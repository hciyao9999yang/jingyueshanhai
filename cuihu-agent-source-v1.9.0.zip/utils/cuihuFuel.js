export const FUEL_ROUTE = "cuihu-pilot-2026";
export const MAX_METRES = 5017.944;
const MAX_ROWS = 192;

export function parsePlan(text, paceText = "") {
  const lines = String(text || "")
    .trim()
    .split(/\r?\n/)
    .map((s) => s.trim())
    .filter(Boolean);
  if (!lines.length || lines.length > MAX_ROWS)
    throw Error("请输入 1 至 192 行赛中补给。");
  const pace = /^(\d{1,2})[:：]([0-5]\d)$/.exec(String(paceText).trim());
  const seconds = pace ? Number(pace[1]) * 60 + Number(pace[2]) : 0;
  return lines
    .map((line, index) => {
      const fail = (message) => {
        throw Error("第 " + (index + 1) + " 行" + message);
      };
      const match =
        /^(\d+(?:[.．]\d+)?)\s*(公里|千米|km|米|m|分钟|分|min)\s*[,，:：、\s]+(.+)$/i.exec(
          line,
        );
      if (!match) fail("请写成「1.5公里 补给原文」或「12分钟 补给原文」。");
      const amount = Number(match[1].replace("．", "."));
      const unit = match[2].toLowerCase();
      const byTime = ["分钟", "分", "min"].includes(unit);
      if (byTime && !seconds) fail("需要目标配速，例如 6:00。");
      const distance = byTime
        ? (amount * 60000) / seconds
        : amount * (["公里", "千米", "km"].includes(unit) ? 1000 : 1);
      if (
        !Number.isFinite(distance) ||
        distance < 1 ||
        distance > MAX_METRES + 0.000001
      )
        fail("里程超出翠湖轨迹（1 至 5017.944 米），请核对。");
      const note = match[3].trim();
      if (!note || note.length > 48 || /[\u0000-\u001f\u007f]/.test(note))
        fail("补给内容须为 1 至 48 个可显示字符。");
      return {
        meters: Math.min(Math.round(distance), Math.floor(MAX_METRES)),
        note,
        source: byTime ? amount + "分 @ " + paceText.trim() : "",
      };
    })
    .sort((a, b) => a.meters - b.meters);
}

export function stationAt(track, meters) {
  let left = 0,
    right = track.length - 1;
  while (right - left > 1) {
    const mid = Math.floor((left + right) / 2);
    if (track[mid].along < meters) left = mid;
    else right = mid;
  }
  const a = track[left],
    b = track[right];
  const fraction =
    b.along > a.along ? (meters - a.along) / (b.along - a.along) : 0;
  const t = Math.min(1, Math.max(0, fraction));
  return { lat: a.lat + (b.lat - a.lat) * t, lon: a.lon + (b.lon - a.lon) * t };
}

export function buildStations(rows, track) {
  const stops = [];
  for (const row of rows) {
    let stop = stops[stops.length - 1];
    if (!stop || stop.meters !== row.meters) {
      stop = {
        meters: row.meters,
        ...stationAt(track, row.meters),
        notes: [],
        estimates: [],
      };
      stops.push(stop);
    }
    if (!stop.notes.includes(row.note)) stop.notes.push(row.note);
    if (row.source && !stop.estimates.includes(row.source))
      stop.estimates.push(row.source);
  }
  return stops;
}

export function newDistanceRun(stops) {
  return {
    stops,
    next: 0,
    last: null,
    lastTime: -Infinity,
    pending: null,
    skipped: 0,
    confirmed: 0,
  };
}

// No catch-up prompts for an old station when acquiring a fix mid-course or after loss.
export function crossStations(run, meters, fixTime) {
  if (
    !run ||
    !Number.isFinite(meters) ||
    !Number.isFinite(fixTime) ||
    fixTime <= run.lastTime
  )
    return null;
  const first = run.last === null;
  const gap = fixTime - run.lastTime > 12000;
  run.lastTime = fixTime;
  run.last = Math.max(run.last ?? 0, meters);
  let reached = null;
  if (run.pending && meters - run.pending.meters > 80) {
    run.pending = null;
    run.skipped++;
  }
  while (run.next < run.stops.length && run.stops[run.next].meters <= meters) {
    const stop = run.stops[run.next++];
    if (meters - stop.meters > (first || gap ? 15 : 45)) {
      run.skipped++;
      continue;
    }
    if (run.pending) run.skipped++;
    run.pending = reached = stop;
  }
  return reached;
}

export function displayKm(meters) {
  return String(Number((meters / 1000).toFixed(3))) + " 公里";
}

export function createPairCode() {
  const data = new Uint32Array(1);
  const value =
    typeof crypto !== "undefined" &&
    typeof crypto.getRandomValues === "function"
      ? crypto.getRandomValues(data)[0]
      : Math.floor(Math.random() * 4294967296);
  return String(value % 1000000).padStart(6, "0");
}
