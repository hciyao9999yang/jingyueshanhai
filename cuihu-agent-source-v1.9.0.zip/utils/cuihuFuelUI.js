import wx from "wx";
import { cuihuPilot } from "./cuihuPilot.js";
import { currentRouteFix } from "./locationLive.js";
import {
  FUEL_ROUTE,
  createPairCode,
  parsePlan,
  buildStations,
  newDistanceRun,
  crossStations,
  displayKm,
} from "./cuihuFuel.js";

import {
  takePlanPhoto,
  requestPlan,
  disposeOperation,
} from "./cuihuPlanInput.js";

const action = (label, run) => ({ label, run });
const isCuihu = (page) => page._raceId === FUEL_ROUTE;
const MAX_HUD = 18;
function shortText(text) {
  return text.length > MAX_HUD ? text.slice(0, MAX_HUD - 1) + "…" : text;
}

export function cancelFuelScan(page) {
  const op = page._fuelWork;
  page._fuelWork = null;
  page._fuelStatus = "";
  disposeOperation(op);
}
export function resetFuel(page) {
  cancelFuelScan(page);
  Object.assign(page, {
    _fuelMode: "",
    _fuelDraftCode: "",
    _fuelBoundCode: "",
    _fuelDraftSource: "",
    _fuelAudioIssue: "",
    _fuelStops: [],
    _fuelDraft: null,
    _fuelRun: null,
    _fuelPhotos: [],
    _fuelText: "",
    _fuelPace: "",
    _fuelError: "",
    _fuelStatus: "",
  });
}
function chooseMode(page, mode) {
  resetFuel(page);
  page._fuelMode = mode;
  if (mode === "none") {
    page.go("fuelStart");
    return;
  }
  if (mode === "wechat") {
    page.go("fuelImport");
    return;
  }
  page.go("fuelAI");
  startWork(page, "general");
}
function draft(page, rows, source, keepCode = false) {
  const stops = buildStations(rows, cuihuPilot.track);
  if (!stops.length) throw Error("没有可绑定的提醒点。");
  page._fuelDraft = stops;
  page._fuelDraftSource = source;
  if (page._fuelMode === "wechat" && !keepCode)
    page._fuelDraftCode = createPairCode();
  page._fuelNoteIndex = page._fuelNotePart = page._fuelDetailIndex = 0;
  page._fuelError = "";
  page._fuelPhotos = [];
  page.go("fuelReview");
}
function editDraft(page) {
  page._fuelText = (page._fuelDraft || [])
    .flatMap((stop) => stop.notes.map((note) => stop.meters + "米 " + note))
    .join("\n");
  page._fuelPace = "";
  page._fuelError = "";
  page.go("fuelManual");
}
function submitTyped(page) {
  if (!page._fuelPhotos.length && !page._fuelDraftCode) {
    page._fuelError = "请先拍摄本人的胜算方案。";
    return;
  }
  try {
    draft(
      page,
      parsePlan(page._fuelText, page._fuelPace),
      "胜算 · 本人校正",
      !!page._fuelDraftCode,
    );
  } catch (error) {
    page._fuelError = error.message;
  }
}
function cancelAndRender(page, message) {
  cancelFuelScan(page);
  page._fuelStatus = "";
  page._fuelError = message;
  if (!page._hidden) page.render();
}

async function startWork(page, kind) {
  if (page._fuelWork) return;
  const op = { view: page._view, cancelled: false };
  const current = () =>
    page._fuelWork === op &&
    !op.cancelled &&
    !page._hidden &&
    page._view === op.view;
  page._fuelWork = op;
  page._fuelError = "";
  page._fuelStatus =
    kind === "general"
      ? "模型正在生成常规建议"
      : kind === "read"
        ? "正在识别赛中条目"
        : "正在调用眼镜相机";
  op.timer = setTimeout(() => {
    if (current()) cancelAndRender(page, "本次操作超时，请重试。");
  }, 90000);
  page.render();
  try {
    if (kind === "one" || kind === "add") {
      if (kind === "add" && page._fuelPhotos.length >= 4)
        throw Error("已拍4张，请识别或清空后重拍。");
      if (kind === "one") page._fuelPhotos = [];
      const shot = await takePlanPhoto(op);
      if (!current()) return;
      const shots = kind === "one" ? [shot] : [...page._fuelPhotos, shot];
      if (shots.reduce((sum, p) => sum + p.size, 0) > 16 * 1024 * 1024)
        throw Error("照片合计过大，请重新拍摄赛中区域。");
      page._fuelPhotos = shots;
      if (kind === "add") return;
    }
    if (kind === "read" && !page._fuelPhotos.length)
      throw Error("请先拍摄赛中方案正文。");
    const photo = kind !== "general";
    page._fuelStatus = photo
      ? "正在识别赛中里程和产品"
      : "模型正在生成常规建议";
    page.render();
    const rows = await requestPlan(op, photo ? page._fuelPhotos : []);
    if (!current()) return;
    draft(page, rows, photo ? "胜算 · 拍照识别" : "大模型 · 常规建议");
  } catch (error) {
    if (current())
      page._fuelError =
        error?.name === "NotAllowedError"
          ? "请在设备上允许相机权限后重试。"
          : String(error?.message || "处理失败，请重试。").slice(0, 84);
  } finally {
    if (page._fuelWork === op) cancelFuelScan(page);
    if (
      !page._hidden &&
      !page._fuelWork &&
      (page._view === op.view || page._view === "fuelReview")
    )
      page.render();
  }
}

export function beginFuelRun(page) {
  page._fuelRun =
    isCuihu(page) && page._fuelStops?.length
      ? newDistanceRun(page._fuelStops)
      : null;
}
function validFuelFix(page, now) {
  const fix = currentRouteFix(page, now),
    nav = page._live?.routeNavigation;
  return fix &&
    nav &&
    Number.isFinite(nav.along) &&
    page._live.routeMatchedAt === fix.timestamp &&
    !nav.offCourse &&
    !nav.nearRoute &&
    !nav.parallelRoute &&
    !page._location?.deviation &&
    fix.accuracy <= 35
    ? fix
    : null;
}
function speakStation(page, stop) {
  const text =
    "已到" +
    displayKm(stop.meters) +
    "。本段补给：" +
    stop.notes.join("，") +
    "。";
  const liveRun = page._fuelRun;
  const applicable = () =>
    page._fuelRun === liveRun &&
    !page._hidden &&
    page._view === "running" &&
    liveRun?.pending === stop;
  const fallback = () => {
    if (!applicable()) return;
    try {
      if (
        typeof speechSynthesis !== "undefined" &&
        typeof speechSynthesis.speak === "function" &&
        typeof SpeechSynthesisUtterance === "function"
      ) {
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = "zh-CN";
        utterance.onerror = () => {
          if (applicable()) page._fuelAudioIssue = "请看字幕";
        };
        speechSynthesis.speak(utterance, "enqueue");
        return;
      }
    } catch {}
    page._fuelAudioIssue = "请看字幕";
  };
  page._fuelAudioIssue = "";
  try {
    if (typeof wx.speech?.playTTS === "function") {
      const result = wx.speech.playTTS(text);
      result?.catch?.(fallback);
      return;
    }
  } catch {}
  fallback();
}
export function observeFuel(page, now) {
  if (
    !page._fuelRun ||
    !isCuihu(page) ||
    page._hidden ||
    page._view !== "running"
  )
    return;
  const fix = validFuelFix(page, now);
  if (!fix) return;
  const due = crossStations(
    page._fuelRun,
    page._live.routeNavigation.along,
    fix.timestamp,
  );
  if (due) {
    page._fuelRun.reachedAt = now;
    speakStation(page, due);
  }
}
export function fuelHUD(page, now) {
  const run = isCuihu(page) && page._fuelRun;
  if (!run)
    return isCuihu(page) && page._fuelMode === "none"
      ? { hudFuel: "", hudFuelLabel: "", fuelBanner: false }
      : {};
  const fix = validFuelFix(page, now);
  if (!fix)
    return {
      hudFuelLabel: "个人补给",
      hudFuel: page._live.state === "paused" ? "已暂停" : "等待路线定位",
    };
  if (run.pending) {
    const notes = run.pending.notes;
    return {
      hudFuelLabel: displayKm(run.pending.meters) + " · 到点",
      hudFuel: shortText(notes.join("、")),
      fuelBanner: now - run.reachedAt < 14000,
      fuelProduct1: notes[0],
      fuelProduct2:
        notes.length > 2 ? notes[1] + " 等，详见补给详情" : notes[1] || "",
      fuelAudioHint: page._fuelAudioIssue || "",
    };
  }
  const next = run.stops[run.next];
  return next
    ? {
        hudFuelLabel:
          "下一补给 · " +
          Math.max(
            0,
            Math.round(next.meters - page._live.routeNavigation.along),
          ) +
          " 米",
        hudFuel: shortText(next.notes.join("、")),
      }
    : { hudFuelLabel: "个人补给", hudFuel: "已无后续提醒" };
}
export function fuelMapXml(page) {
  if (
    !isCuihu(page) ||
    !page._fuelStops?.length ||
    typeof GPXDocument !== "function"
  )
    return "";
  try {
    const doc = new GPXDocument();
    for (const p of page._fuelStops)
      doc.addWaypoint({
        latitude: p.lat,
        longitude: p.lon,
        name: displayKm(p.meters),
      });
    return doc.toString();
  } catch {
    return "";
  }
}
function decide(page, confirm) {
  const run = page._fuelRun;
  if (run?.pending) {
    if (confirm) {
      run.confirmed++;
      page._live.aids++;
    } else {
      run.skipped++;
    }
    run.pending = null;
  }
  page.go("running");
}
function stationDetails(page, station, title, index, count, actions) {
  const notes = station.notes;
  const i = Math.min(page._fuelNoteIndex || 0, notes.length - 1);
  const details = notes[i];
  const parts = details.match(/[\s\S]{1,20}/g);
  const part = Math.min(page._fuelNotePart || 0, parts.length - 1);
  if (notes.length > 1 || parts.length > 1)
    actions.push(
      action("下一段原文", () => {
        page._fuelNotePart = (part + 1) % parts.length;
        if (!page._fuelNotePart) page._fuelNoteIndex = (i + 1) % notes.length;
      }),
    );
  page.display(
    {
      eyebrow:
        title === "核对赛中方案" && page._fuelDraftCode
          ? "核对绑定码　" + page._fuelDraftCode
          : "翠湖 · 补给",
      title,
      next: displayKm(station.meters) + "　" + parts[part],
      detail: station.estimates.length
        ? "按目标配速折算 · " + station.estimates.join("、")
        : "按方案里程提醒",
      hint:
        (title === "核对赛中方案"
          ? (page._fuelDraftSource || "") + " · "
          : "") +
        "第 " +
        (index + 1) +
        " / " +
        count +
        " 个点" +
        (parts.length > 1 || notes.length > 1
          ? " · 原文 " +
            (i + 1) +
            "/" +
            notes.length +
            " 段 " +
            (part + 1) +
            "/" +
            parts.length
          : ""),
      canBack: title !== "到点补给",
      canHome: false,
    },
    actions,
  );
}
export const fuelMethods = {
  onFuelText(event) {
    this._fuelText = event.detail.value;
  },
  onFuelPace(event) {
    this._fuelPace = event.detail.value;
  },
};
export const fuelViews = {
  cuihuReady() {
    this.display(
      {
        eyebrow: "马拉松 · 昆明翠湖 5 公里",
        title: "个人补给方案",
        detail: "选择本次跑步的补给方式。",
        compactMenu: true,
      },
      [
        action("大模型生成常规补给建议", () => chooseMode(this, "general")),
        action("无需补给提醒", () => chooseMode(this, "none")),
        action("微信迈胜 · 胜算专属方案", () => chooseMode(this, "wechat")),
      ],
    );
  },
  fuelAI() {
    const busy = !!this._fuelWork;
    this.display(
      {
        eyebrow: "翠湖 · 常规补给",
        title: "大模型补给建议",
        next: this._fuelStatus || this._fuelError || "可以重新生成本次建议。",
        detail: busy
          ? "生成后可逐点核对，再决定是否采用。"
          : "仅采用你确认过的建议。",
        canHome: false,
      },
      busy
        ? [action("返回选择", () => this.go("cuihuReady"))]
        : [
            action("重新生成", () => startWork(this, "general")),
            action("返回选择", () => this.go("cuihuReady")),
          ],
    );
  },
  fuelImport() {
    const busy = !!this._fuelWork;
    this.display(
      {
        eyebrow: "翠湖 · 微信胜算",
        title: "迈胜个人专属方案",
        fuelLinkCard: true,
        next: this._fuelStatus || "手机微信搜「胜算」或识别太阳码",
        detail:
          this._fuelError ||
          "填写资料并生成方案，打开赛中正文。眼镜拍照后由视觉模型读取。",
        canHome: false,
      },
      busy
        ? [
            action("取消本次操作", () =>
              cancelAndRender(this, "已取消，可重拍。"),
            ),
          ]
        : [
            action("拍照识别赛中方案", () => startWork(this, "one")),
            action("长图分屏拍摄", () => {
              this._fuelPhotos = [];
              this._fuelError = "";
              this.go("fuelPhotos");
            }),
            ...(this._fuelPhotos.length
              ? [action("按照片校正录入", () => editDraft(this))]
              : []),
            action("返回选择", () => this.go("cuihuReady")),
          ],
    );
  },
  fuelPhotos() {
    const n = this._fuelPhotos.length,
      busy = !!this._fuelWork;
    this.display(
      {
        eyebrow: "微信胜算 · 长图",
        title: "分屏拍摄赛中条目",
        next: this._fuelStatus || "已拍 " + n + " / 4 张",
        detail:
          this._fuelError ||
          "从起点按顺序拍到末项，相邻照片保留同一段标题。照片将交给视觉模型。",
        canHome: false,
      },
      busy
        ? [action("取消本次操作", () => cancelAndRender(this, "已取消。"))]
        : [
            ...(n < 4
              ? [
                  action("拍摄第 " + (n + 1) + " 张", () =>
                    startWork(this, "add"),
                  ),
                ]
              : []),
            ...(n
              ? [
                  action("完成拍照并识别", () => startWork(this, "read")),
                  action("清空重拍", () => {
                    this._fuelPhotos = [];
                    this._fuelError = "";
                  }),
                  action("按照片校正录入", () => editDraft(this)),
                ]
              : []),
            action("返回微信引导", () => this.go("fuelImport")),
          ],
    );
  },
  fuelManual() {
    this.display(
      {
        title: "按照片核对条目",
        fuelEditor: true,
        fuelText: this._fuelText,
        fuelPace: this._fuelPace,
        detail:
          this._fuelError || "每行写累计里程和产品原文，按分钟填写须提供配速。",
        canHome: false,
      },
      [
        action("核对点位", () => submitTyped(this)),
        action("返回", () => this.back()),
      ],
    );
  },
  fuelReview() {
    const stops = this._fuelDraft;
    if (!stops?.length) {
      this.go("cuihuReady");
      this.render();
      return;
    }
    const i = this._fuelDetailIndex || 0,
      wechat = this._fuelMode === "wechat";
    const actions = [
      action(wechat ? "确认绑定" : "采用常规建议", () => {
        this._fuelStops = stops;
        this._fuelBoundCode = wechat ? this._fuelDraftCode : "";
        this.go("fuelStart");
      }),
      ...(stops.length > 1
        ? [
            action("查看下一个点", () => {
              this._fuelDetailIndex = (i + 1) % stops.length;
              this._fuelNoteIndex = this._fuelNotePart = 0;
            }),
          ]
        : []),
      ...(wechat
        ? [
            action("重新拍照", () => chooseMode(this, "wechat")),
            action("修正识别结果", () => editDraft(this)),
          ]
        : [action("重新生成", () => chooseMode(this, "general"))]),
      action("返回选择", () => this.go("cuihuReady")),
    ];
    stationDetails(this, stops[i], "核对赛中方案", i, stops.length, actions);
  },
  fuelStart() {
    const silent = this._fuelMode === "none";
    if (!silent && !this._fuelStops.length) {
      this.go("cuihuReady");
      this.render();
      return;
    }
    this.display(
      {
        eyebrow: "翠湖 · 开跑前",
        title: silent
          ? "已关闭补给提醒"
          : this._fuelBoundCode
            ? "个人方案已绑定"
            : "已采用常规建议",
        next: silent
          ? "本次仅开启路线导航与运动数据显示。"
          : "已匹配 " + this._fuelStops.length + " 个路线提醒点",
        detail: this._fuelBoundCode
          ? "本次绑定码　" + this._fuelBoundCode
          : silent
            ? "补给卡片及补给语音已关闭。"
            : "到点显示并播报所选建议。",
        canHome: false,
      },
      [
        action(silent ? "开始跑步" : "使用当前方案开跑", () => {
          beginFuelRun(this);
          this.startRun();
        }),
        action("重新选择方案", () => this.go("cuihuReady")),
        action("连接手表", () => {
          this._cuihuWatchReturn = { view: "fuelStart" };
          this.go("device");
        }),
      ],
    );
  },
  fuelArrival() {
    const run = this._fuelRun;
    if (!run?.pending) {
      this.go("running");
      this.render();
      return;
    }
    stationDetails(
      this,
      run.pending,
      "到点补给",
      run.next - 1,
      run.stops.length,
      [
        action("已补给", () => decide(this, true)),
        action("跳过本点", () => decide(this, false)),
        action("返回导航", () => this.go("running")),
      ],
    );
  },
};
