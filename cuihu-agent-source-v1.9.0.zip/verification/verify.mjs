import vm from "node:vm";
import fs from "node:fs";
import path from "node:path";
import assert from "node:assert/strict";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const storage = new Map();
const timers = new Map();
const startTime = Date.parse("2026-11-11T08:00:00+08:00");
let time = startTime;
let timerId = 0;
let passed = 0;
const check = (condition, label) => {
  assert.ok(condition, label);
  passed++;
};
class Clock extends Date {
  static now() {
    return time;
  }
}

const wx = {
  getStorageSync: (key) => storage.get(key),
  setStorageSync: (key, value) => storage.set(key, value),
};
const navigatorStub = {};
function installGeolocation({ singleFix = false, watch = true } = {}) {
  const active = new Map();
  const requests = [];
  const cleared = [];
  const singleRequests = [];
  navigatorStub.geolocation = {
    watchPosition(success, error, options) {
      const id = requests.length;
      const request = { id, success, error, options };
      requests.push(request);
      active.set(id, request);
      return id;
    },
    clearWatch(id) {
      cleared.push(id);
      active.delete(id);
    },
  };
  if (!watch) delete navigatorStub.geolocation.watchPosition;
  if (singleFix) {
    navigatorStub.geolocation.getCurrentPosition = (
      success,
      error,
      options,
    ) => {
      singleRequests.push({ success, error, options });
    };
  }
  return { active, requests, cleared, singleRequests };
}

function gpsFix(
  lat,
  lon,
  { accuracy = 5, speed = null, heading = null, timestamp = time } = {},
) {
  return {
    coords: { latitude: lat, longitude: lon, accuracy, speed, heading },
    timestamp,
  };
}

const context = vm.createContext({
  Date: Clock,
  navigator: navigatorStub,
  setTimeout(fn, delay) {
    return ++timerId;
  },
  clearTimeout() {},
  setInterval(fn) {
    timers.set(++timerId, fn);
    return timerId;
  },
  clearInterval(id) {
    timers.delete(id);
  },
});
const wxModule = new vm.SyntheticModule(
  ["default"],
  function () {
    this.setExport("default", wx);
  },
  { context, identifier: "wx" },
);
const modules = new Map();
function getModule(file) {
  if (modules.has(file)) return modules.get(file);
  const source = fs.readFileSync(file, "utf8");
  const module = new vm.SourceTextModule(source, { context, identifier: file });
  modules.set(file, module);
  return module;
}
const entry = getModule(path.join(root, "utils/trailScreen.js"));
await entry.link((name, ref) =>
  name === "wx"
    ? wxModule
    : getModule(path.resolve(path.dirname(ref.identifier), name)),
);
await entry.evaluate();
const { trail } = entry.namespace;
const logic = modules.get(path.join(root, "utils/raceLogic.js")).namespace;
const {
  matchCutoff,
  formatCutoff,
  necessaryReady,
  formatElapsed,
  gearComplete,
  normalizeSettings,
  recoveryAdvice,
  nextPrepPlan,
} = logic;

const cfg = JSON.parse(fs.readFileSync(path.join(root, "app.json"), "utf8"));
check(
  cfg.pages.length === 1 && cfg.pages[0] === "pages/index/index",
  "single trail page",
);
check(
  fs.readdirSync(path.join(root, "pages")).join(",") === "index",
  "no leftover app pages",
);
check(
  !cfg.agentWorkers &&
    Array.isArray(cfg.permissions) &&
    cfg.permissions.join() === "GEOLOCATION,CAMERA,INTERNET",
  "location, plan camera and packaged GPX access declared",
);
const markup = fs.readFileSync(path.join(root, cfg.pages[0] + ".ink"), "utf8");
const schema = JSON.parse(markup.match(/<script def>([\s\S]*?)<\/script>/)[1])
  .schema.data;
check(
  Object.keys(schema.properties).length === 0 &&
    schema.additionalProperties === false,
  "no parameters requested at launch",
);
check(
  markup.includes('ink:if="{{fuelEditor}}"') && markup.includes('bindinput="onFuelText"'),
  "manual editor available on fuel entry",
);
check(
  !trail.onVoiceWakeup && !trail.onAirportInput,
  "no voice or text handlers",
);
for (const [, name] of markup.matchAll(/bindtap="([^"]+)"/g)) {
  check(typeof trail[name] === "function", "bound handler " + name);
}

const manifestPath = path.join(root, "META-INF/aix/manifest.json");
if (fs.existsSync(manifestPath)) {
  const manifest = JSON.parse(fs.readFileSync(manifestPath, "utf8"));
  check(
    manifest.entries.every((entry) => entry.path !== "decision-tree.png"),
    "manifest excludes the reference diagram",
  );
}

function make(query, options = {}) {
  if (!options.keepStorage) storage.clear();
  const messages = [];
  const page = {
    ...trail,
    data: { ...trail.data },
    setData(patch) {
      Object.assign(this.data, patch);
    },
    postMessage(payload) {
      messages.push(payload);
    },
  };
  page._messages = messages;
  page.onLoad(query);
  return page;
}
function key(page, code) {
  page.onKeyUp({ code, preventDefault() {} });
}
function visible(page) {
  const slots = page.data.cuihuHud ? [0, 1, 2, 3] : [0, 1, 2];
  return slots.flatMap((slot) =>
    page.data["has" + slot]
      ? [
          {
            slot,
            label: page.data["action" + slot],
            focused: /\bfocused\b/.test(page.data["class" + slot]),
          },
        ]
      : [],
  );
}
function focused(page) {
  return visible(page).find((item) => item.focused)?.label;
}
function labels(page) {
  return visible(page).map((item) => item.label);
}
function hasVisible(page, label) {
  return visible(page).some((item) =>
    typeof label === "string"
      ? item.label.includes(label)
      : label.test(item.label),
  );
}
function tap(page, label) {
  const matches = (item) =>
    typeof label === "string"
      ? item.label.includes(label)
      : label.test(item.label);
  for (let attempt = 0; attempt < 30; attempt++) {
    const item = visible(page).find((item) => item.focused && matches(item));
    if (item) {
      key(page, "Enter");
      return;
    }
    key(page, "ArrowDown");
  }
  assert.fail(
    "Action not reached with real key events: " +
      label +
      " on " +
      page.data.title,
  );
}
function actionCount(page) {
  return (page._actions || []).length;
}
function actionLabels(page) {
  return (page._actions || []).map((item) => item.label);
}
function isAtMostThree(page, allowRent = false) {
  const count = actionCount(page);
  if (allowRent && page._view === "rentSite") return count === 4;
  if (page._view === "racePick" || page._view === "devicePick")
    return count <= 3 || !!page.data.pageInfo;
  return count <= 3;
}
function sendCatalog(page, races) {
  page.onMessage({ data: { type: "trailpilot.race.v1.catalog", races } });
}
function sendBriefing(page, briefing) {
  page.onMessage({
    data: { type: "trailpilot.race.v1.briefing", ...briefing },
  });
}
function continueWithoutRace(page) {
  check(page.data.title === "选择本次赛事", "race pick follows sport choice");
  tap(page, "先不选赛事继续");
  check(
    page.data.title === "赛事资讯同步",
    "skipping a race still opens official sync",
  );
  tap(page, "仍去强装检查");
  check(
    page.data.title === "强装逐项检查" && page.data.hero.includes("未同步"),
    "missing gear list is not invented",
  );
  tap(page, "将按官方公告自查");
}

const home = make();
check(
  labels(home).join() === "自用,租赁" && !home.data.canBack,
  "home only offers own and rental entry",
);
check(home.data.hint.includes("镜腿滑动"), "home teaches temple swipe");
check(
  home.data.eyebrow.includes("1.9.0"),
  "home label shows the updated version",
);
let interceptedExit = false;
home.onKeyUp({
  code: "Backspace",
  preventDefault() {
    interceptedExit = true;
  },
});
check(!interceptedExit, "root Backspace remains with host");

tap(home, "自用");
check(
  home.data.title === "选择本次任务" &&
    actionCount(home) === 2 &&
    hasVisible(home, "日常训练") &&
    hasVisible(home, "赛事使用"),
  "own mode shows training and race without an empty review action",
);
check(!hasVisible(home, "赛后复盘"), "review is hidden until a record exists");

tap(home, "日常训练");
check(
  home.data.title === "选择本次目的" && actionCount(home) === 3,
  "training still chooses a purpose",
);
tap(home, "尝鲜体验");
check(
  home.data.title === "连接运动设备" &&
    home._sport === "" &&
    home._task === "train",
  "daily training skips race type and goes to the device step",
);
tap(home, "暂不连接");
check(
  home.data.title === "核对并开跑" && hasVisible(home, "开始"),
  "training can start without a bluetooth device",
);
tap(home, "开始");
check(
  home._view === "running" &&
    home.data.title === "赛中辅助" &&
    home.data.showMetrics,
  "training starts mid-run assistance",
);
check(
  home.data.metric2 === "—" && home.data.hint.includes("定位未接入"),
  "daily training explains when the runtime provides no location",
);
check(labels(home)[0] === "不适求助", "help is the first mid-run action");
check(
  home.data.metric0Label === "距下一 CP" && home.data.metric1 === "—",
  "missing checkpoint and cutoff show a dash",
);
check(
  home._messages.some((item) => item.type === "trailpilot.run.v1.start"),
  "start message is posted",
);
check(!home.data.canBack && !home.data.canHome, "mid-run hides back and home");
home.goBack();
check(home._view === "running", "back does not leave a live run");
tap(home, "暂停");
check(
  home.data.title === "已暂停" && hasVisible(home, "继续"),
  "pause stops the clock and offers resume",
);
tap(home, "结束");
check(
  home._view === "review" && home.data.title === "复盘与复用",
  "ending a run opens review",
);
check(
  hasVisible(home, "恢复建议") &&
    hasVisible(home, "备赛计划") &&
    hasVisible(home, "更多"),
  "review offers recovery, next plan, and more",
);
check(
  !hasVisible(home, "归还指引") && !hasVisible(home, "沿用设置"),
  "own-use review keeps return and reuse off the main card",
);
tap(home, "恢复建议");
check(
  home.data.title === "一般恢复建议" &&
    home.data.next.includes("一般恢复建议") &&
    home.data.next.includes("不是医疗意见"),
  "recovery is labeled as general advice, not medical or official",
);
tap(home, "备赛计划");
check(
  home.data.title === "下次备赛计划" && home.data.next.length > 0,
  "training review can open a next-prep plan",
);
tap(home, "更多");
check(
  hasVisible(home, "沿用设置") &&
    hasVisible(home, "完成") &&
    !hasVisible(home, "归还指引"),
  "own-use more menu has reuse and done, but no return guide",
);
check(
  home._messages.some((item) => item.type === "trailpilot.run.v1.stop"),
  "stop message is posted",
);

const emptyCatalog = make();
tap(emptyCatalog, "自用");
tap(emptyCatalog, "赛事使用");
tap(emptyCatalog, "竞技 PB");
check(
  emptyCatalog.data.title === "选择本次赛种" &&
    hasVisible(emptyCatalog, "马拉松") &&
    hasVisible(emptyCatalog, "越野跑") &&
    actionCount(emptyCatalog) === 2,
  "race flow asks for event type after purpose",
);
tap(emptyCatalog, "越野跑");
check(
  emptyCatalog.data.title === "选择本次赛事",
  "empty catalog opens race pick rather than inventing events",
);
check(
  !hasVisible(emptyCatalog, "昆明市跑步路线"),
  "the marathon pilot is not listed for trail running",
);
check(
  emptyCatalog._messages.some(
    (item) =>
      item.type === "trailpilot.race.v1.request" &&
      item.reason === "catalog" &&
      item.sport === "trail",
  ),
  "entering race pick requests the host catalog",
);
check(
  hasVisible(emptyCatalog, "稍后同步") &&
    hasVisible(emptyCatalog, "先不选赛事继续") &&
    hasVisible(emptyCatalog, "返回改赛种"),
  "empty catalog offers retry, continue without a race, and back",
);
sendCatalog(emptyCatalog, []);
check(
  emptyCatalog._catalogReceived && emptyCatalog.data.next.includes("无法同步"),
  "an empty host catalog is reported as unavailable",
);
check(
  !hasVisible(emptyCatalog, "测试赛") &&
    !/UTMB|环四姑娘|崇礼|敢峰/i.test(JSON.stringify(emptyCatalog._catalog)),
  "no unofficial race names are invented",
);
tap(emptyCatalog, "先不选赛事继续");
check(
  emptyCatalog.data.title === "赛事资讯同步" &&
    emptyCatalog.data.next.includes("官方公告"),
  "continuing without a race still explains that official info is missing",
);
tap(emptyCatalog, "仍去强装检查");
check(
  emptyCatalog.data.hero.includes("未同步") && actionCount(emptyCatalog) === 3,
  "missing official gear is a single acknowledgement, not a made-up list",
);
tap(emptyCatalog, "稍后准备");
check(emptyCatalog._view === "home", "later prep returns home");
tap(emptyCatalog, "自用");
check(
  hasVisible(emptyCatalog, "继续赛事准备"),
  "in-progress race prep can be resumed",
);
tap(emptyCatalog, "继续赛事准备");
check(
  emptyCatalog._view === "gearCheck" ||
    emptyCatalog.data.title.includes("强装"),
  "resume returns to the incomplete gear check",
);
tap(emptyCatalog, "将按官方公告自查");
tap(emptyCatalog, "暂不连接");
check(
  emptyCatalog.data.title === "核对并开跑" && hasVisible(emptyCatalog, "开始"),
  "start is offered after skipping bluetooth",
);
tap(emptyCatalog, "开始");
check(
  emptyCatalog.data.next.includes("偏航") ||
    emptyCatalog.data.next.includes("轨迹"),
  "trail running emphasizes course and waypoint cues",
);
emptyCatalog.onMessage({
  data: {
    type: "trailpilot.run.v1.update",
    sessionId: emptyCatalog._live.sessionId,
    sequence: 1,
    timestamp: time,
    state: "running",
    pace: `6'10"/公里`,
    nextCp: "3",
    nextCpMeters: 800,
    gpsWeak: true,
    cue: "核对路标",
  },
});
check(
  emptyCatalog.data.metric2.includes("6") &&
    emptyCatalog.data.metric0.includes("CP 3") &&
    emptyCatalog.data.next.includes("定位不稳"),
  "host update refreshes trail cues without a tap",
);
check(
  emptyCatalog.data.metric3.includes("核对路标"),
  "host cue fills the rhythm slot",
);
check(
  emptyCatalog.data.metric2Label === "当前配速" &&
    !emptyCatalog.data.detail.includes("下一补给"),
  "missing pace strategy and aid plan do not invent mid-race copy",
);
emptyCatalog.onMessage({
  data: {
    type: "trailpilot.run.v1.update",
    sessionId: emptyCatalog._live.sessionId,
    sequence: 2,
    timestamp: time + 10,
    state: "running",
    aidAlert: true,
    nextCp: "3",
  },
});
check(
  hasVisible(emptyCatalog, "去补给") && labels(emptyCatalog)[0] === "不适求助",
  "aid alert keeps help first and offers the aid screen",
);
tap(emptyCatalog, "去补给");
check(
  emptyCatalog._view === "aid" &&
    labels(emptyCatalog)[0] === "不适求助" &&
    hasVisible(emptyCatalog, "已补") &&
    hasVisible(emptyCatalog, "稍后"),
  "aid screen uses help, taken, and later",
);
check(
  emptyCatalog.data.next.includes("—"),
  "aid screen falls back to a dash without an official plan",
);
tap(emptyCatalog, "已补");
check(
  emptyCatalog._live.aids === 1 && emptyCatalog._view === "running",
  "taking aid is recorded",
);
tap(emptyCatalog, "不适求助");
check(
  emptyCatalog.data.title === "不适求助" && emptyCatalog.data.tone === "warn",
  "help screen is prioritized and explicit",
);
tap(emptyCatalog, "结束并复盘");
check(
  emptyCatalog._view === "review" && emptyCatalog._record.aids === 1,
  "help can finish into review with aid history",
);

const hosted = make();
tap(hosted, "自用");
tap(hosted, "赛事使用");
tap(hosted, "竞技 PB");
tap(hosted, "越野跑");
sendCatalog(hosted, [
  {
    id: "trail-a",
    name: "宿主测试越野甲",
    sport: "trail",
    date: "2026-12-01",
    place: "测试点",
  },
  { id: "trail-b", name: "宿主测试越野乙", sport: "trail" },
  { id: "trail-c", name: "宿主测试越野丙", sport: "trail" },
  { id: "trail-d", name: "宿主测试越野丁", sport: "trail" },
  { id: "marathon-a", name: "宿主测试马拉松", sport: "marathon" },
  { id: "other", name: "未知项目", sport: "ultra" },
]);
check(
  hasVisible(hosted, "宿主测试越野甲") &&
    !hasVisible(hosted, "宿主测试马拉松") &&
    !hasVisible(hosted, "未知项目") &&
    !hasVisible(hosted, "昆明市跑步路线"),
  "catalog is filtered to the current sport and unknown sports are ignored",
);
check(
  actionCount(hosted) > 3 && hosted.data.pageInfo === "1/2",
  "more than three synced races paginate",
);
tap(hosted, "宿主测试越野甲");
check(
  hosted.data.title === "赛事资讯同步",
  "choosing a race opens official sync",
);
check(
  hosted._messages.some(
    (item) =>
      item.type === "trailpilot.race.v1.request" &&
      item.reason === "sync" &&
      item.raceId === "trail-a",
  ),
  "entering race sync requests the official briefing",
);
check(
  hosted.data.next.includes("尚未收到") ||
    hosted.data.next.includes("官方公告"),
  "a pending briefing tells the runner official info is missing",
);
sendBriefing(hosted, {
  raceId: "trail-a",
  name: "宿主测试越野甲",
  sport: "trail",
  date: "2026-12-01",
  distance: "50 公里",
  climb: "2000 米",
  notices: [{ id: "n1", title: "出发时间调整", summary: "请以手册为准" }],
  mandatoryGear: [
    { id: "shell", label: "防水外套", hint: "需覆盖躯干" },
    { id: "whistle", label: "哨子" },
  ],
  paceStrategy: [
    {
      id: "3",
      cp: "3",
      label: "前段",
      targetPace: `8'00"/公里`,
      cue: "上坡稳走",
    },
  ],
  aidPlan: [
    { id: "3", cp: "3", label: "CP3", plan: "补水补盐", supplies: "水、盐丸" },
  ],
  cutoffTable: [{ group: "open", cp: "3", deadline: time + 40 * 60000 }],
  trainingPlan: "按主办方公布的爬升适应安排",
  syncedAt: 2000,
});
check(
  hosted.data.next.includes("出发时间调整"),
  "official notices appear after a briefing arrives",
);
check(
  hosted.data.detail.includes("宿主测试越野甲") &&
    hosted.data.detail.includes("50 公里") &&
    hosted.data.detail.includes("2000 米"),
  "key official facts are shown only when provided",
);
sendBriefing(hosted, {
  raceId: "trail-a",
  name: "过期资讯",
  sport: "trail",
  notices: [{ title: "过期通知" }],
  syncedAt: 1000,
});
check(
  hosted._raceName === "宿主测试越野甲" &&
    !hosted.data.next.includes("过期通知"),
  "stale briefing with an older syncedAt is ignored",
);
tap(hosted, "已同步，去强装检查");
check(
  hosted.data.title === "强装逐项检查" && hosted.data.hero === "防水外套",
  "gear check starts with the first official item",
);
check(
  hasVisible(hosted, "已带") &&
    hasVisible(hosted, "未带") &&
    hasVisible(hosted, "上一项"),
  "gear check is item-by-item",
);
tap(hosted, "未带");
check(
  hosted.data.hero === "哨子",
  "unchecked items advance to the next official gear row",
);
tap(hosted, "未带");
check(
  hosted.data.title === "强装尚未齐" && !hasVisible(hosted, "开始"),
  "required gear left unpacked blocks the start",
);
tap(hosted, "继续检查");
tap(hosted, "已带");
tap(hosted, "上一项");
tap(hosted, "已带");
tap(hosted, "已带");
check(
  hosted.data.title === "连接运动设备" &&
    hosted._briefed &&
    gearComplete(hosted.sessionState()),
  "all required gear must be packed before leaving the checklist",
);
tap(hosted, "暂不连接");
check(
  hasVisible(hosted, "开始"),
  "lineup offers start only after required gear is packed",
);
tap(hosted, "开始");
hosted.onMessage({
  data: {
    type: "trailpilot.run.v1.update",
    sessionId: hosted._live.sessionId,
    sequence: 1,
    timestamp: time,
    state: "running",
    pace: `8'20"/公里`,
    nextCp: "3",
    nextCpMeters: 500,
    group: "open",
  },
});
check(
  hosted.data.metric2.includes(`8'20"`) &&
    hosted.data.metric2.includes(`8'00"`),
  "mid-race shows current versus official target pace",
);
check(
  hosted.data.metric3.includes("上坡稳走"),
  "current-segment official cue is shown",
);
check(
  hosted.data.detail.includes("补水补盐") ||
    hosted.data.detail.includes("水、盐丸"),
  "running copy shows the official next-aid plan",
);
check(
  hosted.data.metric1.includes("40 分"),
  "briefing cutoff table is used when the live update has none",
);
hosted.onMessage({
  data: {
    type: "trailpilot.run.v1.update",
    sessionId: hosted._live.sessionId,
    sequence: 2,
    timestamp: time + 10,
    state: "running",
    aidAlert: true,
    nextCp: "3",
    group: "open",
  },
});
tap(hosted, "去补给");
check(
  hosted.data.next.includes("补水补盐") ||
    hosted.data.next.includes("水、盐丸"),
  "aid screen shows the official plan for the next CP",
);
tap(hosted, "已补");
tap(hosted, "结束");
tap(hosted, "备赛计划");
check(
  hosted.data.next.includes("按主办方公布的爬升适应安排"),
  "host-provided next-prep plan is shown instead of a generated one",
);
tap(hosted, "更多");
tap(hosted, "沿用设置");
check(
  storage.has("mirrorTrail.preferredSettings"),
  "reuse writes device storage",
);
const reused = make(undefined, { keepStorage: true });
check(
  hasVisible(reused, "确认沿用") &&
    reused.data.next.includes("宿主测试越野甲") &&
    reused.data.next.includes("越野跑"),
  "a new session restores the saved race and sport",
);
tap(reused, "确认沿用");
check(
  reused._view === "device" || reused.data.title.includes("连接"),
  "complete reused race and gear skip back to the ready stage",
);
check(
  reused._raceId === "trail-a" &&
    reused._gearChecks.shell === "packed" &&
    reused._gearChecks.whistle === "packed",
  "reuse restores race identity and gear ticks",
);
check(
  reused._lastPlan.includes("按主办方公布的爬升适应安排"),
  "reuse restores the last prep plan",
);
check(
  reused._messages.some(
    (item) =>
      item.type === "trailpilot.race.v1.request" && item.reason === "sync",
  ),
  "reused races request a fresh official sync",
);

const marathon = make();
tap(marathon, "自用");
tap(marathon, "赛事使用");
tap(marathon, "竞技 PB");
tap(marathon, "马拉松");
continueWithoutRace(marathon);
tap(marathon, "暂不连接");
tap(marathon, "开始");
check(
  marathon.data.next.includes("补给") ||
    marathon.data.next.includes("关键节点"),
  "marathon emphasizes aid stations and key points",
);
marathon.onMessage({
  data: {
    type: "trailpilot.run.v1.update",
    sessionId: marathon._live.sessionId,
    sequence: 1,
    timestamp: time,
    state: "running",
    pace: `4'50"/公里`,
    nextCp: "12",
    nextCpMeters: 2000,
    cutoff: time + 25 * 60000,
    group: "open",
  },
});
check(
  marathon.data.metric1.includes("25 分") &&
    marathon.data.metric0.includes("2 公里"),
  "official cutoff countdown and next CP distance appear when provided",
);
time += 30 * 60000;
for (const tick of timers.values()) tick();
marathon.render();
check(
  marathon.data.metric1 === "已过关门",
  "cutoff text updates as time passes",
);
marathon.onMessage({
  data: {
    type: "trailpilot.run.v1.update",
    sessionId: marathon._live.sessionId,
    sequence: 1,
    timestamp: time,
    state: "running",
    cutoffConflict: true,
    nextCp: "12",
  },
});
check(
  marathon.data.metric1 === "已过关门",
  "stale or equal sequence is ignored",
);

marathon.onMessage({
  data: {
    type: "trailpilot.run.v1.update",
    sessionId: marathon._live.sessionId,
    sequence: 3,
    timestamp: time,
    state: "running",
    cutoffConflict: true,
    nextCp: "12",
  },
});
check(
  marathon.data.metric1 === "—" && marathon.data.hint.includes("官方公告"),
  "conflicting official cutoffs display a dash",
);
tap(marathon, "结束");
tap(marathon, "备赛计划");
check(
  marathon.data.next.includes("关门") || marathon.data.next.includes("配速"),
  "a tight cutoff yields a sustainable-pace next plan",
);

function goToMarathonList(page) {
  tap(page, "自用");
  tap(page, "赛事使用");
  tap(page, "竞技 PB");
  tap(page, "马拉松");
}

const cuihu = make();
goToMarathonList(cuihu);
check(
  cuihu.data.title === "选择本次赛事" && hasVisible(cuihu, "昆明市跑步路线"),
  "marathon race pick shows the built-in Cuihu pilot even before a host catalog arrives",
);
sendCatalog(cuihu, []);
check(
  hasVisible(cuihu, "昆明市跑步路线") && hasVisible(cuihu, "先不选赛事继续"),
  "an empty host catalog still lists the built-in marathon pilot",
);
sendCatalog(cuihu, [
  { id: "marathon-a", name: "宿主测试马拉松", sport: "marathon" },
  { id: "trail-a", name: "宿主测试越野甲", sport: "trail" },
]);
check(
  hasVisible(cuihu, "昆明市跑步路线") &&
    hasVisible(cuihu, "宿主测试马拉松") &&
    !hasVisible(cuihu, "宿主测试越野甲"),
  "host marathon races appear alongside the pilot and trail events stay filtered out",
);
tap(cuihu, "昆明市跑步路线");
check(cuihu._view === "cuihuReady" && !cuihu._live.sessionId, "pre-race does not start tracking");
tap(cuihu, "无需补给提醒");
tap(cuihu, "开始跑步");
check(
  cuihu._view === "running" &&
    cuihu.data.cuihuHud &&
    cuihu._raceId === "cuihu-pilot-2026",
  "confirming start in Cuihu preparation starts navigation",
);

// GCJ02 route and input regression checks follow.
const pilot = modules.get(path.join(root, "utils/cuihuPilot.js")).namespace;
const crs = modules.get(path.join(root, "utils/coordinates.js")).namespace;
const locations = modules.get(
  path.join(root, "utils/locationLive.js"),
).namespace;
const gpsPace = modules.get(path.join(root, "utils/gpsPace.js")).namespace;
const map = modules.get(path.join(root, "utils/cuihuMap.js")).namespace;
const near = (a, b, tolerance = 1e-8) => Math.abs(a - b) <= tolerance;
const beijing = crs.toGcj02(39.915, 116.404, "WGS84");
check(
  near(beijing.latitude, 39.91640428150164) &&
    near(beijing.longitude, 116.41024449916938),
  "known independent Beijing coordinate vector",
);
check(
  crs.toGcj02(25, 102, "BD09") === null,
  "unsupported datum is never silently relabelled",
);
check(crs.toGcj02(NaN, 102, "WGS84") === null, "invalid coordinate rejected");
check(
  crs.resolveInputCrs(
    { coordinateSystem: "GCJ02", coords: { coordinateSystem: "WGS84" } },
    "WGS84",
  ) === null,
  "conflicting nested datums rejected",
);
const berlin = crs.toGcj02(52.52, 13.405, "WGS84");
check(
  berlin.latitude === 52.52 && berlin.longitude === 13.405,
  "outside conversion region stays unchanged",
);
const summary = [];
for (const [slug, routeId, count] of [
  ["kunming-half", pilot.KUNMING_HALF_ID, 8469],
  ["cuihu", pilot.CUIHU_PILOT_ID, 2013],
]) {
  const raw = JSON.parse(
    fs.readFileSync(path.join(root, "assets/routes", slug + ".wgs84.json")),
  );
  const data = JSON.parse(
    fs.readFileSync(path.join(root, "assets/routes", slug + ".gcj02.json")),
  );
  const route = pilot.getBuiltinRoute(routeId);
  check(
    route.coordinateSystem === "GCJ02" &&
      route.track.length === count &&
      route.sourcePointCount === count,
    "all " + slug + " points retained in target CRS",
  );
  check(
    Math.abs(route.trackAlong - raw.distanceMeters) < 0.001,
    "preserve WGS84 distance rather than inflated offset distance",
  );
  let maxError = 0;
  for (let idx = 0; idx < count; idx++) {
    const input = raw.points[idx],
      converted = crs.toGcj02(input[0], input[1], "WGS84"),
      point = route.track[idx];
    const error = pilot.haversineMeters(
      { lat: converted.latitude, lon: converted.longitude },
      point,
    );
    maxError = Math.max(maxError, error);
    check(error < 0.001, "route conversion " + slug + " #" + idx);
    const direct = crs.toGcj02(point.lat, point.lon, "GCJ-02");
    check(
      direct.latitude === point.lat && direct.longitude === point.lon,
      "GCJ02 not converted twice #" + idx,
    );
    check(
      point.lat === data.points[idx][0] && point.lon === data.points[idx][1],
      "JSON and runtime geometry agree #" + idx,
    );
  }
  // Both full-route replay and input normalization are tested. Sparse replay
  // callbacks cover the entire route; the conversion loop above checks every point.
  for (const [source, inputCrs] of [
    ["host", "WGS84"],
    ["host", "GCJ02"],
    ["native", "WGS84"],
    ["native", "GCJ02"],
  ]) {
    time = startTime;
    const page = {
      _raceId: routeId,
      _nativeCoordinateSystem: inputCrs,
      _live: {
        state: "running",
        sessionId: "gcj-test",
        alongMeters: null,
        startedAt: time,
        elapsedBase: 0,
      },
      _location: {
        sessionId: "gcj-test",
        routeId,
        startedAt: time,
        nativePace: gpsPace.createGpsPaceFeed(),
        hostPace: gpsPace.createGpsPaceFeed(),
      },
    };
    let falseDeviations = 0,
      maxPixelError = 0,
      maxAlongError = 0,
      samples = 0;
    // Route-wide sampled callbacks include both ends of every GPX segment.
    const indices = [
      ...new Set([
        ...Array.from({ length: Math.ceil(count / 64) }, (_, i) => i * 64),
        ...raw.segments.flatMap(([a, b]) => [a, b - 1]),
        count - 1,
      ]),
    ].sort((a, b) => a - b);
    let previousIndex = 0;
    for (const idx of indices) {
      time += Math.max(
        1000,
        Math.ceil(
          (route.track[idx].along - route.track[previousIndex].along) / 2.5,
        ) * 1000,
      );
      previousIndex = idx;
      const w = raw.points[idx],
        g = data.points[idx],
        p = inputCrs === "WGS84" ? w : g;
      const message = {
        coords: {
          latitude: p[0],
          longitude: p[1],
          accuracy: 5,
          speed: 2.5,
          coordinateSystem: inputCrs,
        },
        timestamp: time,
      };
      const ok = locations.updateRunPosition(page, message, time, time, source);
      check(ok, "input callback accepted " + source + inputCrs);
      falseDeviations += page._live.offCourse ? 1 : 0;
      check(
        page._location.fix?.coordinateSystem === "GCJ02",
        "accepted fix carries target CRS",
      );
      maxAlongError = Math.max(
        maxAlongError,
        Math.abs((page._live.alongMeters ?? 0) - route.track[idx].along),
      );
      const expected = map.projectRoutePoint(route, route.track[idx]);
      const observed = map.projectRoutePoint(route, page._location.fix);
      if (
        Math.hypot(expected.x - observed.x, expected.y - observed.y) > 0.001
      ) {
        console.error("MISMATCH", idx, {
          input: p,
          expected: route.track[idx],
          actual: page._location.fix,
          px: expected,
          observed,
        });
        throw new Error("projection mismatch");
      }
      maxPixelError = Math.max(
        maxPixelError,
        Math.hypot(expected.x - observed.x, expected.y - observed.y),
      );
      samples++;
    }
    check(
      falseDeviations === 0,
      "no false deviation during " +
        slug +
        " " +
        source +
        " " +
        inputCrs +
        " replay",
    );
    check(
      maxAlongError < 85,
      "progress remains on correct lap: " +
        slug +
        " " +
        source +
        " " +
        inputCrs +
        " error=" +
        maxAlongError,
    );
    check(
      maxPixelError < 0.001,
      "position and rendered route projection overlap " +
        slug +
        " " +
        source +
        " " +
        inputCrs,
    );
    summary.push({
      route: slug,
      input: source + "/" + inputCrs,
      samples,
      falseDeviations,
      maxPixelError,
      maxCoordinateErrorMeters: maxError,
      maxAlongErrorMeters: maxAlongError,
    });
  }
  // Native AMap defaults to GCJ02, old host messages default to WGS84.
  for (const source of ["native", "host"]) {
    time += 20000;
    const p = source === "host" ? raw.points[0] : data.points[0];
    const page = {
      _raceId: routeId,
      _live: {
        state: "running",
        sessionId: "defaults",
        alongMeters: null,
        startedAt: time,
      },
      _location: {
        sessionId: "defaults",
        routeId,
        startedAt: time,
        nativePace: gpsPace.createGpsPaceFeed(),
        hostPace: gpsPace.createGpsPaceFeed(),
      },
    };
    locations.updateRunPosition(
      page,
      { latitude: p[0], longitude: p[1], accuracy: 5 },
      time,
      time,
      source,
    );
    check(
      pilot.haversineMeters(page._location.fix, route.track[0]) < 0.001,
      "unlabelled " + source + " uses documented default",
    );
  }
  // A true 300m departure must still warn; a CRS fix must not disable warnings.
  time += 20000;
  const origin = route.track[0];
  const departure = {
    _raceId: routeId,
    _live: {
      state: "running",
      sessionId: "off",
      alongMeters: 0,
      startedAt: time,
    },
    _location: {
      sessionId: "off",
      routeId,
      startedAt: time,
      nativePace: gpsPace.createGpsPaceFeed(),
      hostPace: gpsPace.createGpsPaceFeed(),
    },
  };
  for (let k = 0; k < 4; k++) {
    time += 2000;
    locations.updateRunPosition(
      departure,
      {
        latitude: origin.lat - 0.003,
        longitude: origin.lon - 0.003,
        accuracy: 5,
        coordinateSystem: "GCJ02",
      },
      time,
      time,
      "native",
    );
  }
  check(departure._live.offCourse, "real off-route still detected " + slug);
  const before = departure._location.fix;
  time += 2000;
  locations.updateRunPosition(
    departure,
    {
      latitude: origin.lat,
      longitude: origin.lon,
      accuracy: 5,
      coordinateSystem: "BD09",
    },
    time,
    time,
    "native",
  );
  check(
    departure._location.fix === before && departure._location.datumMismatch,
    "BD09 refused and marked unsupported " + slug,
  );
}
// Real UI selection, persistence, and data-source reset: no route snapping.
const settingsPage = make();
goToMarathonList(settingsPage);
tap(settingsPage, "昆明市跑步路线");
check(settingsPage._view === "cuihuReady" && !settingsPage._live.sessionId, "pre-race does not start tracking");
tap(settingsPage, "无需补给提醒");
tap(settingsPage, "开始跑步");
check(
  actionLabels(settingsPage).includes("坐标设置"),
  "navigation exposes input CRS selector",
);
tap(settingsPage, "坐标设置");
check(
  settingsPage._view === "coordinateSettings",
  "CRS menu opens via real key events",
);
tap(settingsPage, "原始GPS输入 WGS84");
check(
  settingsPage._nativeCoordinateSystem === "WGS84" &&
    settingsPage._view === "running" &&
    settingsPage._live.alongMeters === null,
  "source switch resets ambiguous position and returns to navigation",
);
check(
  storage.get("navigation.nativeInputCrs.v1") === "WGS84",
  "input CRS selection persists",
);
const settingsRestored = make(undefined, { keepStorage: true });
check(
  settingsRestored._nativeCoordinateSystem === "WGS84",
  "saved input mode restored on next launch",
);
// Pause and stale fixes do not drive navigation.
const ts = time;
const session = settingsPage._location;
settingsPage.pauseRun();
check(settingsPage._location === null, "pause stops continuous positioning");
settingsPage.resumeRun();
const before = settingsPage._location.fix;
check(
  locations.updateRunPosition(
    settingsPage,
    { latitude: 25, longitude: 102, accuracy: 5 },
    ts - 30000,
    time,
    "host",
  ) === false,
  "stale data rejected",
);
check(settingsPage._location.fix === before, "stale fix cannot change marker");
const half = pilot.getBuiltinRoute(pilot.KUNMING_HALF_ID);
check(
  half.waypoints.map((p) => p.minute).join() === "30,45,60,90,105,120,140",
  "seven fueling times preserved",
);
for (const w of half.waypoints) {
  const found = pilot.locateOnRoute(half, w.lat, w.lon, w.along, {
    accuracy: 5,
  });
  check(!found.offCourse, "fuel point remains on transformed route");
}
const assetRoot = path.join(root, "assets");
for (const name of ["kunming-half-route.png", "kunming-route.png"])
  check(
    fs
      .readFileSync(path.join(assetRoot, name))
      .subarray(0, 8)
      .toString("hex") === "89504e470d0a1a0a",
    "valid offline map " + name,
  );
// Compare the accelerated search with the full segment-by-segment reference.
// Cover initial acquisition, loop progress, bends, and points well off route.
for (const id of [pilot.CUIHU_PILOT_ID, pilot.KUNMING_HALF_ID]) {
  const route = pilot.getBuiltinRoute(id);
  const reference = { ...route, blocks: null };
  for (const fraction of [0, .01, .15, .45, .8, .99, 1]) {
    const sample = route.track[Math.floor((route.track.length - 1) * fraction)];
    for (const [dx, dy] of [[0,0], [.0002,0], [.0005,-.0008], [.002,.003]]) {
      for (const along of [undefined, sample.along]) {
        const args = [sample.lat+dy, sample.lon+dx, along, {accuracy:6, heading:90}];
        const fast = pilot.locateOnRoute(route, ...args);
        const full = pilot.locateOnRoute(reference, ...args);
        check(JSON.stringify(fast) === JSON.stringify(full), "indexed match agrees with full track");
      }
    }
  }
}
const diagPage = make();
goToMarathonList(diagPage);
tap(diagPage, "昆明市跑步路线");
check(diagPage._view === "cuihuReady" && !diagPage._live.sessionId, "pre-race does not start tracking");
tap(diagPage, "无需补给提醒");
tap(diagPage, "开始跑步");
const diagRoute = pilot.getBuiltinRoute(pilot.CUIHU_PILOT_ID);
const original = JSON.parse(fs.readFileSync(path.join(root,"assets/routes/cuihu.wgs84.json"))).points[0];
const sendNative = (coords, accuracy = 5, declared) => {
  time += 2000;
  locations.updateRunPosition(diagPage, {coords:{latitude:coords[0], longitude:coords[1],
    accuracy, coordinateSystem:declared}}, time, time, "native");
  diagPage.render();
};
sendNative(original);
tap(diagPage,"坐标设置");
check(/按 WGS84 0m/.test(diagPage.data.next) && !/按 GCJ02 0m/.test(diagPage.data.next),
  "known raw-GPS start distinguishes the two input modes");
const start = diagRoute.track[0];
sendNative([start.lat,start.lon]);
check(/按 GCJ02 0m/.test(diagPage.data.next) && !/按 WGS84 0m/.test(diagPage.data.next),
  "known AMap start distinguishes the two input modes");
sendNative([start.lat,start.lon],5,"GCJ02");
check(diagPage.data.next.includes("已声明 GCJ02"), "declared datum overrides the manual choice");
tap(diagPage,"返回导航");
sendNative([start.lat+0.00023,start.lon-0.00008],5,"GCJ02");
check(diagPage.data.mapRunnerStyle === map.cuihuMapData(diagRoute,diagPage._location.fix,diagPage._live.routeNavigation).mapRunnerStyle,
  "runner marker uses observed location");
sendNative([start.lat,start.lon],90);
check(!diagPage.data.mapRunnerStyle && !diagPage.data.navCoordinate.includes("距轨迹"),
  "weak fix hides stale distances as well as the marker");
// Exercise all three choices through the real menu with simulated device interfaces.
const fuel = modules.get(path.join(root,"utils/cuihuFuel.js")).namespace;
const input = modules.get(path.join(root,"utils/cuihuPlanInput.js")).namespace;
const tick = ()=>new Promise(resolve=>setImmediate(resolve));
const track = pilot.cuihuPilot.track;
const expectedMeters = [200,500,1000,2000,3000,5000];
const choices = ["大模型生成常规补给建议","无需补给提醒","微信迈胜 · 胜算专属方案"];
function selectCuihu() {
  const page=make();
  goToMarathonList(page);tap(page,"昆明市跑步路线");
  check(page.data.title==="个人补给方案" && actionLabels(page).join()===choices.join() && !page._live.sessionId,"route opens the three plan choices directly");
  return page;
}
const events=[], speeches=[];
context.Blob=Blob;
context.crypto={getRandomValues(bytes){events.push("code");bytes[0]=42680;return bytes;}};
let rejectPhoto=false;
wx.media={createCameraContext(){return {async takePhoto(options){
  events.push("photo");check(options.mode==="telephoto" && options.quality==="high","use document camera mode");
  if(rejectPhoto)throw Object.assign(Error("denied"),{name:"NotAllowedError"});
  return {data:Uint8Array.from([12,34,56,78]),mimeType:"image/jpeg"};
}}}};
wx.arrayBufferToBase64=buf=>Buffer.from(buf).toString("base64");
wx.speech={playTTS(text){speeches.push(text)}};
let modelReply, requests=[];
function installModel(){
 context.LanguageModel={availability:async()=>"available",create:async({initialPrompts})=>{
  events.push("model");
  check(initialPrompts[0].role==="system","model initialized with task instructions");
  return {async prompt(arg){requests.push(arg);events.push("prompt");return typeof modelReply==="function"?await modelReply():JSON.stringify(modelReply)}, destroy(){events.push("destroy");}};
 }};
}
const silent=selectCuihu();tap(silent,choices[1]);
check(!silent._live.sessionId && silent._view==="fuelStart","no reminders still requires an explicit start");
tap(silent,"开始跑步");silent._live.aidAlert=true;silent.render();
check(silent._view==="running" && silent.data.cuihuHud && !silent.data.hudFuel && !silent.data.fuelBanner && !silent._fuelRun && !actionLabels(silent).includes("去补给") && !events.length && !speeches.length,"silent run retains navigation without fuel HUD, alerts, camera, model or speech");
const general=selectCuihu();tap(general,choices[0]);await tick();
check(general._view==="fuelAI" && general.data.next.includes("不可用") && !general._fuelDraft,"missing model allows retry without creating a plan");
installModel();
modelReply={complete:true,basis:"cumulative",courseMeters:5000,points:[{meters:1400,items:["留意是否口渴，按需饮水"]}]};
tap(general,"重新生成");await tick();
check(general._view==="fuelReview" && general._fuelDraft[0].meters===1400 && !general._fuelDraftCode && !general._fuelStops.length && typeof requests.at(-1)==="string" && !events.includes("photo"),"real text-prompt result populates general draft without camera or code");
tap(general,"采用常规建议");check(!general._live.sessionId && general._fuelStops[0].notes[0].includes("按需饮水"),"general suggestion explicitly adopted before start");
tap(general,"使用当前方案开跑");check(general._view==="running" && general._fuelRun.stops[0].meters===1400,"general plan starts with its own generated checkpoint");

const deferred=selectCuihu();let finishOld;
modelReply=()=>new Promise(resolve=>{finishOld=resolve});
tap(deferred,choices[0]);await tick();tap(deferred,"返回选择");tap(deferred,choices[1]);
finishOld(JSON.stringify({complete:true,basis:"cumulative",courseMeters:null,points:[{meters:100,items:["按需饮水"]}]}));await tick();
check(deferred._view==="fuelStart" && !deferred._fuelStops.length && !deferred._fuelDraft && !deferred._fuelDraftCode,"stale completion cannot replace newly selected silent mode");
const segments={complete:true,basis:"segments",courseMeters:5000,endsAtFinish:true,points:[
 {meters:200,items:["迈胜清酸片 PRO 1片"]},{meters:300,items:["按方案补水"]},
 {meters:500,items:["迈胜续航机能胶 PRO 1袋"]},{meters:1000,items:["迈胜液体盐丸 1袋"]},
 {meters:1000,items:["迈胜电解质浓缩液 PRO 1袋，兑水分次饮用"]},
 {meters:2000,items:["迈胜续航机能胶 PRO 1袋","迈胜液体盐丸 1袋"]}
]};
assert.throws(()=>input.parseModelPlan(JSON.stringify({...segments,courseMeters:21100}),true),/不匹配/);
assert.throws(()=>input.parseModelPlan(JSON.stringify({...segments,points:segments.points.slice(0,-1)}),true),/不符/);
assert.throws(()=>input.parseModelPlan(JSON.stringify({...segments,points:[{meters:500,items:[]}]}),true),/内容/);
assert.throws(()=>input.parseModelPlan("{}",true),/未读全/);
const paired=selectCuihu();events.length=0;requests=[];
tap(paired,choices[2]);check(paired._view==="fuelImport" && paired.data.fuelLinkCard && !paired._fuelDraftCode && !events.length && !paired._live.sessionId,"static sun entry precedes photo and code");
rejectPhoto=true;tap(paired,"拍照识别赛中方案");await tick();
check(paired.data.detail.includes("相机权限") && !paired._fuelDraftCode && !requests.length,"denied camera cannot generate code or request model");
rejectPhoto=false;modelReply={complete:false};
tap(paired,"拍照识别赛中方案");await tick();
check(paired._view==="fuelImport" && paired.data.detail.includes("未读全") && !paired._fuelDraftCode && !paired._fuelStops.length,"unreadable photo cannot generate a binding");
tap(paired,"按照片校正录入");
paired.onFuelText({detail:{value:"7.5公里 测试条目"}});tap(paired,"核对点位");
check(paired.data.detail.includes("超出") && !paired._fuelDraftCode,"manual correction rejects out-of-route entry");
paired.onFuelText({detail:{value:"12分钟 测试条目乙\n1公里 测试条目甲\n2公里 测试条目丙"}});tap(paired,"核对点位");
check(paired.data.detail.includes("配速"),"time entries require explicit pace");
paired.onFuelPace({detail:{value:"6:00"}});tap(paired,"核对点位");
check(paired._view==="fuelReview" && paired._fuelDraftCode==="042680" && !paired._fuelStops.length && paired._fuelDraft.length===2,"explicit correction of captured plan can be reviewed");
tap(paired,"查看下一个点");check(paired.data.detail.includes("12分") && paired.data.next.includes("2 公里"),"time provenance remains available");
tap(paired,"下一段原文");check(paired.data.next.includes("测试条目丙"),"same-distance manual products remain individually reviewable");
tap(paired,"重新拍照");events.length=0;
check(!paired._fuelDraftCode && !paired._fuelDraft && !paired._fuelStops.length,"reshooting clears prior plan and binding");
tap(paired,"长图分屏拍摄");
tap(paired,"拍摄第 1 张");await tick();tap(paired,"拍摄第 2 张");await tick();
check(events.join()==="photo,photo" && !paired._fuelDraftCode && paired._fuelPhotos.length===2,"multi-frame mode captures pages before recognition or binding");
modelReply=segments;tap(paired,"完成拍照并识别");await tick();
const images=requests.at(-1)[0].content.filter(item=>item.type==="image_url");
check(images.length===2 && images.every(item=>item.image_url.url==="data:image/jpeg;base64,DCI4Tg=="),"actual camera bytes and MIME type passed as two image messages");
check(events.indexOf("code")>events.indexOf("prompt") && events.filter(e=>e==="code").length===1 && !paired._fuelPhotos.length,"binding code generated only after recognition and photos released");
check(paired._view==="fuelReview" && paired.data.eyebrow.includes("042680") && !paired._fuelStops.length && !paired._live.sessionId,"review shows new six-digit code before bind or start");
check(paired._fuelDraft.map(p=>p.meters).join()===expectedMeters.join(),"six segment distances mapped into actual cumulative positions");
tap(paired,"确认绑定");check(paired._view==="fuelStart" && !paired._live.sessionId && paired.data.detail.includes("042680") && paired._fuelBoundCode==="042680","confirmation binds the reviewed code without starting");
tap(paired,"使用当前方案开跑");check(paired._view==="running" && paired._fuelRun && paired._live.sessionId,"only explicit start enables active run");

const arrivals=[];
let courseMeters=0;
for(let i=0;i<track.length;i++){
 const p=track[i];time+=Math.max(500,Math.round((p.along-courseMeters)*500));courseMeters=p.along;
 const coords={latitude:p.lat,longitude:p.lon,accuracy:6,speed:2,coordinateSystem:"GCJ02"};
 locations.updateRunPosition(paired,{coords},time,time,"native");paired.render();
 const station=paired._fuelRun.pending;
 if(!station)continue;
 arrivals.push(station.meters);
 check(paired.data.fuelBanner && paired.data.fuelProduct1===station.notes[0],"HUD shows full product at "+station.meters+" metres");
 check(Math.abs(paired._live.alongMeters-station.meters)<40,"on-distance match at "+station.meters);
 for(const note of station.notes)check(speeches.at(-1).includes(note),"voice includes product and quantity "+note);
 if(station.meters===500)check(station.notes.length===1 && paired.data.fuelProduct1==="按方案补水","no product invented at the second station");
 if(station.meters===5000)check(paired.data.fuelProduct2===station.notes[1] && station.notes.length===2,"both finish products visible on HUD");
 paired.render();paired.render();tap(paired,"补给详情");tap(paired,"已补给");
}
check(arrivals.join()===expectedMeters.join() && speeches.length===6 && paired._live.aids===6,"six unique on-route visual and voice reminders including finish");

tap(paired,"结束");check(paired._record.aids===6,"end record counts actual confirmed stops");
const nextRunner=selectCuihu();check(!nextRunner._fuelDraftCode && !nextRunner._fuelStops.length,"next runner starts fresh");
check(input.parseModelPlan(JSON.stringify({...segments,endsAtFinish:false,points:segments.points.slice(0,-1)}),true).at(-1).meters===3000,"last planned reminder can legitimately precede finish");
tap(nextRunner,choices[2]);tap(nextRunner,"拍照识别赛中方案");await tick();
check(nextRunner._view==="fuelReview" && nextRunner._fuelDraft.length===6 && requests.at(-1)[0].content.length===2 && !nextRunner._live.sessionId,"single photo succeeds through the primary button");
const gates=modules.get(path.join(root,"utils/cuihuFuelUI.js")).namespace;
const bindStops=fuel.buildStations(fuel.parsePlan("1公里 测试条目甲\n2公里 测试条目乙"),track);
const mockPage={_view:"running",_raceId:pilot.CUIHU_PILOT_ID,_fuelRun:fuel.newDistanceRun(bindStops),_live:{state:"running",routeMatchedAt:time,routeNavigation:{along:1003}},_location:{fix:{timestamp:time,accuracy:6}}};
function quiet(apply,undo,msg){apply();gates.observeFuel(mockPage,time);check(!mockPage._fuelRun.pending,msg);undo();}
quiet(()=>mockPage._live.state="paused",()=>mockPage._live.state="running","pause suppresses trigger");
quiet(()=>mockPage._location.weakAt=time,()=>mockPage._location.weakAt=null,"weak GPS suppresses trigger");
quiet(()=>mockPage._live.routeNavigation.offCourse=true,()=>mockPage._live.routeNavigation.offCourse=false,"off-course fix suppresses trigger");
quiet(()=>mockPage._location.deviation={},()=>mockPage._location.deviation=null,"unconfirmed deviation suppresses trigger");
quiet(()=>mockPage._live.routeNavigation.parallelRoute=true,()=>mockPage._live.routeNavigation.parallelRoute=false,"ambiguous parallel path suppresses trigger");
quiet(()=>mockPage._hidden=true,()=>mockPage._hidden=false,"hidden app suppresses trigger");
quiet(()=>mockPage._raceId=pilot.KUNMING_HALF_ID,()=>mockPage._raceId=pilot.CUIHU_PILOT_ID,"half marathon cannot fire Cuihu stations");
gates.observeFuel(mockPage,time+15000);check(!mockPage._fuelRun.pending,"expired fix suppresses trigger");
const missed=fuel.newDistanceRun(bindStops);fuel.crossStations(missed,0,0);fuel.crossStations(missed,1650,300000);
check(missed.skipped===1 && !missed.pending,"reacquisition far beyond a station does not prompt retroactive consumption");
const repeat=fuel.newDistanceRun(bindStops);fuel.crossStations(repeat,995,1);fuel.crossStations(repeat,1001,2001);repeat.pending=null;
check(!fuel.crossStations(repeat,990,4001) && !fuel.crossStations(repeat,1002,6001) && repeat.next===1,"backtracking and jitter do not retrigger consumption");
context.GPXDocument=class{constructor(){this.w=[]}addWaypoint(p){this.w.push(p)}toString(){return JSON.stringify(this.w)}};
check(JSON.parse(gates.fuelMapXml({_raceId:pilot.CUIHU_PILOT_ID,_fuelStops:bindStops})).length===2,"two GPX waypoints for the confirmed personal plan");
context.speechSynthesis={speak(utterance){speeches.push(utterance.text)}};
context.SpeechSynthesisUtterance=class{constructor(text){this.text=text}};
delete wx.speech;
const voiceRun=fuel.newDistanceRun(bindStops);
mockPage._fuelRun=voiceRun;gates.observeFuel(mockPage,time+1);
mockPage._location.fix.timestamp=mockPage._live.routeMatchedAt=time+2;
gates.observeFuel(mockPage,time+2);
check(speeches.length===7 && speeches.at(-1).includes(bindStops[0].notes[0]),"documented Web TTS fallback reads station");

delete wx.media;delete wx.speech;
fs.writeFileSync(
  path.join(root, "verification/gcj02-results.json"),
  JSON.stringify({ passed, summary }, null, 2),
);
console.log(JSON.stringify({ passed, summary }, null, 2));
