<script def>
{
  "navigationBarTitleText": "越野跑向导",
  "description": "打开越野跑向导首页。镜腿滑动选项、单击确认，按步骤完成准备、开跑和复盘。",
  "schema": {
    "data": {
      "type": "object",
      "properties": {},
      "additionalProperties": false
    }
  }
}
</script>
<script setup>
import { trail } from '../../utils/trailScreen.js';
export default trail;
</script>
<page>
  <view class="hud {{compactMenu ? 'compact-menu' : ''}} {{cuihuHud ? 'cuihu-hud' : ''}}">
    <view class="cuihu-navigation" ink:if="{{cuihuHud}}">
      <view class="cuihu-directions">
        <view class="cuihu-guide">
          <image class="cuihu-arrow" ink:if="{{navIcon}}" src="{{navIcon}}" mode="aspectFit" />
          <view class="cuihu-maneuver">
            <text class="cuihu-distance" ink:if="{{navDistance}}">{{navDistance}}</text>
            <text class="cuihu-instruction {{navDistance ? 'cuihu-instruction-small' : ''}}">{{navInstruction}}</text>
          </view>
        </view>
        <view class="cuihu-position">
          <text class="cuihu-status {{navWarning ? 'cuihu-status-warn' : ''}}">{{navStatus}}</text>
          <text class="cuihu-progress" ink:if="{{navProgress}}">{{navProgress}}</text>
        </view>
        <text class="cuihu-coordinate">{{navCoordinate}}</text>
      </view>
      <view class="cuihu-map">
        <image class="cuihu-map-route" src="{{mapRouteAsset}}" mode="aspectFit" />
        <view class="cuihu-map-target" ink:if="{{mapTargetStyle}}" style="{{mapTargetStyle}}"></view>
        <view class="cuihu-map-runner {{mapRunnerClamped ? 'cuihu-map-runner-edge' : ''}}" ink:if="{{mapRunnerStyle}}" style="{{mapRunnerStyle}}"></view>
      </view>
    </view>
    <view class="cuihu-open-space" ink:if="{{cuihuHud}}"></view>
    <view class="fuel-banner" ink:if="{{cuihuHud && fuelBanner}}">
      <text class="fuel-banner-title">{{hudFuelLabel}}　{{fuelAudioHint}}</text>
      <text class="fuel-banner-line">{{fuelProduct1}}</text>
      <text class="fuel-banner-line" ink:if="{{fuelProduct2}}">{{fuelProduct2}}</text>
    </view>
    <view class="cuihu-metrics" ink:if="{{cuihuHud && !fuelBanner}}">
      <view class="cuihu-metric cuihu-heart">
        <view class="cuihu-metric-heading">
          <text class="cuihu-metric-label">心率</text>
          <text class="cuihu-source" ink:if="{{hudHeartSource}}">{{hudHeartSource}}</text>
        </view>
        <view class="cuihu-reading">
          <text class="cuihu-value">{{hudHeartRate}}</text>
          <text class="cuihu-unit">bpm</text>
        </view>
      </view>
      <view class="cuihu-metric cuihu-pace">
        <view class="cuihu-metric-heading">
          <text class="cuihu-metric-label">配速</text>
          <text class="cuihu-source" ink:if="{{hudPaceSource}}">{{hudPaceSource}}</text>
        </view>
        <view class="cuihu-reading">
          <text class="cuihu-value">{{hudPace}}</text>
          <text class="cuihu-unit">分/公里</text>
        </view>
      </view>
      <view class="cuihu-metric cuihu-fuel" ink:if="{{hudFuel}}">
        <text class="cuihu-metric-label">{{hudFuelLabel}}</text>
        <text class="cuihu-fuel-text">{{hudFuel}}</text>
      </view>
    </view>
    <view class="preview" ink:if="{{previewOpen}}">
      <text class="title">{{title}}</text>
      <map ink:if="{{previewReady}}" style="width: 256px; height: 84px;" latitude="{{previewLat}}" longitude="{{previewLon}}" zoom="{{previewZoom}}" map-style='{"background":"#000000"}'>
        <template slot="overlays">
          <map-gpx data="{{overlayFirst}}" stroke-color="#8affaa" start-color="#68e68c" end-color="#afffc6" stroke-width="2" point-radius="2" label-visible="{{false}}" />
          <map-gpx ink:if="{{overlaySecond}}" data="{{overlaySecond}}" stroke-color="#8affaa" start-color="#68e68c" end-color="#afffc6" stroke-width="2" point-radius="2" label-visible="{{false}}" />
          <map-gpx ink:if="{{overlayFuel}}" data="{{overlayFuel}}" waypoint-color="#8affaa" point-radius="3" label-visible="{{false}}" />
          <map-gpx ink:if="{{overlayMarker}}" data="{{overlayMarker}}" waypoint-color="#ffffff" point-radius="4" label-visible="{{false}}" />
        </template>
      </map>
      <image ink:if="{{!previewReady}}" class="preview-fallback" src="{{previewFallback}}" mode="aspectFit" />
      <text class="detail">{{next}}</text>
    </view>
    <view class="heading" ink:if="{{!cuihuHud && !previewOpen}}">
      <text class="eyebrow">{{eyebrow}}</text>
      <text class="title">{{title}}</text>
    </view>
    <view class="fuel-link-card" ink:if="{{fuelLinkCard}}">
      <image class="fuel-sun" src="/assets/fuel/shengsuan-sun.png" mode="aspectFit" />
      <view class="fuel-link-text">
        <text class="next">{{next}}</text>
        <text class="fuel-pair">微信胜算 · 静态入口</text>
        <text class="hint">{{detail}}</text>
      </view>
    </view>
    <view class="readout" ink:if="{{!cuihuHud && !previewOpen && !fuelLinkCard}}">
      <view class="primary">
        <view class="hero-block {{tone}}" ink:if="{{hero || heroLabel}}">
          <text class="hero">{{hero}}</text>
          <text class="hero-label" ink:if="{{heroLabel}}">{{heroLabel}}</text>
        </view>
        <text class="next" ink:if="{{next}}">{{next}}</text>
        <text class="detail" ink:if="{{detail}}">{{detail}}</text>
        <text class="hint" ink:if="{{hint}}">{{hint}}</text>
      </view>
    </view>
    <view class="metrics" ink:if="{{showMetrics && !cuihuHud}}">
      <view class="metric">
        <text class="metric-value">{{metric0}}</text>
        <text class="metric-label">{{metric0Label}}</text>
      </view>
      <view class="metric">
        <text class="metric-value">{{metric1}}</text>
        <text class="metric-label">{{metric1Label}}</text>
      </view>
      <view class="metric">
        <text class="metric-value">{{metric2}}</text>
        <text class="metric-label">{{metric2Label}}</text>
      </view>
      <view class="metric">
        <text class="metric-value">{{metric3}}</text>
        <text class="metric-label">{{metric3Label}}</text>
      </view>
    </view>
    <view class="fuel-editor" ink:if="{{fuelEditor}}">
      <textarea class="fuel-field fuel-lines" value="{{fuelText}}" placeholder="每行如：1.5公里 补给原文" maxLength="12000" bindinput="onFuelText" />
      <input class="fuel-field" value="{{fuelPace}}" placeholder="目标配速 分:秒（按分钟时填写）" maxLength="5" bindinput="onFuelPace" />
    </view>
    <view class="actions">
      <view class="{{class0}}" bindtap="tapAction0" ink:if="{{has0}}"><text class="action-label">{{action0}}</text></view>
      <view class="{{class1}}" bindtap="tapAction1" ink:if="{{has1}}"><text class="action-label">{{action1}}</text></view>
      <view class="{{class2}}" bindtap="tapAction2" ink:if="{{has2}}"><text class="action-label">{{action2}}</text></view>
      <view class="{{class3}}" bindtap="tapAction3" ink:if="{{cuihuHud && has3}}"><text class="action-label">{{action3}}</text></view>
    </view>
    <view class="footer" ink:if="{{canBack || pageInfo}}">
      <view class="footer-navigation">
        <view class="soft-key" bindtap="goBack" ink:if="{{canBack}}"><text class="footer-label">{{backLabel}}</text></view>
        <view class="soft-key home-key" bindtap="goHome" ink:if="{{canHome}}"><text class="footer-label">首页</text></view>
      </view>
      <view class="pagination" ink:if="{{pageInfo}}">
        <view class="soft-key" bindtap="prevPage"><text class="footer-label">上页</text></view>
        <text class="footer-label page-info">{{pageInfo}}</text>
        <view class="soft-key" bindtap="nextPage"><text class="footer-label">下页</text></view>
      </view>
    </view>
  </view>
</page>
<style>
.fuel-editor { display: flex; flex-direction: column; }
.fuel-field { color: #b5ffca; background-color: #08190d; border: 1px solid #267c42; height: 23px; font-size: 13px; }
.fuel-lines { height: 36px; }
.preview { display: flex; flex-direction: column; align-items: center; }
.preview-fallback { width: 256px; height: 84px; }
.hud { display: flex; flex-direction: column; width: 100%; height: 100%; padding: 9px 17px 7px; box-sizing: border-box; background-color: #000000; }
.heading { display: flex; flex-direction: column; padding-bottom: 4px; border-bottom: 1px solid #267c42; }
.eyebrow { display: block; color: #79ef9b; font-size: 13px; line-height: 17px; }
.title { display: block; color: #a6ffc0; font-size: 20px; line-height: 24px; font-weight: bold; }
.readout { display: flex; flex-direction: row; align-items: center; padding-top: 4px; padding-bottom: 5px; }
.primary { display: flex; flex: 1; min-width: 0; flex-direction: column; }
.hero-block { display: flex; flex-direction: column; padding: 1px 0 2px 8px; border-left: 2px solid #49ff7e; }
.hero-block.warn { border-left: 5px solid #a6ffc0; }
.hero { display: block; color: #acffc5; font-size: 40px; line-height: 44px; font-weight: bold; }
.hero-label { display: block; color: #8affaa; font-size: 17px; line-height: 20px; font-weight: bold; }
.next { display: block; margin-top: 3px; color: #a1ffba; font-size: 17px; line-height: 21px; font-weight: bold; }
.detail { display: block; color: #7df39e; font-size: 15px; line-height: 19px; }
.hint { display: block; color: #77e69a; font-size: 13px; line-height: 17px; }
.metrics { display: flex; flex-direction: row; margin: 2px 0 6px; }
.metric { display: flex; flex: 1; min-width: 0; flex-direction: column; padding: 2px 4px; margin-right: 3px; border: 1px solid #267c42; border-radius: 3px; }
.metric-value { display: block; color: #acffc5; font-size: 13px; line-height: 17px; font-weight: bold; }
.metric-label { display: block; color: #77e69a; font-size: 11px; line-height: 14px; }
.actions { display: flex; flex-direction: column; }
.action { display: flex; flex-direction: row; align-items: center; min-height: 27px; padding: 1px 8px; margin-bottom: 3px; border: 1px solid #267c42; border-radius: 3px; }
.focused { border: 2px solid #8affaa; background-color: #102e1b; }
.action-label { color: #a6ffc0; font-size: 16px; line-height: 21px; }
.footer { display: flex; flex-direction: row; align-items: center; justify-content: space-between; }
.footer-navigation { display: flex; flex-direction: row; align-items: center; }
.home-key { margin-left: 7px; }
.pagination { display: flex; flex-direction: row; align-items: center; }
.soft-key { padding: 2px 8px; border: 1px solid #267c42; }
.footer-label { color: #77e69a; font-size: 13px; line-height: 17px; }
.page-info { margin-left: 7px; margin-right: 7px; }
@media (max-height: 185px) {
  .hud { padding: 3px 10px; }
  .heading { flex-direction: row; align-items: center; padding-bottom: 1px; }
  .eyebrow { font-size: 11px; line-height: 15px; margin-right: 8px; }
  .title { font-size: 16px; line-height: 21px; }
  .hero-block { flex-direction: row; align-items: center; padding: 0 0 0 4px; }
  .hero { font-size: 16px; line-height: 18px; }
  .hero-label { font-size: 12px; line-height: 16px; margin-left: 6px; }
  .compact-menu .hero-block { display: none; }
  .readout { padding-top: 2px; padding-bottom: 2px; }
  .compact-menu .readout { padding-top: 1px; padding-bottom: 1px; }
  .next { margin-top: 0; font-size: 14px; line-height: 17px; }
  .detail { font-size: 12px; line-height: 15px; }
  .hint { font-size: 11px; line-height: 13px; }
  .metrics { margin: 1px 0 3px; }
  .metric { padding: 0 3px; }
  .metric-value { font-size: 11px; line-height: 14px; }
  .metric-label { font-size: 10px; line-height: 12px; }
  .action { min-height: 20px; padding: 0 6px; margin-bottom: 2px; }
  .action-label { font-size: 13px; line-height: 17px; }
  .footer-label { font-size: 11px; line-height: 13px; }
  .soft-key { padding: 0 5px; }
}
.hud.cuihu-hud { padding: 9px 14px 6px; }
.cuihu-navigation { display: flex; flex-shrink: 0; flex-direction: row; align-items: flex-start; }
.cuihu-directions { display: flex; flex: 1; min-width: 0; flex-direction: column; }
.cuihu-guide { display: flex; flex-direction: row; align-items: center; min-height: 50px; }
.cuihu-arrow { display: block; flex-shrink: 0; width: 42px; height: 42px; margin-right: 6px; }
.cuihu-maneuver { display: flex; flex: 1; min-width: 0; flex-direction: column; }
.cuihu-distance { display: block; color: #b5ffca; font-size: 28px; line-height: 33px; font-weight: bold; }
.cuihu-instruction { display: block; color: #b5ffca; font-size: 20px; line-height: 25px; font-weight: bold; }
.cuihu-instruction-small { color: #92f6ae; font-size: 14px; line-height: 18px; font-weight: normal; }
.cuihu-position { display: flex; flex-direction: row; align-items: center; margin-top: 2px; }
.cuihu-status { display: block; color: #92f6ae; font-size: 13px; line-height: 18px; }
.cuihu-status-warn { color: #d0ffdc; font-weight: bold; }
.cuihu-progress { display: block; margin-left: 9px; color: #92f6ae; font-size: 13px; line-height: 17px; }
.cuihu-coordinate { display: block; color: #92f6ae; font-size: 11px; line-height: 14px; }
.cuihu-map { position: relative; flex-shrink: 0; width: 104px; height: 84px; margin-left: 6px; }
.cuihu-map-route { display: block; width: 104px; height: 84px; }
.cuihu-map-runner { position: absolute; box-sizing: border-box; width: 8px; height: 8px; border: 1px solid #08190d; border-radius: 4px; background-color: #d0ffdc; }
.cuihu-map-runner-edge { border: 2px solid #d0ffdc; background-color: #000000; }
.cuihu-map-target { position: absolute; box-sizing: border-box; width: 10px; height: 10px; border: 2px solid #b5ffca; border-radius: 5px; }
.cuihu-open-space { flex: 1; }
.cuihu-metrics { display: flex; flex-direction: row; align-items: flex-start; }
.cuihu-metric { display: flex; min-width: 0; flex-direction: column; }
.cuihu-heart { width: 22%; }
.cuihu-pace { width: 29%; }
.cuihu-fuel { flex: 1; }
.cuihu-metric-heading { display: flex; flex-direction: row; align-items: center; }
.cuihu-metric-label { display: block; color: #92f6ae; font-size: 13px; line-height: 17px; }
.cuihu-source { display: block; margin-left: 6px; color: #7cda98; font-size: 11px; line-height: 16px; }
.cuihu-reading { display: flex; flex-direction: row; align-items: flex-end; }
.cuihu-value { display: block; flex-shrink: 0; color: #b5ffca; font-size: 25px; line-height: 30px; font-weight: bold; }
.cuihu-heart .cuihu-value { width: 49px; }
.cuihu-pace .cuihu-value { width: 87px; }
.cuihu-unit { display: block; flex-shrink: 0; width: 42px; margin-bottom: 3px; color: #92f6ae; font-size: 10px; line-height: 14px; }
.cuihu-fuel-text { display: block; color: #b5ffca; font-size: 16px; line-height: 24px; }
.cuihu-hud .actions { flex-direction: row; justify-content: space-between; margin-top: 4px; }
.cuihu-hud .action { flex: 1; min-width: 0; min-height: 24px; justify-content: center; margin: 0 8px 0 0; padding: 0; border: none; border-radius: 0; }
.cuihu-hud .focused { background-color: transparent; border-bottom: 1px solid #b5ffca; }
.cuihu-hud .action-label { color: #8ce9a7; font-size: 13px; line-height: 18px; }
.cuihu-hud .focused .action-label { color: #d0ffdc; font-weight: bold; }
@media (max-height: 185px) {
  .hud.cuihu-hud { padding: 4px 10px 3px; }
  .cuihu-guide { min-height: 43px; }
  .cuihu-arrow { width: 37px; height: 37px; margin-right: 5px; }
  .cuihu-distance { font-size: 23px; line-height: 27px; }
  .cuihu-instruction { font-size: 17px; line-height: 22px; }
  .cuihu-instruction-small { font-size: 12px; line-height: 16px; }
  .cuihu-status { font-size: 11px; line-height: 15px; }
  .cuihu-progress { font-size: 11px; line-height: 14px; }
  .cuihu-metric-label { font-size: 11px; line-height: 13px; }
  .cuihu-source { font-size: 10px; line-height: 12px; }
  .cuihu-value { font-size: 21px; line-height: 22px; }
  .cuihu-heart .cuihu-value { width: 43px; }
  .cuihu-pace .cuihu-value { width: 77px; }
  .cuihu-unit { margin-bottom: 2px; }
  .cuihu-fuel-text { font-size: 14px; line-height: 21px; }
  .cuihu-hud .actions { margin-top: 3px; }
  .cuihu-hud .action { min-height: 20px; }
  .cuihu-hud .action-label { font-size: 12px; line-height: 16px; }
}
.fuel-link-card { display: flex; flex-direction: row; align-items: center; margin: 2px 0; }
.fuel-sun { width: 93px; height: 93px; flex-shrink: 0; margin-right: 10px; background-color: #fff; }
.fuel-link-text { display: flex; flex: 1; flex-direction: column; }
.fuel-pair { color: #bcffca; font-size: 23px; font-weight: bold; }
.fuel-banner { display: flex; flex-direction: column; border-left: 3px solid #afffc6; padding-left: 7px; }
.fuel-banner-title { color: #8affaa; font-size: 12px; line-height: 14px; }
.fuel-banner-line { color: #c5ffd1; font-size: 16px; line-height: 19px; font-weight: bold; }
@media (max-height: 185px) {
  .fuel-sun { width: 56px; height: 56px; }
  .fuel-pair { font-size: 17px; line-height: 19px; }
  .fuel-banner-line { font-size: 13px; line-height: 15px; }
}
</style>
