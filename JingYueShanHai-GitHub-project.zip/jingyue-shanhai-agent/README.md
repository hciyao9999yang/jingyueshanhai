# 镜越山海 · 机场接驳 Agent

运行于 Rokid AIUI 的机场接驳演示项目，当前版本 **v14.3-localmap**。

从眼镜领取点出发，帮助用户选择出租车、机场大巴、网约车或地铁，分步前往机场内接驳点，随后展示乘坐方案。位置由用户确认，不依赖 Intellect 后端，不修改乐奇手机 App。

> 当前使用模拟机场点位和交通数据，不能用于实地导航。源码和 AIX 打包检查已完成，AIUI 平台接受情况与眼镜显示仍需实测。本仓库的打包脚本按照已提供 AIX 的 ZIP 源码结构重新封装，不是 Rokid 官方编译器或签名工具。

## 先做哪一步

- **上传到 GitHub**：看 [中文上传说明](docs/GITHUB_UPLOAD.md)。
- **运行后得到 AIX**：推送代码后打开 GitHub 的 Actions，下载 `JingYueShanHai-AIX` 构建产物。
- **本地直接打包**：运行下面两条 Python 命令。
- **继续修改功能**：主要修改 `pages/index/index.ink` 和 `utils/mapData.js`。

GitHub 用于管理源码、协作与自动打包。眼镜运行仍需将 AIX 上传到你已使用的 AIUI/真机测试入口；本项目不是 GitHub Pages 网站，也未验证 AIUI 是否支持直接从 GitHub 导入。

## 这一版如何显示地图

路线图片随 Agent 一起打包，页面通过本地 `image` 组件显示 PNG。用户确认到达下一节点后，程序切换相应图片；“走错了”后重新规划并选择新的图片。

- 图中 **1**：最后确认的位置。
- 图中 **2**：下一目标节点。
- 明亮粗线：当前步骤；较暗细线：本层后续路线。
- 跨楼层步骤：单独的换层连接示意，不把两层当成一张平面图。
- 默认只展示路线和当前动作；“说明”展开完整描述。

这是一组由模拟节点生成的路线示意图，不是真实机场平面图，不包含室内实时定位。当前数据生成 210 张路线状态图片。

## 本地构建

环境：Node.js 24、Python 3.12。Python 依赖锁定在 `requirements.txt`，不需要安装 npm 依赖。

```sh
python -m pip install -r requirements.txt
python scripts/build.py
```

如果电脑用 `python3` 命令，就将上面两处 `python` 换为 `python3`。

生成结果：

| 文件 | 用途 |
| --- | --- |
| `dist/JingYueShanHai-v14.3-localmap.aix` | 重新封装的 Agent 包，交给平台上传验证 |
| `dist/verification.txt` | 逻辑和资源检查记录 |
| `dist/SHA256SUMS.txt` | 文件校验值 |

单独运行现有源码测试：

```sh
npm test
```

修改节点、边或路线计算后，必须重新执行 `python scripts/build.py`。构建会重新生成图片及索引，请将 `assets/routes/` 和 `utils/routeImages.js` 的变化一并提交。

## 自动构建

仓库中的 `Build AIX` 工作流在以下情况执行：向 main 分支推送、针对 main 的 Pull Request、在 Actions 页面手动运行。

工作流安装 Python 图片依赖，生成地图，检查当前项目，再输出 AIX 和报告。仅需要仓库读取权限，不需要填写 Rokid 密钥或 GitHub Token，也不会自动发布到 Rokid 或创建公开 Release。

GitHub 托管的工作流尚未在你的仓库运行。首次推送后，以 Actions 的实际运行结果为准。

## 源码位置

| 路径 | 内容 |
| --- | --- |
| `app.json`、`app.js`、`app.wxss` | Agent 入口、配置和全局样式 |
| `pages/index/index.ink` | 欢迎、起点确认、目的地、交通选择、室内引导、完成页 |
| `utils/mapData.js` | 模拟点位、路线边、目的地与交通数据 |
| `utils/routeEngine.js` | 路线查找与步骤生成 |
| `utils/routeImages.js` | 自动生成的路线图片索引 |
| `assets/routes/` | 随包 PNG 图片 |
| `scripts/build-scenes.mjs` | 枚举路线状态 |
| `scripts/render_assets.py` | 根据坐标绘制路线图 |
| `scripts/build.py` | 生成、验证、封装 AIX |
| `tests/verify.mjs` | 模拟页面状态的逻辑验证 |
| `AGENTS.md` | 业务边界及后续开发约定 |

## 验证范围与已知限制

已完成本地检查：四种交通方式共 19 个主流程步骤、670 次路线步骤图片选择、210 个唯一图片资源、地标重规划、取消返回、异常文字提示、页面结构及 AIX 压缩包完整性。

这些是静态检查和模拟状态测试，不能证明 AIUI 编译通过或眼镜已显示图片。当前没有真机日志或平台上传成功回执。

仍需处理的业务数据与功能：

- 机场领取点、楼层、出口编号和交通点位待现场核实。
- 大巴售票点和候车点仍复用了同一个模拟节点。
- 原引擎反向路线可能沿用正向动作描述，实地使用前需要逐条校对。
- 原业务的“无路线”与“已在终点”空态尚未完全区分。
- 语音识别和交通实时信息未在本次修复中完成真机验证。

## 眼镜测试

1. 上传新构建的 AIX，退出后重新进入智能体。
2. 确认欢迎页或地图区出现 `v14.3-localmap`。
3. 选择出租车，查看图中 1、2 和连接线。
4. 点击“我到了”，查看当前点和图片是否同步变化。
5. 测试换层、地标纠错以及返回原导航。

如果出现包格式报错，保留完整上传提示；如果图片不显示，提供版本标记及页面照片。不要把源码重新封装成功当成平台接受或真机测试通过。

## 参考

- [Rokid AIUI Image 组件](https://github.com/yodaos-project/AIUI/blob/main/skills/aiui-dev/references/components/image.md)
- [GitHub 工作流入门](https://docs.github.com/en/actions/tutorials/create-an-example-workflow)
- [GitHub 工作流产物](https://docs.github.com/en/actions/tutorials/store-and-share-data)

本项目未附加开源许可证；是否公开仓库及授权他人使用，由项目所有者决定。
