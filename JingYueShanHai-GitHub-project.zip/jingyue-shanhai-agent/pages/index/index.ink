<script def>
{
  "navigationBarTitleText": "镜越山海｜机场接驳指引"
}
</script>

<page>
  <view class="hud-page">

    <!-- ===== 欢迎界面 ===== -->
    <scroll-view scroll-y="true" scroll-into-view="{{scrollIntoView}}" class="hud-scroll" ink:if="{{phase === 'welcome'}}">
      <view class="hud-welcome-inner">
        <text class="hud-app-title">镜越山海 · 机场接驳指引</text>
        <text class="hud-build-tag">v14.3-localmap · 昆明长水机场到达接驳</text>
        <view class="hud-dot"></view>

        <view class="hud-card hud-welcome-card">
          <text class="hud-welcome-text">你好，我是镜越山海，你的机场接驳向导。我会带你从机场到达出口出发，找到正确的乘车位置，前往酒店或赛事领物点。</text>
          <text class="hud-welcome-text">服务范围：从眼镜领取点到机场内乘车位置。不提供机场外实时导航，只展示交通方案说明。</text>
        </view>

        <button id="focus_startGuide"
          class="hud-btn hud-btn-primary hud-action-btn {{focusedKey === 'startGuide' ? 'hud-focus' : ''}}"
          bindtap="startGuide">开始引导</button>

        <button id="focus_goBackLevel"
          class="hud-btn hud-action-btn {{focusedKey === 'goBackLevel' ? 'hud-focus' : ''}}"
          bindtap="goBackLevel">返回上一层</button>

        <text class="hud-text-sm hud-focus-hint">上下滑动选择，点击确认</text>
      </view>
    </scroll-view>

    <!-- ===== 领取点确认 ===== -->
    <scroll-view scroll-y="true" scroll-into-view="{{scrollIntoView}}" class="hud-scroll" ink:if="{{phase === 'pickup_confirm'}}">
      <view class="hud-gps-nav-inner">

        <text class="hud-section-title">领取点确认</text>

        <view class="hud-card">
          <text class="hud-card-title">{{pickupPoint.airportName}}</text>
          <view class="hud-card-row">
            <text class="hud-card-label">航站楼</text>
            <text class="hud-card-value">{{pickupPoint.terminal}}</text>
          </view>
          <view class="hud-card-row">
            <text class="hud-card-label">楼层</text>
            <text class="hud-card-value">{{pickupPoint.floor}}</text>
          </view>
          <view class="hud-card-row">
            <text class="hud-card-label">到达出口</text>
            <text class="hud-card-value">{{pickupPoint.exitGate}}</text>
          </view>
          <view class="hud-card-row">
            <text class="hud-card-label">服务点</text>
            <text class="hud-card-value">{{pickupPoint.serviceName}}</text>
          </view>
          <view class="hud-card-row">
            <text class="hud-card-label">附近地标</text>
            <text class="hud-card-value">{{pickupPointLandmarksStr}}</text>
          </view>
          <view class="hud-card-row">
            <text class="hud-card-label">核实日期</text>
            <text class="hud-card-value">{{pickupPoint.verifiedDate}}</text>
          </view>
        </view>

        <view class="hud-card hud-step-card">
          <text class="hud-text-sm hud-text-bold">你是否在 {{pickupPoint.exitGate}} 旁的眼镜领取点？</text>
          <text class="hud-text-sm">确认后，将以此作为你的最后确认位置。</text>
        </view>

        <view class="hud-btn-row">
          <button id="focus_pickupNo"
            class="hud-btn hud-action-btn {{focusedKey === 'pickupNo' ? 'hud-focus' : ''}}"
            bindtap="showLandmarkSelect">不在领取点</button>
          <button id="focus_pickupYes"
            class="hud-btn hud-btn-primary hud-action-btn {{focusedKey === 'pickupYes' ? 'hud-focus' : ''}}"
            bindtap="confirmPickupPoint">确认在领取点</button>
        </view>

        <view ink:if="{{pickupSelectLandmark}}">
          <text class="hud-section-title">选择你看到的地标</text>
          <text class="hud-text-sm">如果不在领取点，请选择你当前附近可见的地标：</text>
          <view ink:for="{{pickupLandmarkNodes}}" ink:key="id" ink:for-item="lm" ink:for-index="lmidx"
            id="focus_pickupLm_{{lmidx}}"
            class="hud-list-item hud-action-item {{focusedPickupLmIdx === lmidx ? 'hud-focus' : ''}}"
            bindtap="selectLandmarkAsStart"
            data-id="{{lm.id}}" data-index="{{lmidx}}">
            <text class="hud-list-item-title">{{lm.name}}</text>
            <text class="hud-list-item-desc">{{lm.floor}}</text>
          </view>
          <button id="focus_pickupLmCancel"
            class="hud-btn hud-action-btn {{focusedKey === 'pickupLmCancel' ? 'hud-focus' : ''}}"
            bindtap="cancelLandmarkSelect">取消</button>
        </view>

        <button id="focus_pickupBack"
          class="hud-btn hud-action-btn {{focusedKey === 'pickupBack' ? 'hud-focus' : ''}}"
          bindtap="goBackToWelcome">返回欢迎页</button>

        <view class="hud-disclaimer">{{dataDisclaimer}}</view>
      </view>
    </scroll-view>

    <!-- ===== 目的地语音输入 ===== -->
    <scroll-view scroll-y="true" scroll-into-view="{{scrollIntoView}}" class="hud-scroll" ink:if="{{phase === 'dest_voice'}}">
      <view class="hud-gps-nav-inner">
        <text class="hud-section-title">目的地</text>
        <text class="hud-text-sm">当前位置：{{currentLocationLabel}}（手动确认）</text>

        <view class="hud-card hud-voice-card" ink:if="{{voiceInputStatus === 'idle'}}">
          <text class="hud-card-title">你想去哪里？</text>
          <text class="hud-text-sm">可以说酒店、景点、学校或赛事领物点。</text>
          <text class="hud-text-sm hud-text-ok">如：去海埂大酒店 / 去云南大学 / 去领物中心</text>
        </view>

        <view class="hud-btn-row" ink:if="{{voiceInputStatus === 'idle'}}">
          <button id="focus_startVoice"
            class="hud-btn hud-btn-primary hud-action-btn {{focusedKey === 'startVoice' ? 'hud-focus' : ''}}"
            bindtap="startVoiceInput">语音输入目的地</button>
        </view>

        <view ink:if="{{voiceInputStatus === 'listening'}}">
          <view class="hud-card hud-voice-listening">
            <text class="hud-card-title">正在聆听…</text>
            <view class="hud-voice-pulse"></view>
            <text class="hud-text-sm">请说出你的目的地</text>
          </view>
          <view class="hud-btn-row">
            <button id="focus_cancelVoice"
              class="hud-btn hud-action-btn {{focusedKey === 'cancelVoice' ? 'hud-focus' : ''}}"
              bindtap="cancelVoiceInput">取消</button>
          </view>
        </view>

        <view ink:if="{{voiceInputStatus === 'result'}}">
          <view class="hud-card">
            <text class="hud-card-title">识别结果</text>
            <view class="hud-card-row">
              <text class="hud-card-label">你说</text>
              <text class="hud-card-value hud-text-bold">{{voiceInputText}}</text>
            </view>
          </view>

          <view ink:if="{{destCandidates.length > 0}}">
            <text class="hud-text-sm hud-text-warn">存在多个匹配地点，请选择：</text>
            <view ink:for="{{destCandidates}}" ink:key="name" ink:for-item="cand" ink:for-index="cidx"
              id="focus_cand_{{cidx}}"
              class="hud-list-item hud-action-item {{focusedCandIdx === cidx ? 'hud-focus' : ''}}"
              bindtap="selectDestinationCandidate"
              data-index="{{cidx}}">
              <text class="hud-list-item-title">{{cand.name}}</text>
              <text class="hud-list-item-desc">{{cand.address}}</text>
            </view>
          </view>

          <view class="hud-card" ink:if="{{destCandidates.length === 0 && matchedDest}}">
            <text class="hud-card-title">{{matchedDest.name}}</text>
            <view class="hud-card-row">
              <text class="hud-card-label">地址</text>
              <text class="hud-card-value">{{matchedDest.address}}</text>
            </view>
            <view class="hud-card-row" ink:if="{{matchedDest.eventName}}">
              <text class="hud-card-label">赛事</text>
              <text class="hud-card-value">{{matchedDest.eventName}}</text>
            </view>
            <view class="hud-card-row" ink:if="{{matchedDest.pickupDeadline}}">
              <text class="hud-card-label">领物截止</text>
              <text class="hud-card-value hud-text-warn">{{matchedDest.pickupDeadline}}</text>
            </view>
            <view class="hud-btn-row">
              <button id="focus_retryVoice"
                class="hud-btn hud-action-btn {{focusedKey === 'retryVoice' ? 'hud-focus' : ''}}"
                bindtap="startVoiceInput">重新说</button>
              <button id="focus_confirmDest"
                class="hud-btn hud-btn-primary hud-action-btn {{focusedKey === 'confirmDest' ? 'hud-focus' : ''}}"
                bindtap="confirmMatchedDest">确认目的地</button>
            </view>
          </view>

          <view ink:if="{{destCandidates.length === 0 && !matchedDest}}">
            <text class="hud-text-sm hud-text-warn">未找到匹配目的地，请重试或手动选择</text>
            <view class="hud-btn-row">
              <button id="focus_retryVoice"
                class="hud-btn hud-btn-primary hud-action-btn {{focusedKey === 'retryVoice' ? 'hud-focus' : ''}}"
                bindtap="startVoiceInput">重新语音输入</button>
            </view>
          </view>
        </view>

        <view ink:if="{{voiceInputStatus === 'error'}}">
          <view class="hud-card hud-text-warn">
            <text class="hud-card-title">语音识别失败</text>
            <text class="hud-text-sm">{{voiceInputText}}</text>
          </view>
          <view class="hud-btn-row">
            <button id="focus_retryVoice"
              class="hud-btn hud-btn-primary hud-action-btn {{focusedKey === 'retryVoice' ? 'hud-focus' : ''}}"
              bindtap="startVoiceInput">重新语音输入</button>
          </view>
        </view>

        <view ink:if="{{voiceInputStatus !== 'listening'}}">
          <text class="hud-text-sm hud-manual-hint">— 或手动选择 —</text>
          <view ink:for="{{destinations}}" ink:key="id" ink:for-item="dest" ink:for-index="didx"
            id="focus_dest_{{didx}}"
            class="hud-list-item hud-action-item {{focusedDestIdx === didx ? 'hud-focus' : ''}}"
            bindtap="selectDestinationManual"
            data-id="{{dest.id}}" data-index="{{didx}}">
            <text class="hud-list-item-title">{{dest.name}}</text>
            <text class="hud-list-item-desc">{{dest.address}}</text>
          </view>
        </view>

        <button id="focus_destBack"
          class="hud-btn hud-action-btn {{focusedKey === 'destBack' ? 'hud-focus' : ''}}"
          bindtap="goBackToPickupConfirm">返回</button>

        <view class="hud-disclaimer">{{dataDisclaimer}}</view>
      </view>
    </scroll-view>

    <!-- ===== 交通方式选择 ===== -->
    <scroll-view scroll-y="true" scroll-into-view="{{scrollIntoView}}" class="hud-scroll" ink:if="{{phase === 'transport_select'}}">
      <view class="hud-gps-nav-inner">
        <text class="hud-section-title">选择交通方式</text>
        <text class="hud-text-sm">前往 {{selectedDest.name}}</text>

        <view class="hud-card hud-step-card" ink:if="{{recommendation.reasonShort}}">
          <text class="hud-card-title">推荐：{{recommendation.transportLabel}}</text>
          <text class="hud-text-sm">{{recommendation.reasonShort}}</text>
          <text class="hud-text-sm hud-text-dim">直线距离：{{recommendation.estimatedDistance}}</text>
        </view>

        <view ink:for="{{transportOptions}}" ink:key="id" ink:for-item="opt" ink:for-index="tidx"
          id="focus_transport_{{tidx}}"
          class="hud-list-item hud-action-item {{focusedTransportIdx === tidx ? 'hud-focus' : ''}}"
          bindtap="selectTransport"
          data-id="{{opt.id}}" data-index="{{tidx}}">
          <text class="hud-list-item-title">{{opt.label}}{{opt.isRecommended ? ' ★推荐' : ''}}</text>
          <text class="hud-list-item-desc">{{opt.desc}}</text>
          <text class="hud-list-item-desc" ink:if="{{opt.isRecommended}}">推荐理由：{{opt.reason}}</text>
        </view>

        <button id="focus_backFromTransport"
          class="hud-btn hud-action-btn {{focusedKey === 'backFromTransport' ? 'hud-focus' : ''}}"
          bindtap="goBackToDestVoice">返回</button>
      </view>
    </scroll-view>

    <!-- ===== 室内分段引导 ===== -->

    <scroll-view scroll-y="true" scroll-into-view="{{scrollIntoView}}" class="hud-scroll" ink:if="{{phase === 'indoor_nav'}}">
      <view id="indoorTop" class="hud-indoor-inner">

        <view class="hud-indoor-header">
          <text class="hud-indoor-header-floor">{{currentFloor}}</text>
          <text class="hud-indoor-header-transport">{{transportLabel}}</text>
        </view>

        <view ink:if="{{wrongWayMode}}">
          <text class="hud-section-title">选择你看到的地标</text>
          <text class="hud-text-sm">走错了？请选择你当前附近可见的地标：</text>
          <view ink:for="{{wrongWayNodes}}" ink:key="id" ink:for-item="lm" ink:for-index="lmidx"
            id="focus_landmark_{{lmidx}}"
            class="hud-list-item hud-action-item {{focusedLandmarkIdx === lmidx ? 'hud-focus' : ''}}"
            bindtap="selectLandmark"
            data-id="{{lm.id}}" data-index="{{lmidx}}">
            <text class="hud-list-item-title">{{lm.name}}</text>
            <text class="hud-list-item-desc">{{lm.floor}}</text>
          </view>
          <button id="focus_cancelWrongWay"
            class="hud-btn hud-action-btn {{focusedKey === 'cancelWrongWay' ? 'hud-focus' : ''}}"
            bindtap="cancelWrongWay">取消</button>
        </view>

        <view ink:if="{{rideHailOrderMode && !wrongWayMode}}">
          <text class="hud-section-title">网约车订单核对</text>
          <view class="hud-card">
            <text class="hud-text-sm">{{rideHailReminder}}</text>
            <text class="hud-text-sm hud-text-warn">{{rideHailDisclaimer}}</text>
          </view>
          <view class="hud-card">
            <text class="hud-card-title">订单上车区信息</text>
            <view ink:for="{{rideHailOrderFields}}" ink:key="key" ink:for-item="field" ink:for-index="fidx">
              <text class="hud-card-label">{{field.label}}</text>
              <input class="hud-input" placeholder="{{field.placeholder}}" bindinput="onOrderFieldInput" data-key="{{field.key}}" value="{{rideHailOrderValues[field.key]}}" />
            </view>
          </view>
          <view class="hud-btn-row">
            <button id="focus_skipOrderCheck"
              class="hud-btn hud-action-btn {{focusedKey === 'skipOrderCheck' ? 'hud-focus' : ''}}"
              bindtap="skipOrderCheck">引导到公共候车区</button>
            <button id="focus_confirmOrder"
              class="hud-btn hud-btn-primary hud-action-btn {{focusedKey === 'confirmOrder' ? 'hud-focus' : ''}}"
              bindtap="confirmRideHailOrder">核对并引导</button>
          </view>
          <button id="focus_backFromOrder"
            class="hud-btn hud-action-btn {{focusedKey === 'backFromOrder' ? 'hud-focus' : ''}}"
            bindtap="goBackToTransportSelect">换交通方式</button>
        </view>

        <view ink:if="{{!wrongWayMode && !rideHailOrderMode}}">
          <view class="hud-card hud-step-card" ink:if="{{transportMode === 'bus' && busStage === 'ticket'}}">
            <text class="hud-card-title">第一阶段：前往售票窗口</text>
            <text class="hud-text-sm">购票后继续引导到候车点</text>
          </view>
          <view class="hud-card hud-step-card" ink:if="{{transportMode === 'bus' && busStage === 'waiting'}}">
            <text class="hud-card-title">第二阶段：前往候车点</text>
            <text class="hud-text-sm">已购票，请前往 {{busWaitingLocation}} 候车</text>
          </view>

          <view class="hud-card" ink:if="{{!indoorSteps.length}}">
            <text class="hud-text-sm">你已在目标区域附近，无需室内引导。</text>
            <view class="hud-btn-row">
              <button id="focus_skipToTransportInfo"
                class="hud-btn hud-btn-primary hud-action-btn {{focusedKey === 'skipToTransportInfo' ? 'hud-focus' : ''}}"
                bindtap="showTransportInfo">{{transportMode === 'bus' && busStage === 'ticket' ? '已购票，前往候车点' : '查看乘车指引'}}</button>
            </view>
          </view>

          <view ink:if="{{indoorSteps.length}}">

            <view class="hud-local-map">
              <text class="hud-map-caption">{{routeImageTitle}}</text>
              <image ink:if="{{routeImageSrc}}" src="{{routeImageSrc}}" mode="aspectFit" class="hud-route-image"></image>
              <text class="hud-map-caption">1 已确认位置 · 2 下一点 · 模拟示意</text>
              <text ink:if="{{routeMapError}}" class="hud-map-caption">{{routeMapError}}</text>
              <text class="hud-map-version">v14.3-localmap</text>
            </view>

            <view class="hud-card hud-floor-change-card" ink:if="{{currentStepFloorChange}}">
              <text class="hud-text-sm hud-text-warn">换层示意：{{currentStep.fromFloor}} → {{currentStep.toFloor}}</text>
              <text class="hud-text-sm">{{floorChangeType}}</text>
            </view>

            <view class="hud-card hud-step-card">
              <text class="hud-current-action">{{currentStepIndexP1}}/{{indoorSteps.length}} · {{currentActionText}}</text>
            </view>

            <view ink:if="{{detailExpanded}}">
              <view class="hud-card">
                <text class="hud-text-sm">{{currentStep.description}}</text>
                <view class="hud-card-row" ink:if="{{currentStep.landmarkStr}}">
                  <text class="hud-card-label">注意标识</text>
                  <text class="hud-card-value">{{currentStep.landmarkStr}}</text>
                </view>
                <view class="hud-card-row">
                  <text class="hud-card-label">从</text>
                  <text class="hud-card-value">{{currentStep.fromName}}</text>
                </view>
                <view class="hud-card-row">
                  <text class="hud-card-label">方向</text>
                  <text class="hud-card-value">{{currentStep.direction}}</text>
                </view>
              </view>
            </view>


            <view class="hud-btn-row">
              <button id="focus_toggleDetail"
                class="hud-btn hud-action-btn {{focusedKey === 'toggleDetail' ? 'hud-focus' : ''}}"
                bindtap="toggleDetail">{{detailExpanded ? '收起' : '说明'}}</button>
              <button id="focus_wrongWay"
                class="hud-btn hud-action-btn {{focusedKey === 'wrongWay' ? 'hud-focus' : ''}}"
                bindtap="wrongWay">走错了</button>
              <button id="focus_advanceStep"
                class="hud-btn hud-btn-primary hud-action-btn {{focusedKey === 'advanceStep' ? 'hud-focus' : ''}}"
                bindtap="advanceStep">我到了</button>
            </view>
          </view>

          <button id="focus_backFromIndoor"
            class="hud-btn hud-action-btn {{focusedKey === 'backFromIndoor' ? 'hud-focus' : ''}}"
            bindtap="goBackToTransportSelect">换交通方式</button>
        </view>

        <view class="hud-disclaimer" ink:if="{{!wrongWayMode && !rideHailOrderMode}}">{{dataDisclaimer}}</view>
        <text class="hud-build-tag">v14.3-localmap</text>
      </view>
    </scroll-view>

    <!-- ===== 乘车指引 ===== -->
    <scroll-view scroll-y="true" scroll-into-view="{{scrollIntoView}}" class="hud-scroll" ink:if="{{phase === 'transport_info'}}">
      <view class="hud-gps-nav-inner">
        <text class="hud-section-title">乘车指引 · {{transportLabel}}</text>

        <view class="hud-card" ink:if="{{transportMode === 'taxi'}}">
          <text class="hud-card-title">出租车乘车</text>
          <view class="hud-card-row"><text class="hud-card-label">上车地点</text><text class="hud-card-value">{{transitInfo.location}}</text></view>
          <view class="hud-card-row"><text class="hud-card-label">楼层</text><text class="hud-card-value">{{transitInfo.floor}}</text></view>
          <view class="hud-card-row"><text class="hud-card-label">预计等待</text><text class="hud-card-value">{{transitInfo.estimatedWaitMin}}</text></view>
          <view class="hud-card-row"><text class="hud-card-label">排队情况</text><text class="hud-card-value">{{transitInfo.queueDescription}}</text></view>
        </view>

        <view class="hud-card hud-step-card" ink:if="{{transportMode === 'taxi'}}">
          <text class="hud-card-title">向司机说明</text>
          <view class="hud-card-row"><text class="hud-card-label">目的地</text><text class="hud-card-value hud-text-bold">{{selectedDest.name}}</text></view>
          <view class="hud-card-row"><text class="hud-card-label">地址</text><text class="hud-card-value">{{selectedDest.address}}</text></view>
          <view class="hud-card hud-text-warn" style="margin-top: 8rpx;"><text class="hud-text-sm">{{transitInfo.boardingNote}}</text></view>
        </view>

        <view class="hud-card" ink:if="{{transportMode === 'ride_hail'}}">
          <text class="hud-card-title">网约车乘车</text>
          <view class="hud-card-row"><text class="hud-card-label">上车地点</text><text class="hud-card-value">{{transitInfo.location}}</text></view>
          <view class="hud-card-row"><text class="hud-card-label">楼层</text><text class="hud-card-value">{{transitInfo.floor}}</text></view>
          <view class="hud-card-row"><text class="hud-card-label">集合点</text><text class="hud-card-value hud-text-warn">{{transitInfo.meetingPoint}}</text></view>
          <view class="hud-card hud-text-warn" style="margin-top: 8rpx;"><text class="hud-text-sm">{{transitInfo.pickupNote}}</text></view>
        </view>

        <view class="hud-card" ink:if="{{transportMode === 'ride_hail' && rideHailOrderSummary}}">
          <text class="hud-card-title">订单上车区信息</text>
          <text class="hud-text-sm">{{rideHailOrderSummary}}</text>
        </view>

        <view class="hud-card" ink:if="{{transportMode === 'metro'}}">
          <text class="hud-card-title">地铁乘车</text>
          <view class="hud-card-row"><text class="hud-card-label">入口位置</text><text class="hud-card-value">{{transitInfo.entranceLocation}}</text></view>
          <view class="hud-card-row"><text class="hud-card-label">线路</text><text class="hud-card-value hud-text-bold">{{transitInfo.line}}</text></view>
          <view class="hud-card-row"><text class="hud-card-label">方向</text><text class="hud-card-value">{{transitInfo.direction}}</text></view>
          <view class="hud-card-row"><text class="hud-card-label">下车站</text><text class="hud-card-value hud-text-warn">{{transitInfo.alightStation}}</text></view>
          <view class="hud-card-row"><text class="hud-card-label">出站口</text><text class="hud-card-value hud-text-warn">{{transitInfo.exitGate}}</text></view>
          <view class="hud-card-row"><text class="hud-card-label">预计乘车</text><text class="hud-card-value">{{transitInfo.estimatedRideMin}}</text></view>
          <view class="hud-card-row" ink:if="{{transitInfo.transferStations.length}}"><text class="hud-card-label">换乘站</text><text class="hud-card-value">{{transitInfo.transferStationsStr}}</text></view>
        </view>

        <view class="hud-card" ink:if="{{transportMode === 'metro'}}">
          <view class="hud-card-row"><text class="hud-card-label">购票</text><text class="hud-card-value">{{transitInfo.ticketNote}}</text></view>
          <view class="hud-card-row"><text class="hud-card-label">安检</text><text class="hud-card-value">{{transitInfo.securityNote}}</text></view>
          <view class="hud-card-row"><text class="hud-card-label">乘车</text><text class="hud-card-value">{{transitInfo.boardingNote}}</text></view>
          <view class="hud-card-row" ink:if="{{transitInfo.operationHours}}"><text class="hud-card-label">运营时间</text><text class="hud-card-value">{{transitInfo.operationHours}}</text></view>
        </view>

        <view class="hud-card" ink:if="{{transportMode === 'bus'}}">
          <text class="hud-card-title">机场大巴乘车</text>
          <view class="hud-card-row"><text class="hud-card-label">售票/候车</text><text class="hud-card-value">{{transitInfo.stopLocation}}</text></view>
          <view class="hud-card-row"><text class="hud-card-label">楼层</text><text class="hud-card-value">{{transitInfo.floor}}</text></view>
          <view class="hud-card-row"><text class="hud-card-label">线路</text><text class="hud-card-value hud-text-bold">{{transitInfo.line}}</text></view>
          <view class="hud-card-row"><text class="hud-card-label">方向</text><text class="hud-card-value">{{transitInfo.direction}}</text></view>
          <view class="hud-card-row"><text class="hud-card-label">下车站</text><text class="hud-card-value hud-text-warn">{{transitInfo.alightStop}}</text></view>
          <view class="hud-card-row"><text class="hud-card-label">预计乘车</text><text class="hud-card-value">{{transitInfo.estimatedRideMin}}</text></view>
          <view class="hud-card-row"><text class="hud-card-label">运营时间</text><text class="hud-card-value">{{transitInfo.operationHours}}</text></view>
          <view class="hud-card-row"><text class="hud-card-label">票价</text><text class="hud-card-value">{{transitInfo.ticketPrice}}</text></view>
          <view class="hud-card-row" ink:if="{{transitInfo.priceSource}}"><text class="hud-card-label">票价来源</text><text class="hud-card-value hud-text-dim">{{transitInfo.priceSource}}</text></view>
        </view>

        <view class="hud-card hud-text-warn"><text class="hud-text-sm">请核对以上信息后上车。时间和费用为模拟估算，以实际为准。</text></view>

        <view class="hud-btn-row">
          <button id="focus_backFromTransportInfo" class="hud-btn hud-action-btn {{focusedKey === 'backFromTransportInfo' ? 'hud-focus' : ''}}" bindtap="goBackToTransportSelect">更换交通方式</button>
          <button id="focus_showCompletion" class="hud-btn hud-btn-primary hud-action-btn {{focusedKey === 'showCompletion' ? 'hud-focus' : ''}}" bindtap="showCompletion">机场内引导完成</button>
        </view>
      </view>
    </scroll-view>

    <!-- ===== 引导完成 ===== -->
    <scroll-view scroll-y="true" scroll-into-view="{{scrollIntoView}}" class="hud-scroll" ink:if="{{phase === 'completion'}}">
      <view class="hud-gps-nav-inner">
        <text class="hud-section-title">引导完成</text>
        <view class="hud-card hud-step-card">
          <text class="hud-card-title">机场内引导完成</text>
          <text class="hud-text-sm">已到达 {{transportLabel}} 乘车位置。</text>
          <text class="hud-text-sm">目的地：{{selectedDest.name}}</text>
          <text class="hud-text-sm hud-text-dim">{{selectedDest.address}}</text>
        </view>
        <view class="hud-card">
          <text class="hud-card-title">后续乘坐方案</text>
          <text class="hud-text-sm">{{completionRideSummary}}</text>
        </view>
        <view class="hud-btn-row">
          <button id="focus_viewRidePlan" class="hud-btn hud-action-btn {{focusedKey === 'viewRidePlan' ? 'hud-focus' : ''}}" bindtap="showTransportInfo">查看乘坐方案</button>
          <button id="focus_changeTransport" class="hud-btn hud-action-btn {{focusedKey === 'changeTransport' ? 'hud-focus' : ''}}" bindtap="goBackToTransportSelect">更换交通方式</button>
        </view>
        <button id="focus_completionToWelcome" class="hud-btn hud-btn-primary hud-action-btn {{focusedKey === 'completionToWelcome' ? 'hud-focus' : ''}}" bindtap="goBackToWelcome">返回欢迎页</button>
        <view class="hud-disclaimer">机场内引导已完成。不提供机场外实时导航，请按乘坐方案自行前往目的地。</view>
      </view>
    </scroll-view>

  </view>
</page>

<style>
.hud-scroll { flex: 1; min-height: 0; }
.hud-welcome-inner { display: flex; flex-direction: column; align-items: center; padding: 40rpx 0 40rpx 0; }
.hud-indoor-inner { display: flex; flex-direction: column; padding-bottom: 12rpx; }
.hud-gps-nav-inner { display: flex; flex-direction: column; padding-bottom: 20rpx; }
.hud-app-title { font-size: 32rpx; font-weight: bold; color: #00ff41; text-align: center; }
.hud-build-tag { font-size: 20rpx; color: rgba(0, 255, 65, 0.5); text-align: center; margin-top: 6rpx; margin-bottom: 16rpx; }
.hud-welcome-card { width: 100%; margin: 16rpx 0; border-color: #00ff41; background-color: rgba(0, 255, 65, 0.08); }
.hud-welcome-text { font-size: 22rpx; color: rgba(0, 255, 65, 0.85); line-height: 1.6; margin-bottom: 8rpx; }
.hud-action-btn { margin-top: 8rpx; }
.hud-focus-hint { margin-top: 16rpx; opacity: 0.5; font-size: 18rpx; text-align: center; }
.hud-voice-card { border-color: #00ff41; background-color: rgba(0, 255, 65, 0.08); }
.hud-voice-listening { border-color: #00ff41; background-color: rgba(0, 255, 65, 0.12); display: flex; flex-direction: column; align-items: center; }
.hud-voice-pulse { width: 24rpx; height: 24rpx; border-radius: 50%; background-color: #00ff41; opacity: 0.6; margin: 8rpx 0; }
.hud-manual-hint { display: block; text-align: center; opacity: 0.4; font-size: 18rpx; margin: 8rpx 0; }
.hud-indoor-header { display: flex; flex-direction: row; justify-content: space-between; align-items: center; padding: 4rpx 0; margin-bottom: 4rpx; }
.hud-indoor-header-floor { font-size: 22rpx; color: #00ff41; font-weight: bold; }
.hud-indoor-header-transport { font-size: 20rpx; color: rgba(0, 255, 65, 0.7); }
.hud-map-area { margin: 4rpx 0 2rpx 0; min-height: 130px; }
.hud-map-unavailable { display: flex; flex-direction: column; align-items: center; justify-content: center; height: 130px; border: 1rpx solid rgba(0, 255, 65, 0.2); border-radius: 4rpx; }
.hud-map-info-row { display: flex; flex-direction: row; justify-content: center; margin-bottom: 4rpx; }
.hud-map-hint { display: block; text-align: center; opacity: 0.4; font-size: 18rpx; padding: 2rpx 0; }
.hud-floor-change-card { border-color: rgba(0, 255, 65, 0.48); background-color: rgba(0, 255, 65, 0.06); border-style: dashed; }
.hud-step-card { border-color: #00ff41; background-color: rgba(0, 255, 65, 0.08); }
.hud-progress-bar { width: 100%; height: 4rpx; background-color: rgba(0, 255, 65, 0.2); border-radius: 2rpx; margin: 8rpx 0; overflow: hidden; }
.hud-progress-fill { height: 100%; background-color: #00ff41; border-radius: 2rpx; }
.hud-text-ok { color: #00ff41; }
.hud-input { border: 1rpx solid rgba(0, 255, 65, 0.48); border-radius: 4rpx; background-color: rgba(0, 255, 65, 0.06); color: #00ff41; font-size: 22rpx; padding: 8rpx 10rpx; margin-top: 4rpx; }
.hud-diag-card { border: 1rpx solid rgba(0, 255, 65, 0.3); border-radius: 4rpx; background-color: rgba(0, 255, 65, 0.04); padding: 6rpx 8rpx; margin: 4rpx 0; }
.hud-diag-title { font-size: 18rpx; color: rgba(0, 255, 65, 0.6); font-weight: bold; margin-bottom: 2rpx; }
.hud-diag-row { display: flex; flex-direction: row; align-items: flex-start; margin: 1rpx 0; }
.hud-diag-label { font-size: 18rpx; color: rgba(0, 255, 65, 0.5); flex-shrink: 0; }
.hud-diag-val { font-size: 18rpx; color: rgba(0, 255, 65, 0.85); word-break: break-all; }
.hud-diag-error { color: #ffcc00; }
.hud-diag-error-detail { font-size: 18rpx; color: #ffcc00; text-align: center; margin: 4rpx 8rpx; word-break: break-all; }
.hud-local-map { display: flex; flex-direction: column; width: 100%; }
.hud-route-image { width: 100%; height: 130rpx; flex-shrink: 0; }
.hud-map-caption { font-size: 18rpx; line-height: 1.2; color: #00d640; }
.hud-map-version { font-size: 16rpx; line-height: 1.1; color: #00a032; }
.hud-current-action { font-size: 24rpx; line-height: 1.25; font-weight: bold; }
.hud-indoor-inner .hud-card { padding: 6rpx 8rpx; margin-bottom: 4rpx; }
.hud-indoor-inner .hud-btn { padding: 6rpx 10rpx; margin-top: 4rpx; margin-bottom: 4rpx; font-size: 20rpx; }
</style>

<script setup>
import { ROUTE_IMAGES } from '../../utils/routeImages.js';
import { MOCK_AIRPORT } from '../../utils/mapData.js';
import { findNodePath, buildIndoorSteps, getNodeById, computeTransportRecommendation, buildBusTwoStageSteps, getTransportLabel } from '../../utils/routeEngine.js';

export default {
  data: {
    phase: 'welcome', focusedKey: '', focusOrder: [], focusedDestIdx: -1, focusedTransportIdx: -1, focusedLandmarkIdx: -1, focusedPickupLmIdx: -1, focusedCandIdx: -1, scrollIntoView: '',
    pickupPoint: null, pickupPointLandmarksStr: '', pickupSelectLandmark: false, pickupLandmarkNodes: [],
    startNodeId: 'arrival_hall', currentLocationLabel: '',
    destinations: [], selectedDest: null, destCandidates: [], matchedDest: null, voiceInputStatus: 'idle', voiceInputText: '',
    transportOptions: [], transportMode: '', transportLabel: '', transportZoneNodeId: '',
    recommendation: { transportLabel: '', reasonShort: '', reasonDetail: '', estimatedDistance: '' },
    indoorSteps: [], currentStepIndex: 0, currentStep: null, currentStepIndexP1: 1, progressPercent: 0, currentFloor: '', currentActionText: '', currentStepFloorChange: false, floorChangeType: '', detailExpanded: false,
    busStage: '', busWaitingLocation: '', rideHailOrderMode: false, rideHailReminder: '', rideHailDisclaimer: '', rideHailOrderFields: [], rideHailOrderValues: {}, rideHailOrderSummary: '',
    mapUnavailable: false, routeMapError: '', routeImageSrc: '', routeImageTitle: '路线示意图',
    _mapRetryTimer: null, wrongWayMode: false, wrongWayNodes: [], transitInfo: null, completionRideSummary: '', dataDisclaimer: ''
  },

  onLoad() {
    console.info('[mapfix] onLoad v14.3-localmap');
    var pp = MOCK_AIRPORT.pickupPoint;
    this.setData({ destinations: MOCK_AIRPORT.destinations, transportOptions: MOCK_AIRPORT.transportOptions, pickupPoint: pp, pickupPointLandmarksStr: pp.nearbyLandmarks ? pp.nearbyLandmarks.join('、') : '', currentLocationLabel: pp.serviceName, startNodeId: pp.nodeId, currentFloor: pp.floor, dataDisclaimer: MOCK_AIRPORT.disclaimer });
    this.rebuildFocusList();
  },
  onReady() { console.info('[mapfix] onReady v14.3-localmap'); },
  onUnload() { console.info('[mapfix] onUnload v14.3-localmap'); this.cleanupVoiceRecognition(); this.clearMapRetryTimer(); },

  cleanupVoiceRecognition() { if (this._voiceRecognition) { try { this._voiceRecognition.abort(); } catch (e) {} this._voiceRecognition = null; } },
  // 地图为随包 PNG；不获取 Canvas，不依赖网络地图或延迟绘图。
  clearMapRetryTimer() {},
  updateRouteImage() {
    if (this.data.phase !== 'indoor_nav' || this.data.wrongWayMode || this.data.rideHailOrderMode) return;
    var steps = this.data.indoorSteps, idx = this.data.currentStepIndex;
    if (!steps.length) { this.setData({routeImageSrc: '', routeMapError: ''}); return; }
    if (!steps[idx]) { this.setData({routeImageSrc: '', mapUnavailable: true, routeMapError: '路线步骤越界，请重新选择交通方式'}); return; }
    var ids = [steps[idx].fromId];
    for (var i = idx; i < steps.length; i++) {
      if (ids[ids.length-1] !== steps[i].fromId) {
        this.setData({routeImageSrc: '', mapUnavailable: true, routeMapError: '路线节点不连续，请重新选择交通方式'}); return;
      }
      ids.push(steps[i].toId);
    }
    var record = ROUTE_IMAGES[ids.join('>')];
    if (!record) { this.setData({routeImageSrc: '', mapUnavailable: true, routeMapError: '缺少当前路线图片，请使用文字指引'}); return; }
    this.setData({routeImageSrc: record.src, routeImageTitle: record.title,
      mapUnavailable: false, routeMapError: '', currentLocationLabel: steps[idx].fromName});
    console.info('[localmap] selected', record.src, record.currentId, record.nextId);
  },
  retryDrawMap() { this.updateRouteImage(); },
  computeActionText(step) { if (!step) return ''; var d = step.direction || '', t = step.toName || ''; if (d && t) return d + '前往 ' + t; return step.description || ''; },
  computeFloorChange(step) { if (!step || !step.fromFloor || !step.toFloor || step.fromFloor === step.toFloor) return { change: false, type: '' }; var tp = step.type === 'escalator' ? '按现场标识乘扶梯至目标楼层' : step.type === 'elevator' ? '乘电梯至目标楼层' : '按标识前往目标楼层'; return { change: true, type: tp }; },

  startVoiceInput() {
    console.info('[mapfix] 启动语音输入');
    this.cleanupVoiceRecognition();
    var self = this, recognition = null;
    try { recognition = new SpeechRecognition(); } catch (e) { console.error('[mapfix] SpeechRecognition不可用:', e); this.setData({ voiceInputStatus: 'error', voiceInputText: '语音识别不可用，请手动选择目的地' }); this.rebuildFocusList(); return; }
    recognition.lang = 'zh-CN'; recognition.continuous = false; recognition.interimResults = false; recognition.maxAlternatives = 1;
    recognition.onresult = function(ev) { var tr = ''; try { tr = ev.results[ev.resultIndex][0].transcript; } catch (err) {} self.setData({ voiceInputStatus: 'result', voiceInputText: tr }); var m = self.matchDestinationWithCandidates(tr); if (m) { if (m.candidates && m.candidates.length > 0) { self.setData({ destCandidates: m.candidates, matchedDest: null }); } else { self.setData({ matchedDest: m, destCandidates: [] }); } } else { self.setData({ destCandidates: [], matchedDest: null }); } self.rebuildFocusList(); };
    recognition.onerror = function(ev) { var msg = '语音识别失败'; if (ev.error === 'no-speech') msg = '未检测到语音，请重试'; else if (ev.error === 'not-allowed') msg = '麦克风权限被拒绝'; else if (ev.error === 'network') msg = '网络错误，请检查连接'; self.setData({ voiceInputStatus: 'error', voiceInputText: msg }); self.rebuildFocusList(); };
    recognition.onend = function() { if (self.data.voiceInputStatus === 'listening') { self.setData({ voiceInputStatus: 'idle' }); self.rebuildFocusList(); } };
    this._voiceRecognition = recognition;
    this.setData({ voiceInputStatus: 'listening', voiceInputText: '' });
    this.rebuildFocusList();
    try { recognition.start(); } catch (e) { this.setData({ voiceInputStatus: 'error', voiceInputText: '无法启动语音识别：' + (e.message || e.name || '未知错误') }); this.rebuildFocusList(); }
  },
  cancelVoiceInput() { this.cleanupVoiceRecognition(); this.setData({ voiceInputStatus: 'idle', voiceInputText: '' }); this.rebuildFocusList(); },

  matchDestinationWithCandidates(transcript) {
    var dests = this.data.destinations; if (!dests || !dests.length || !transcript) return null;
    var text = transcript.toLowerCase().replace(/\s+/g, '');
    for (var i = 0; i < dests.length; i++) { var d = dests[i]; var nm = (d.name || '').toLowerCase(); if (nm.length >= 2 && text.indexOf(nm) >= 0) { if (d.destCandidates && d.destCandidates.length > 0) return { id: d.id, name: d.name, address: d.address, type: d.type, lat: d.lat, lng: d.lng, candidates: d.destCandidates }; return { id: d.id, name: d.name, address: d.address, type: d.type, lat: d.lat, lng: d.lng, eventName: d.eventName, pickupDeadline: d.pickupDeadline, candidates: [] }; } }
    var dpn = [{ destIdx: 0, pn: ['海埂大酒店', '海埂', '滇池路1288'] }, { destIdx: 1, pn: ['马拉松领物', '领物中心', '高原半程', '呈贡体育中心', '领装备'] }, { destIdx: 2, pn: ['云南大学', '云大', '呈贡校区', '东陆校区'] }, { destIdx: 3, pn: ['滇池海埂公园', '海埂公园', '滇池', '1312'] }];
    var best = null, bestS = 0, MIN = 4;
    for (var pi = 0; pi < dpn.length; pi++) { var e = dpn[pi]; var d2 = dests[e.destIdx]; var s = 0; for (var pn = 0; pn < e.pn.length; pn++) { var p = e.pn[pn].toLowerCase(); if (p.length >= 2 && text.indexOf(p) >= 0) s += p.length >= 4 ? 8 : 5; } var ad = (d2.address || '').toLowerCase().split(/[，,市省区县]/); for (var ap = 0; ap < ad.length; ap++) { var pt = ad[ap].trim(); if (pt.length >= 3 && text.indexOf(pt) >= 0) s += 3; } if (d2.eventName) { var ep = d2.eventName.split(/[，,]/); for (var epi = 0; epi < ep.length; epi++) { var ev = ep[epi].trim().toLowerCase(); if (ev.length >= 2 && text.indexOf(ev) >= 0) s += 5; } } if (s > bestS) { bestS = s; best = d2; } }
    if (!best || bestS < MIN) { console.info('[mapfix] 匹配不足:', bestS); return null; }
    console.info('[mapfix] 匹配成功:', best.name, '得分:', bestS);
    if (best.destCandidates && best.destCandidates.length > 0) return { id: best.id, name: best.name, address: best.address, type: best.type, lat: best.lat, lng: best.lng, candidates: best.destCandidates };
    return { id: best.id, name: best.name, address: best.address, type: best.type, lat: best.lat, lng: best.lng, eventName: best.eventName, pickupDeadline: best.pickupDeadline, candidates: [] };
  },

  confirmMatchedDest() { var d = this.data.matchedDest; if (!d) return; var r = computeTransportRecommendation(MOCK_AIRPORT, d); var tl = getTransportLabel(r.recommendedId); var opts = this.data.transportOptions.map(function(o) { return { id: o.id, label: o.label, zoneNodeId: o.zoneNodeId, icon: o.icon, desc: o.desc, isRecommended: o.id === r.recommendedId, reason: o.id === r.recommendedId ? r.reasonShort : '' }; }); this.setData({ selectedDest: d, recommendation: { transportLabel: tl, reasonShort: r.reasonShort, reasonDetail: r.reasonDetail, estimatedDistance: r.estimatedDistance }, transportOptions: opts }); this.goToTransportSelect(); },
  selectDestinationCandidate(e) { var ds = e && e.currentTarget && e.currentTarget.dataset ? e.currentTarget.dataset : {}; var idx = parseInt(ds.index, 10); var c = this.data.destCandidates[idx]; if (!c) return; var d = { id: this.data.matchedDest ? this.data.matchedDest.id : 'c_' + idx, name: c.name, address: c.address, type: this.data.matchedDest ? this.data.matchedDest.type : 'unknown', lat: c.lat, lng: c.lng }; var r = computeTransportRecommendation(MOCK_AIRPORT, d); var tl = getTransportLabel(r.recommendedId); var opts = this.data.transportOptions.map(function(o) { return { id: o.id, label: o.label, zoneNodeId: o.zoneNodeId, icon: o.icon, desc: o.desc, isRecommended: o.id === r.recommendedId, reason: o.id === r.recommendedId ? r.reasonShort : '' }; }); this.setData({ selectedDest: d, recommendation: { transportLabel: tl, reasonShort: r.reasonShort, reasonDetail: r.reasonDetail, estimatedDistance: r.estimatedDistance }, transportOptions: opts }); this.goToTransportSelect(); },
  selectDestinationManual(e) { var ds = e && e.currentTarget && e.currentTarget.dataset ? e.currentTarget.dataset : {}; var idx = parseInt(ds.index, 10); var d = this.data.destinations[idx]; if (!d) return; var r = computeTransportRecommendation(MOCK_AIRPORT, d); var tl = getTransportLabel(r.recommendedId); var opts = this.data.transportOptions.map(function(o) { return { id: o.id, label: o.label, zoneNodeId: o.zoneNodeId, icon: o.icon, desc: o.desc, isRecommended: o.id === r.recommendedId, reason: o.id === r.recommendedId ? r.reasonShort : '' }; }); this.setData({ selectedDest: d, recommendation: { transportLabel: tl, reasonShort: r.reasonShort, reasonDetail: r.reasonDetail, estimatedDistance: r.estimatedDistance }, transportOptions: opts }); this.goToTransportSelect(); },

  rebuildFocusList() {
    var ph = this.data.phase, order = [];
    if (ph === 'welcome') { order = ['startGuide', 'goBackLevel']; }
    else if (ph === 'pickup_confirm') { if (this.data.pickupSelectLandmark) { for (var k = 0; k < this.data.pickupLandmarkNodes.length; k++) order.push('pickupLm_' + k); order.push('pickupLmCancel'); } else order = ['pickupNo', 'pickupYes', 'pickupBack']; }
    else if (ph === 'dest_voice') { var vs = this.data.voiceInputStatus; if (vs === 'listening') order = ['cancelVoice', 'destBack']; else if (vs === 'idle') { order = ['startVoice']; for (var i = 0; i < this.data.destinations.length; i++) order.push('dest_' + i); order.push('destBack'); } else if (vs === 'result') { if (this.data.destCandidates.length > 0) { for (var c = 0; c < this.data.destCandidates.length; c++) order.push('cand_' + c); order.push('retryVoice'); order.push('destBack'); } else if (this.data.matchedDest) { order = ['retryVoice', 'confirmDest']; for (var j = 0; j < this.data.destinations.length; j++) order.push('dest_' + j); order.push('destBack'); } else { order = ['retryVoice']; for (var m = 0; m < this.data.destinations.length; m++) order.push('dest_' + m); order.push('destBack'); } } else if (vs === 'error') { order = ['retryVoice']; for (var n = 0; n < this.data.destinations.length; n++) order.push('dest_' + n); order.push('destBack'); } }
    else if (ph === 'transport_select') { for (var j2 = 0; j2 < this.data.transportOptions.length; j2++) order.push('transport_' + j2); order.push('backFromTransport'); }
    else if (ph === 'indoor_nav') { if (this.data.wrongWayMode) { for (var k2 = 0; k2 < this.data.wrongWayNodes.length; k2++) order.push('landmark_' + k2); order.push('cancelWrongWay'); } else if (this.data.rideHailOrderMode) order = ['skipOrderCheck', 'confirmOrder', 'backFromOrder']; else if (this.data.indoorSteps.length === 0) order = ['skipToTransportInfo', 'backFromIndoor']; else { order = ['toggleDetail', 'wrongWay', 'advanceStep', 'backFromIndoor']; } }
    else if (ph === 'transport_info') order = ['backFromTransportInfo', 'showCompletion'];
    else if (ph === 'completion') order = ['viewRidePlan', 'changeTransport', 'completionToWelcome'];
    var fk = order.length > 0 ? order[0] : '', fdI = -1, ftI = -1, flI = -1, fpI = -1, fcI = -1;
    if (fk.indexOf('dest_') === 0) fdI = parseInt(fk.substring(5), 10); else if (fk.indexOf('transport_') === 0) ftI = parseInt(fk.substring(10), 10); else if (fk.indexOf('landmark_') === 0) flI = parseInt(fk.substring(9), 10); else if (fk.indexOf('pickupLm_') === 0) fpI = parseInt(fk.substring(9), 10); else if (fk.indexOf('cand_') === 0) fcI = parseInt(fk.substring(5), 10);
    var siv = fk ? 'focus_' + fk : ''; if (ph === 'indoor_nav' && !this.data.wrongWayMode && !this.data.rideHailOrderMode) siv = 'indoorTop';
    this.setData({ focusOrder: order, focusedKey: fk, focusedDestIdx: fdI, focusedTransportIdx: ftI, focusedLandmarkIdx: flI, focusedPickupLmIdx: fpI, focusedCandIdx: fcI, scrollIntoView: siv });
  },

  moveFocus(dir) { var o = this.data.focusOrder; if (!o || !o.length) return; var ci = o.indexOf(this.data.focusedKey); var ni = dir === 'next' ? (ci >= 0 ? (ci + 1) % o.length : 0) : (ci > 0 ? ci - 1 : o.length - 1); var nk = o[ni]; var fdI = -1, ftI = -1, flI = -1, fpI = -1, fcI = -1; if (nk.indexOf('dest_') === 0) fdI = parseInt(nk.substring(5), 10); else if (nk.indexOf('transport_') === 0) ftI = parseInt(nk.substring(10), 10); else if (nk.indexOf('landmark_') === 0) flI = parseInt(nk.substring(9), 10); else if (nk.indexOf('pickupLm_') === 0) fpI = parseInt(nk.substring(9), 10); else if (nk.indexOf('cand_') === 0) fcI = parseInt(nk.substring(5), 10); var siv = 'focus_' + nk; if (this.data.phase === 'indoor_nav' && !this.data.wrongWayMode && !this.data.rideHailOrderMode && nk !== 'backFromIndoor' && !this.data.detailExpanded) siv = 'indoorTop'; this.setData({ focusedKey: nk, focusedDestIdx: fdI, focusedTransportIdx: ftI, focusedLandmarkIdx: flI, focusedPickupLmIdx: fpI, focusedCandIdx: fcI, scrollIntoView: siv }); },

  activateFocused() { var k = this.data.focusedKey; if (!k) return; switch (k) { case 'startGuide': this.startGuide(); break; case 'goBackLevel': this.goBackLevel(); break; case 'pickupYes': this.confirmPickupPoint(); break; case 'pickupNo': this.showLandmarkSelect(); break; case 'pickupBack': this.goBackToWelcome(); break; case 'pickupLmCancel': this.cancelLandmarkSelect(); break; case 'startVoice': case 'retryVoice': this.startVoiceInput(); break; case 'cancelVoice': this.cancelVoiceInput(); break; case 'confirmDest': this.confirmMatchedDest(); break; case 'destBack': this.goBackToPickupConfirm(); break; case 'backFromTransport': this.goBackToDestVoice(); break; case 'skipToTransportInfo': this.showTransportInfo(); break; case 'toggleDetail': this.toggleDetail(); break; case 'retryMap': this.retryDrawMap(); break; case 'wrongWay': this.wrongWay(); break; case 'advanceStep': this.advanceStep(); break; case 'backFromIndoor': this.goBackToTransportSelect(); break; case 'backFromTransportInfo': this.goBackToTransportSelect(); break; case 'showCompletion': this.showCompletion(); break; case 'viewRidePlan': this.showTransportInfo(); break; case 'changeTransport': this.goBackToTransportSelect(); break; case 'completionToWelcome': this.goBackToWelcome(); break; case 'skipOrderCheck': this.skipOrderCheck(); break; case 'confirmOrder': this.confirmRideHailOrder(); break; case 'backFromOrder': this.goBackToTransportSelect(); break; case 'cancelWrongWay': this.cancelWrongWay(); break; default: if (k.indexOf('dest_') === 0) this.selectDestinationManual({ currentTarget: { dataset: { index: parseInt(k.substring(5), 10) } } }); else if (k.indexOf('transport_') === 0) this.selectTransportByIndex(parseInt(k.substring(10), 10)); else if (k.indexOf('landmark_') === 0) this.selectLandmarkByIndex(parseInt(k.substring(9), 10)); else if (k.indexOf('pickupLm_') === 0) this.selectPickupLandmarkByIndex(parseInt(k.substring(9), 10)); else if (k.indexOf('cand_') === 0) this.selectDestinationCandidate({ currentTarget: { dataset: { index: parseInt(k.substring(5), 10) } } }); break; } },

  startGuide() { this.setData({ phase: 'pickup_confirm', pickupSelectLandmark: false }); this.rebuildFocusList(); },
  goBackToWelcome() { this.cleanupVoiceRecognition(); this.clearMapRetryTimer(); this.setData({ phase: 'welcome', pickupSelectLandmark: false, selectedDest: null, matchedDest: null, destCandidates: [], voiceInputStatus: 'idle', voiceInputText: '', transportMode: '', transportLabel: '', transportZoneNodeId: '', indoorSteps: [], currentStepIndex: 0, currentStep: null, transitInfo: null, wrongWayMode: false, wrongWayNodes: [], rideHailOrderMode: false, rideHailOrderValues: {}, rideHailOrderSummary: '', busStage: '', mapUnavailable: false, routeMapError: '', detailExpanded: false, currentFloor: this.data.pickupPoint ? this.data.pickupPoint.floor : '' }); this.rebuildFocusList(); },
  goBackLevel() { try { wx.navigateBack({ delta: 1 }); } catch (e) {} },
  confirmPickupPoint() { var pp = this.data.pickupPoint; this.setData({ startNodeId: pp.nodeId, currentLocationLabel: pp.serviceName, currentFloor: pp.floor, phase: 'dest_voice', voiceInputStatus: 'idle', voiceInputText: '' }); this.rebuildFocusList(); },
  showLandmarkSelect() { var ln = []; var an = MOCK_AIRPORT.nodes; for (var i = 0; i < an.length; i++) { var n = an[i]; if (n.type === 'arrival_hall' || n.type === 'exit' || n.type === 'concourse' || n.type === 'corridor' || n.type === 'info_desk' || n.type === 'landmark' || n.type === 'restroom' || n.type === 'elevator' || n.type === 'escalator') ln.push({ id: n.id, name: n.name, floor: n.floor }); } this.setData({ pickupSelectLandmark: true, pickupLandmarkNodes: ln }); this.rebuildFocusList(); },
  selectLandmarkAsStart(e) { var ds = e && e.currentTarget && e.currentTarget.dataset ? e.currentTarget.dataset : {}; this.selectPickupLandmarkByIndex(parseInt(ds.index, 10)); },
  selectPickupLandmarkByIndex(idx) { var lm = this.data.pickupLandmarkNodes[idx]; if (!lm) return; this.setData({ startNodeId: lm.id, currentLocationLabel: lm.name, currentFloor: lm.floor, pickupSelectLandmark: false, phase: 'dest_voice', voiceInputStatus: 'idle', voiceInputText: '' }); this.rebuildFocusList(); },
  cancelLandmarkSelect() { this.setData({ pickupSelectLandmark: false }); this.rebuildFocusList(); },
  goBackToPickupConfirm() { this.cleanupVoiceRecognition(); this.setData({ phase: 'pickup_confirm', voiceInputStatus: 'idle', voiceInputText: '', destCandidates: [], matchedDest: null }); this.rebuildFocusList(); },
  goToTransportSelect() { if (!this.data.selectedDest) return; this.setData({ phase: 'transport_select' }); this.rebuildFocusList(); },
  goBackToDestVoice() { this.setData({ phase: 'dest_voice', voiceInputStatus: 'idle', voiceInputText: '', destCandidates: [], matchedDest: null }); this.rebuildFocusList(); },
  goBackToTransportSelect() { this.clearMapRetryTimer(); this.setData({ phase: 'transport_select', indoorSteps: [], currentStepIndex: 0, currentStep: null, transitInfo: null, wrongWayMode: false, wrongWayNodes: [], rideHailOrderMode: false, rideHailOrderValues: {}, rideHailOrderSummary: '', busStage: '', mapUnavailable: false, routeMapError: '', detailExpanded: false }); this.rebuildFocusList(); },

  selectTransport(e) { var ds = e && e.currentTarget && e.currentTarget.dataset ? e.currentTarget.dataset : {}; this.selectTransportByIndex(parseInt(ds.index, 10)); },
  selectTransportByIndex(idx) { var o = this.data.transportOptions[idx]; if (!o) return; this.setData({ transportMode: o.id, transportLabel: o.label, transportZoneNodeId: o.zoneNodeId }); if (o.id === 'ride_hail') { this.startRideHailOrderMode(); return; } if (o.id === 'bus') { this.startIndoorNav('ticket'); return; } this.startIndoorNav(); },
  startRideHailOrderMode() { var oi = MOCK_AIRPORT.rideHailOrderInfo; this.setData({ phase: 'indoor_nav', rideHailOrderMode: true, rideHailReminder: oi.reminder, rideHailDisclaimer: oi.disclaimer, rideHailOrderFields: oi.orderInputFields, rideHailOrderValues: {}, indoorSteps: [], currentStep: null, wrongWayMode: false }); this.rebuildFocusList(); },
  onOrderFieldInput(e) { var ds = e && e.currentTarget && e.currentTarget.dataset ? e.currentTarget.dataset : {}; var k = ds.key, v = e.detail.value || ''; var nv = {}; var ks = Object.keys(this.data.rideHailOrderValues || {}); for (var i = 0; i < ks.length; i++) nv[ks[i]] = this.data.rideHailOrderValues[ks[i]]; nv[k] = v; this.setData({ rideHailOrderValues: nv }); },
  skipOrderCheck() { this.setData({ rideHailOrderMode: false, rideHailOrderSummary: '未取得订单，已引导到公共网约车候车区' }); this.startIndoorNav(); },
  confirmRideHailOrder() { var v = this.data.rideHailOrderValues || {}, f = this.data.rideHailOrderFields || [], s = ''; for (var i = 0; i < f.length; i++) { var vv = v[f[i].key] || ''; if (vv) s += (s ? '、' : '') + f[i].label + ': ' + vv; } if (!s) s = '未输入订单信息，引导到公共候车区'; else s = '已核对 — ' + s; this.setData({ rideHailOrderMode: false, rideHailOrderSummary: s }); this.startIndoorNav(); },

  startIndoorNav(busStage) {
    var sn = this.data.startNodeId, en = this.data.transportZoneNodeId;
    if (this.data.transportMode === 'bus') {
      busStage = busStage || 'ticket'; var ts = buildBusTwoStageSteps(MOCK_AIRPORT, sn); var steps = busStage === 'ticket' ? ts.ticketSteps : ts.waitingSteps;
      if (!steps || steps.length === 0) { var st = busStage || 'ticket'; this.setData({ phase: 'indoor_nav', busStage: st, indoorSteps: [], currentStepIndex: 0, currentStep: null, currentFloor: st === 'ticket' ? this.data.currentFloor : MOCK_AIRPORT.busTicketData.waitingFloor, wrongWayMode: false, rideHailOrderMode: false, busWaitingLocation: MOCK_AIRPORT.busTicketData.waitingLocation, detailExpanded: false }); this.rebuildFocusList(); return; }
      var fs = steps[0]; fs.landmarkStr = fs.landmarks.join('、'); var sN = getNodeById(MOCK_AIRPORT.nodes, steps[0].fromId); var sF = sN ? sN.floor : this.data.currentFloor; var at = this.computeActionText(fs); var fc = this.computeFloorChange(fs);
      this.setData({ phase: 'indoor_nav', busStage: busStage || 'ticket', indoorSteps: steps, currentStepIndex: 0, currentStep: fs, currentStepIndexP1: 1, progressPercent: 0, currentFloor: sF, currentActionText: at, currentStepFloorChange: fc.change, floorChangeType: fc.type, wrongWayMode: false, rideHailOrderMode: false, busWaitingLocation: MOCK_AIRPORT.busTicketData.waitingLocation, mapUnavailable: false, routeMapError: '', detailExpanded: false });
      this.updateRouteImage(); this.rebuildFocusList(); return;
    }
    var nIds = findNodePath(MOCK_AIRPORT.edges, sn, en); var iSteps = buildIndoorSteps(MOCK_AIRPORT.nodes, nIds, MOCK_AIRPORT.edges);
    if (iSteps.length === 0) { this.setData({ phase: 'indoor_nav', indoorSteps: [], currentStepIndex: 0, currentStep: null, currentFloor: '', wrongWayMode: false, rideHailOrderMode: false, detailExpanded: false }); this.rebuildFocusList(); return; }
    var fs2 = iSteps[0]; fs2.landmarkStr = fs2.landmarks.join('、'); var sN2 = getNodeById(MOCK_AIRPORT.nodes, sn); var sF2 = sN2 ? sN2.floor : ''; var at2 = this.computeActionText(fs2); var fc2 = this.computeFloorChange(fs2);
    this.setData({ phase: 'indoor_nav', indoorSteps: iSteps, currentStepIndex: 0, currentStep: fs2, currentStepIndexP1: 1, progressPercent: 0, currentFloor: sF2, currentActionText: at2, currentStepFloorChange: fc2.change, floorChangeType: fc2.type, wrongWayMode: false, rideHailOrderMode: false, mapUnavailable: false, routeMapError: '', detailExpanded: false });
    this.updateRouteImage(); this.rebuildFocusList();
  },

  advanceStep() {
    var steps = this.data.indoorSteps; if (!steps.length) return;
    var ni = this.data.currentStepIndex + 1;
    if (ni >= steps.length) { if (this.data.transportMode === 'bus' && this.data.busStage === 'ticket') { this.startIndoorNav('waiting'); return; } this.showTransportInfo(); return; }
    var step = steps[ni]; step.landmarkStr = step.landmarks.join('、'); var prog = Math.round((ni / steps.length) * 100);
    var fN = getNodeById(MOCK_AIRPORT.nodes, step.fromId); var nF = fN ? fN.floor : this.data.currentFloor;
    var at = this.computeActionText(step); var fc = this.computeFloorChange(step);
    this.setData({ currentStepIndex: ni, currentStep: step, currentStepIndexP1: ni + 1, progressPercent: prog, currentFloor: nF, currentActionText: at, currentStepFloorChange: fc.change, floorChangeType: fc.type, currentLocationLabel: step.fromName, detailExpanded: false });
    this.updateRouteImage(); this.rebuildFocusList();
  },

  toggleDetail() { this.setData({ detailExpanded: !this.data.detailExpanded }); },
  wrongWay() { var ln = []; var an = MOCK_AIRPORT.nodes; for (var i = 0; i < an.length; i++) { var n = an[i]; if (n.id === this.data.transportZoneNodeId) continue; ln.push({ id: n.id, name: n.name, floor: n.floor }); } this.setData({ wrongWayMode: true, wrongWayNodes: ln }); this.rebuildFocusList(); },
  selectLandmark(e) { var ds = e && e.currentTarget && e.currentTarget.dataset ? e.currentTarget.dataset : {}; this.selectLandmarkByIndex(parseInt(ds.index, 10)); },
  selectLandmarkByIndex(idx) { var lm = this.data.wrongWayNodes[idx]; if (!lm) return; var sn = lm.id, en = this.data.transportZoneNodeId; var nIds = findNodePath(MOCK_AIRPORT.edges, sn, en); var steps = buildIndoorSteps(MOCK_AIRPORT.nodes, nIds, MOCK_AIRPORT.edges); if (steps.length === 0) { this.setData({ wrongWayMode: false, indoorSteps: [], currentStepIndex: 0, currentStep: null, currentFloor: lm.floor }); this.rebuildFocusList(); return; } var fs = steps[0]; fs.landmarkStr = fs.landmarks.join('、'); var sN = getNodeById(MOCK_AIRPORT.nodes, sn); var sF = sN ? sN.floor : lm.floor; var at = this.computeActionText(fs); var fc = this.computeFloorChange(fs); this.setData({ wrongWayMode: false, startNodeId: sn, currentLocationLabel: lm.name, indoorSteps: steps, currentStepIndex: 0, currentStep: fs, currentStepIndexP1: 1, progressPercent: 0, currentFloor: sF, currentActionText: at, currentStepFloorChange: fc.change, floorChangeType: fc.type, mapUnavailable: false, routeMapError: '', detailExpanded: false }); this.updateRouteImage(); this.rebuildFocusList(); },
  cancelWrongWay() { this.setData({ wrongWayMode: false, wrongWayNodes: [] }); this.rebuildFocusList(); this.updateRouteImage(); },

  showTransportInfo() { var m = this.data.transportMode, t = MOCK_AIRPORT.transit, info = null; if (m === 'taxi') info = t.taxiQueue; else if (m === 'ride_hail') info = t.rideHailZone; else if (m === 'metro') info = t.metroEntrance; else if (m === 'bus') info = t.busStop; if (!info) return; var ic = {}; var ks = Object.keys(info); for (var i = 0; i < ks.length; i++) ic[ks[i]] = info[ks[i]]; if (ic.transferStations && ic.transferStations.length) ic.transferStationsStr = ic.transferStations.join('；'); else ic.transferStationsStr = ''; this.setData({ phase: 'transport_info', transitInfo: ic }); this.rebuildFocusList(); },
  showCompletion() { var m = this.data.transportMode, d = this.data.selectedDest, s = ''; if (m === 'taxi') s = '出租车前往 ' + d.name + '（' + d.address + '），打表计费，以实际为准。'; else if (m === 'ride_hail') s = '网约车前往 ' + d.name + '（' + d.address + '），请通过 App 查看行程。'; else if (m === 'metro') { var mt = MOCK_AIRPORT.transit.metroEntrance; s = mt.line + ' ' + mt.direction + '，在 ' + mt.alightStation + ' 下车，从 ' + mt.exitGate + ' 出站。'; } else if (m === 'bus') { var bs = MOCK_AIRPORT.transit.busStop; s = bs.line + ' ' + bs.direction + '，在 ' + bs.alightStop + ' 下车。运营时间：' + bs.operationHours + '。'; } this.setData({ phase: 'completion', completionRideSummary: s }); this.rebuildFocusList(); },

  onKeyUp(event) { if (!event || !event.code) return; var c = event.code; if (c === 'ArrowUp') { this.moveFocus('next'); return; } if (c === 'ArrowDown') { this.moveFocus('prev'); return; } if (c === 'Enter') { this.activateFocused(); return; } if (c === 'Backspace') { if (this.data.phase === 'welcome') this.goBackLevel(); else if (this.data.phase === 'pickup_confirm') { if (this.data.pickupSelectLandmark) this.cancelLandmarkSelect(); else this.goBackToWelcome(); } else if (this.data.phase === 'dest_voice') { if (this.data.voiceInputStatus === 'listening') this.cancelVoiceInput(); else if (this.data.matchedDest) { this.setData({ matchedDest: null, destCandidates: [], voiceInputStatus: 'result' }); this.rebuildFocusList(); } else this.goBackToPickupConfirm(); } else if (this.data.phase === 'transport_select') this.goBackToDestVoice(); else if (this.data.phase === 'indoor_nav') { if (this.data.wrongWayMode) this.cancelWrongWay(); else this.goBackToTransportSelect(); } else if (this.data.phase === 'transport_info') this.goBackToTransportSelect(); else if (this.data.phase === 'completion') this.goBackToTransportSelect(); return; } },
  onVoiceWakeup(event) {}
}
</script>
