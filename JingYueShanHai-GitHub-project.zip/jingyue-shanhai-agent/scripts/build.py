"""Regenerate route images, verify and repackage the source-format AIX.
This is NOT an official AIUI compiler or signer.
"""
from pathlib import Path
import hashlib,json,subprocess,sys,uuid,zipfile
from html.parser import HTMLParser
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
def run(args):
    result=subprocess.run(args,cwd=ROOT,text=True,encoding='utf-8',errors='replace',stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    print(result.stdout,end='')
    if result.returncode:raise SystemExit(result.returncode)
    return result.stdout
class MarkupCheck(HTMLParser):
    def __init__(self):super().__init__();self.stack=[]
    def handle_starttag(self,tag,attrs):self.stack.append(tag)
    def handle_startendtag(self,tag,attrs):pass
    def handle_endtag(self,tag):
        if not self.stack or self.stack.pop()!=tag:raise ValueError('Unbalanced page element: '+tag)
def main():
    (ROOT/'build').mkdir(exist_ok=True);(ROOT/'dist').mkdir(exist_ok=True)
    run(['node','scripts/build-scenes.mjs'])
    run([sys.executable,'scripts/render_assets.py'])
    report=run(['node','--experimental-vm-modules','--disable-warning=ExperimentalWarning','tests/verify.mjs'])
    ink=(ROOT/'pages/index/index.ink').read_text(encoding='utf-8')
    check=MarkupCheck();check.feed(ink[ink.index('<page>'):ink.index('</page>')+7])
    if check.stack:raise ValueError('Unclosed page elements')
    pngs=list((ROOT/'assets/routes').glob('*.png'))
    for file in pngs:
        with Image.open(file) as im:
            im.load()
            if im.size!=(896,260) or not im.getbbox():raise ValueError('Invalid route image: '+str(file))
    report+='PASS page markup and '+str(len(pngs))+' PNG images decoded\n'
    # Include only Agent runtime files, avoiding development tools and credentials.
    names=['AGENTS.md','app.js','app.json','app.wxss']
    for folder in ['pages','utils','assets']:
        names.extend(p.relative_to(ROOT).as_posix() for p in sorted((ROOT/folder).rglob('*')) if p.is_file())
    digest=hashlib.sha256()
    for name in sorted(names):
        digest.update(name.encode('utf-8')+b'\0');digest.update((ROOT/name).read_bytes())
    package_version=str(uuid.uuid5(uuid.NAMESPACE_URL,'jingyue-shanhai:'+digest.hexdigest()))
    archive=ROOT/'dist/JingYueShanHai-v14.3-localmap.aix'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_STORED) as z:
        z.writestr('VERSION',package_version)
        for name in names:z.write(ROOT/name,name)
    with zipfile.ZipFile(archive) as z:
        bad=z.testzip()
        if bad:raise ValueError('Bad ZIP CRC: '+bad)
        if len(z.read('VERSION'))!=36:raise ValueError('Invalid package version marker')
    sha=hashlib.sha256(archive.read_bytes()).hexdigest()
    (ROOT/'dist/SHA256SUMS.txt').write_text(sha+'  '+archive.name+'\n',encoding='utf-8')
    (ROOT/'dist/verification.txt').write_text(report+'PASS archive structure and CRC\nAIUI upload/compiler and real glasses are NOT validated by this build.\n',encoding='utf-8')
    print('Created '+str(archive)+' ('+str(archive.stat().st_size)+' bytes)')
if __name__=='__main__':main()
