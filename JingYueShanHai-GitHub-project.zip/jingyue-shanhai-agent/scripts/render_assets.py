from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import json,math,hashlib
root=Path(__file__).resolve().parents[1]
out=root/'assets/routes';out.mkdir(parents=True,exist_ok=True)
scenes=json.loads((root/'build/scenes.json').read_text(encoding='utf-8'))
manifest={}
# Only remove generated route assets; all other assets are preserved.
for old in out.glob('r_*.png'):
 old.unlink()
font=ImageFont.load_default(size=28)
for scene in scenes:
 ns=scene['nodes']; name='r_'+hashlib.sha256(scene['key'].encode()).hexdigest()[:16]+'.png'
 if scene['cross']:pts=[(150,178),(746,80)]
 else:
  xs=[n['sx'] for n in ns];ys=[n['sy'] for n in ns]
  dx=max(xs)-min(xs);dy=max(ys)-min(ys)
  if dx==0 and dy==0: raise ValueError('Coincident nodes: '+scene['key'])
  scale=min(744/dx if dx else float('inf'),124/dy if dy else float('inf'))
  pts=[(448+(n['sx']-(min(xs)+max(xs))/2)*scale,130+(n['sy']-(min(ys)+max(ys))/2)*scale) for n in ns]
 im=Image.new('RGB',(896,260),'black');d=ImageDraw.Draw(im)
 for i in range(len(pts)-2,-1,-1):d.line([pts[i],pts[i+1]],fill='#00ff41' if i==0 else '#008f30',width=8 if i==0 else 4)
 a,b=pts[:2];ang=math.atan2(b[1]-a[1],b[0]-a[0]);tx=a[0]+(b[0]-a[0])*.55;ty=a[1]+(b[1]-a[1])*.55
 arrow=min(17,math.hypot(b[0]-a[0],b[1]-a[1])/6)
 d.polygon([(tx+arrow*math.cos(ang),ty+arrow*math.sin(ang)),(tx-10*math.cos(ang)+12*math.sin(ang),ty-10*math.sin(ang)-12*math.cos(ang)),(tx-10*math.cos(ang)-12*math.sin(ang),ty-10*math.sin(ang)+12*math.cos(ang))],fill='#00ff41')
 for i in range(len(pts)-1,-1,-1):
  x,y=pts[i];r=12 if i<2 else 5
  d.ellipse((x-r,y-r,x+r,y+r),fill='#00ff41' if i==0 else 'black',outline='#00ff41' if i<2 else '#008f30',width=3)
  if i==1:d.ellipse((x-5,y-5,x+5,y+5),fill='#00ff41')
 d.text((a[0],min(234,a[1]+32)),'1',font=font,fill='#00ff41',anchor='mm')
 box=d.textbbox((b[0]+24,b[1]),'2',font=font,anchor='lm')
 d.rectangle((box[0]-3,box[1]-3,box[2]+3,box[3]+3),fill='black')
 d.text((b[0]+24,b[1]),'2',font=font,fill='#00ff41',anchor='lm')
 im.save(out/name,optimize=True)
 manifest[scene['key']]={'src':'/assets/routes/'+name,'title':scene['title'],'currentId':ns[0]['id'],'nextId':ns[1]['id'],'crossFloor':scene['cross']}
(root/'utils/routeImages.js').write_text('// Generated from bundled MOCK_AIRPORT. Regenerate when nodes/edges change.\nexport const ROUTE_IMAGES = '+json.dumps(manifest,ensure_ascii=False,separators=(',',':'))+';\n',encoding='utf-8')
print('Rendered',len(manifest),'bundled PNG images')
