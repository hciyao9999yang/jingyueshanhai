import fs from 'node:fs';
import {MOCK_AIRPORT as data} from '../utils/mapData.js';
import {findNodePath,buildIndoorSteps} from '../utils/routeEngine.js';
const scenes={};
for(const start of data.nodes) for(const end of data.nodes) {
 const ids=findNodePath(data.edges,start.id,end.id);
 const steps=buildIndoorSteps(data.nodes,ids,data.edges);
 for(let index=0;index<steps.length;index++) {
  const remain=steps.slice(index), key=[remain[0].fromId,...remain.map(s=>s.toId)].join('>');
  if(scenes[key]) continue;
  const nodes=remain.map(s=>data.nodes.find(n=>n.id===s.toId));
  nodes.unshift(data.nodes.find(n=>n.id===remain[0].fromId));
  if(nodes.some(n=>!n||!Number.isFinite(n.sx)||!Number.isFinite(n.sy))) throw Error('Invalid coordinates '+key);
  const cross=nodes[0].floor!==nodes[1].floor;
  const visible=cross?nodes.slice(0,2):nodes.slice(0,nodes.findIndex(n=>n.floor!==nodes[0].floor)<0?nodes.length:nodes.findIndex(n=>n.floor!==nodes[0].floor));
  scenes[key]={key,nodes:visible,cross,title:cross?'换层示意：'+nodes[0].floor+' → '+nodes[1].floor:'本层路线示意 · '+nodes[0].floor};
 }
}
fs.mkdirSync(new URL('../build/',import.meta.url),{recursive:true});
fs.writeFileSync(new URL('../build/scenes.json',import.meta.url),JSON.stringify(Object.values(scenes),null,2));
console.log('Generated '+Object.keys(scenes).length+' route states from '+data.nodes.length+' nodes');
