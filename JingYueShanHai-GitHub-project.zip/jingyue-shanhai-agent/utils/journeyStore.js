// ============================================================
// Journey 状态管理 — localStorage 持久化
// 存储键: journey_state
// ============================================================

const STORAGE_KEY = 'journey_state';

// 生成唯一 Journey ID
export function generateJourneyId() {
  const ts = Date.now().toString(36);
  const rand = Math.random().toString(36).slice(2, 8);
  return 'journey_' + ts + '_' + rand;
}

// 安全读取 localStorage
function safeGetItem(key) {
  try {
    if (typeof localStorage === 'undefined') return null;
    return localStorage.getItem(key);
  } catch (e) {
    return null;
  }
}

// 安全写入 localStorage
function safeSetItem(key, value) {
  try {
    if (typeof localStorage === 'undefined') return false;
    localStorage.setItem(key, value);
    return true;
  } catch (e) {
    return false;
  }
}

// 安全删除 localStorage
function safeRemoveItem(key) {
  try {
    if (typeof localStorage === 'undefined') return false;
    localStorage.removeItem(key);
    return true;
  } catch (e) {
    return false;
  }
}

// 获取当前 Journey 状态
export function getJourney() {
  const raw = safeGetItem(STORAGE_KEY);
  if (!raw) return null;
  try {
    const data = JSON.parse(raw);
    if (data && data.journeyId) {
      return data;
    }
    return null;
  } catch (e) {
    return null;
  }
}

// 保存完整 Journey 状态
export function saveJourney(journey) {
  journey.updatedAt = Date.now();
  const ok = safeSetItem(STORAGE_KEY, JSON.stringify(journey));
  return ok;
}

// 更新 Journey 状态（增量合并）
export function updateJourney(patch) {
  const current = getJourney();
  if (!current) return null;
  const updated = {
    ...current,
    ...patch,
    updatedAt: Date.now()
  };
  // 合并数组字段
  if (patch.completedSegmentIds) {
    updated.completedSegmentIds = patch.completedSegmentIds;
  }
  const ok = safeSetItem(STORAGE_KEY, JSON.stringify(updated));
  return ok ? updated : null;
}

// 创建新 Journey
export function createJourney(airportId) {
  const journey = {
    journeyId: generateJourneyId(),
    status: 'init',
    airportId: airportId,
    pickupPointId: null,
    destinationId: null,
    routeOptionId: null,
    currentSegmentIndex: 0,
    completedSegmentIds: [],
    lastConfirmedNodeId: null,
    // GPS 定位信息（通过 navigator.geolocation 获取后保存）
    lastKnownPosition: null,
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
  saveJourney(journey);
  return journey;
}

// 清除 Journey
export function clearJourney() {
  safeRemoveItem(STORAGE_KEY);
}

// 判断 Journey 是否未完成
export function isJourneyInProgress(journey) {
  if (!journey) return false;
  return journey.status !== 'completed';
}

// 获取存储是否可用
export function isStorageAvailable() {
  try {
    if (typeof localStorage === 'undefined') return false;
    const testKey = '__storage_test__';
    localStorage.setItem(testKey, '1');
    localStorage.removeItem(testKey);
    return true;
  } catch (e) {
    return false;
  }
}
