import { getSegmentTypeLabel } from './routeEngine.js';

// ============================================================
// 语音命令解析 + TTS 播报 + ASR 启动 + 全局语音引导
// 所有语音功能 try/catch 降级，不可用时回退到触控
// ============================================================

// 命令关键词映射（含导航类全局命令）
const COMMAND_KEYWORDS = [
  // —— 全局导航命令 ——
  { command: 'next', keywords: ['下一个', '下一个', '往下', '下移', '下一个选项'] },
  { command: 'prev', keywords: ['上一个', '上一个', '往上', '上移', '上一个选项'] },
  { command: 'confirm', keywords: ['确认', '选择', '确定', '好', '好的', '就是这个'] },
  { command: 'back', keywords: ['返回', '后退', '回去', '退回'] },
  // —— 业务命令 ——
  { command: 'arrived', keywords: ['我到了', '到了', '已到达', '到达'] },
  { command: 'repeat', keywords: ['重复', '重复一下', '再说一遍', '再说一次'] },
  { command: 'wrong_way', keywords: ['走错了', '走错路', '走错', '迷路'] },
  { command: 'change_transport', keywords: ['换交通', '换交通方式', '换个方式', '换乘', '换车'] },
  { command: 'pause', keywords: ['暂停', '停一下', '等一下'] },
  { command: 'resume', keywords: ['继续', '恢复', '继续导航'] },
  { command: 'start_nav', keywords: ['开始导航', '开始', '导航', '出发'] }
];

// 解析语音命令
export function parseVoiceCommand(text) {
  if (!text) return 'unknown';
  const lower = text.toLowerCase().trim();
  for (const item of COMMAND_KEYWORDS) {
    for (const kw of item.keywords) {
      if (lower.includes(kw)) {
        return item.command;
      }
    }
  }
  return 'unknown';
}

// TTS 语音播报
export function speak(text) {
  try {
    if (typeof speechSynthesis === 'undefined') return;
    if (!text) return;
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.0;
    utterance.volume = 1.0;
    speechSynthesis.speak(utterance, 'enqueue');
  } catch (e) {
    // TTS 不可用，静默降级
  }
}

// 全局语音引导播报（自动 TTS，不影响触控操作）
export function guideSpeak(text) {
  try {
    speak(text);
  } catch (e) {
    // 静默降级
  }
}

// 根据页面和阶段返回引导文案
export function getPhaseGuide(page, phase, context) {
  var ctx = context || {};
  var guides = {
    index: {
      welcome: '你好，我是镜越山海，你的机场赴赛向导。我会一步步带你找到昆明长水国际机场的出口和乘车点，前往酒店或赛事领物点。GPS 定位结合 3D 地图实时可视化，立体显示你在机场中的位置和前往目的地的方向。上下滑动切换选项，点击确认。',
      init: '正在初始化镜越山海导航系统。',
      error: '初始化失败。' + (ctx.errorMessage ? ctx.errorMessage : ''),
      resume: '发现未完成行程。' + (ctx.journeyId ? '行程编号 ' + ctx.journeyId : '') + '。请选择继续或重新开始。',
      position_select: '请确认当前位置。可使用自动定位，或在列表中手动选择领取点。上下滑动切换选项，点击确认。',
      dest_type_select: '请选择目的地类型。酒店需核对分店地址，领物点需核对赛事及截止时间。',
      dest_verify: '请核对目的地信息。上下滑动查看选项，点击确认。',
      ready: '行程概览已就绪。点击开始导航，或修改目的地。',
      transport_select: '请选择交通方式。出租车在 A号出口外排队，网约车在 B1 层 P2 区，地铁为 6 号线往市区，公交为机场快线 1 路。上下滑动切换选项，点击确认。',
      indoor_nav: '室内引导第 ' + (ctx.currentIndex !== undefined ? ctx.currentIndex + 1 : 1) + ' 步，共 ' + (ctx.totalSteps ? ctx.totalSteps : 1) + ' 步。' + (ctx.description ? ctx.description : '') + '到达后点击我到了进入下一步。',
      transport_info: '已到达乘车区。请核对乘车信息后上车。上车后可返回重新选择交通方式或返回欢迎页。'
    },
    guidance: {
      guiding: '第 ' + (ctx.currentIndex ? ctx.currentIndex + 1 : 1) + ' 步，共 ' + (ctx.totalSteps ? ctx.totalSteps : 1) + ' 步。' + (ctx.description ? ctx.description : ''),
      arrival: '即将到达目的地。请核对信息后确认到达。'
    },
    routes: {
      list: '已计算 ' + (ctx.count ? ctx.count : 3) + ' 个交通方案。上下滑动查看，点击选择。'
    },
    transport: {
      taxi: '出租车乘车核对。请确认上车地点后排号。点击确认上车。',
      ride_hail: '网约车乘车核对。请到集合点与司机会合。点击确认上车。',
      metro: '地铁乘车核对。请注意线路方向和下车站。到站后点击确认。',
      bus: '公交乘车核对。请注意线路方向和下车站。到站后点击确认。'
    },
    help: {
      select: '遇到了什么情况？上下滑动选择场景，点击确认。',
      wrong_way: '走错路处理。请在列表中选择当前位置，系统将重新规划路线。',
      temp_leave: '行程已暂停。处理完毕后返回引导页面点击继续。',
      change_dest: '改变目的地。将返回首页重新选择，原方案将被清除。',
      network_issue: '网络中断。本地数据仍可使用，恢复后可继续。'
    }
  };

  var pageGuides = guides[page];
  if (!pageGuides) return '';
  return pageGuides[phase] || '';
}

// 取消正在进行的 TTS（AIUI 当前不支持 cancel，保留空函数兼容调用方）
export function cancelSpeak() {
  // AIUI speechSynthesis 当前未暴露 cancel()，此处为空操作
}

// 播报当前路段信息
export function speakSegment(segment) {
  const typeLabel = getSegmentTypeLabel(segment.type);
  let text = typeLabel + '。' + segment.description;
  if (segment.landmarks && segment.landmarks.length > 0) {
    text += '。注意标志：' + segment.landmarks.join('，');
  }
  speak(text);
}

// 检查语音识别是否可用
export function isASRAvailable() {
  try {
    return typeof SpeechRecognition !== 'undefined';
  } catch (e) {
    return false;
  }
}

// 检查 TTS 是否可用
export function isTTSAvailable() {
  try {
    return typeof speechSynthesis !== 'undefined';
  } catch (e) {
    return false;
  }
}

// 启动一次语音识别
export function startRecognition(onResult, onError) {
  try {
    if (typeof SpeechRecognition === 'undefined') return null;

    const recognition = new SpeechRecognition();
    recognition.lang = 'zh-CN';
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onresult = function(event) {
      try {
        if (event.results && event.results.length > 0) {
          const transcript = event.results[0][0].transcript || '';
          onResult(transcript);
        }
      } catch (e) {
        // 解析失败，静默
      }
    };

    recognition.onerror = function(event) {
      if (onError) {
        onError(event && event.error ? event.error : 'unknown');
      }
    };

    recognition.start();
    return recognition;
  } catch (e) {
    return null;
  }
}
