// ============================================================
// 数据包 — 昆明长水国际机场 T1 航站楼 到达接驳指引
// ============================================================
// ⚠️ 模拟，不用于实地导航
// 以下节点坐标为未核实模拟值，示意坐标(sx/sy)为人工设定，
// 非真实机场平面图尺寸。缺少经核实的完整长水机场室内路线数据。
// 数据缺口详见 dataGaps 字段。
// 数据核实日期：待现场核实
// ============================================================

export const MOCK_AIRPORT = {
  airportId: 'KMG-T1',
  name: '昆明长水国际机场',
  terminal: 'T1 航站楼',
  floors: ['B1 地下交通层', '1F 到达层', '2F 出发层'],

  // ⚠️ 模拟声明
  disclaimer: '模拟，不用于实地导航。基于模拟坐标的流程演示，不替代官方航站楼导引。',
  schematicNote: '模拟路线示意图 — 示意坐标仅供可视化参考，非真实平面图尺寸',

  // 数据核实日期
  dataVerifiedDate: '待核实',

  // ---------- 数据缺口声明 ----------
  dataGaps: [
    '缺少经核实的昆明长水机场 T1 完整室内平面图和精确节点坐标',
    '缺少经核实的到达层各出口编号与楼层精确位置',
    '缺少经核实的出租车排队点实时排队长度和等待时间',
    '缺少经核实的机场大巴线路运营时间、票价和实时班次',
    '缺少经核实的网约车候车区实时车位分配信息',
    '缺少经核实的昆明地铁 6 号线实时运营状态和末班车时间',
    '缺少经核实的机场到目的地的实时路况、价格和行驶时间',
    '室内步行距离为估算值，非实测数据'
  ],

  // ---------- 领取点配置（固定起点） ----------
  pickupPoint: {
    airportName: '昆明长水国际机场',
    terminal: 'T1 航站楼',
    floor: '1F 到达层',
    exitGate: 'B 号出口',
    serviceName: '眼镜领取服务点',
    nearbyLandmarks: ['到达出口指示牌', '行李提取区 B 区', '蓝色问询标识'],
    nodeId: 'arrival_hall', // 对应 nodes 中的起点节点
    verifiedDate: '待核实',
    note: '未经现场核实的模拟领取点，实际位置以机场现场为准'
  },

  // ---------- 机场中心坐标 ----------
  airportCenter: {
    latitude: 25.0420,
    longitude: 102.9290,
    zoom: 15
  },

  // ---------- 交通方式选项 ----------
  // 推荐方案由 routeEngine.computeTransportRecommendation 动态计算
  // recommended=true 为默认推荐，reason 为推荐理由
  transportOptions: [
    { id: 'taxi', label: '出租车', zoneNodeId: 'taxi_queue', icon: '🚕', desc: '排队上车，打表前往', recommended: false, reason: '' },
    { id: 'bus', label: '机场大巴', zoneNodeId: 'bus_stop', icon: '🚌', desc: '机场快线，经济实惠', recommended: false, reason: '' },
    { id: 'ride_hail', label: '网约车', zoneNodeId: 'ride_hail_zone', icon: '🚗', desc: 'App 下单，B1 层候车', recommended: false, reason: '' },
    { id: 'metro', label: '地铁', zoneNodeId: 'metro_entrance', icon: '🚇', desc: '6 号线往市区', recommended: false, reason: '' }
  ],

  // ---------- 推荐理由模板 ----------
  // 根据目的地类型和距离匹配推荐方案，理由标注「估算」
  recommendedReasons: {
    metro: {
      short: '费用最低，约 7 元（估算）',
      detail: '推荐地铁：费用最低，约 7 元（估算）。无需担心交通拥堵，但需步行至 B1 层入口。'
    },
    taxi: {
      short: '少步行、少换乘，直达目的地（估算）',
      detail: '推荐出租车：少步行、少换乘，可直达目的地（估算）。排队上车后打表前往，适合带行李出行。'
    },
    ride_hail: {
      short: '较快到达，可提前下单（估算）',
      detail: '推荐网约车：较快到达，可提前在手机 App 下单（估算）。需步行至 B1 层 P2 候车区。'
    },
    bus: {
      short: '经济实惠，适合市区方向（估算）',
      detail: '推荐机场大巴：经济实惠，适合前往市区方向（估算）。需先到售票窗口购票，再至候车点上车。'
    }
  },

  // ---------- 大巴两阶段数据 ----------
  // 第一阶段：引导到售票窗口/购票点
  // 第二阶段：购票后引导到候车点
  busTicketData: {
    ticketNodeId: 'bus_stop', // 售票窗口对应节点（模拟：与公交站同位置）
    ticketLocation: 'B1 层机场公交枢纽站旁售票窗口',
    ticketFloor: 'B1 地下交通层',
    waitingNodeId: 'bus_stop', // 候车点对应节点
    waitingLocation: 'B1 层机场公交枢纽站 3 号站台',
    waitingFloor: 'B1 地下交通层',
    line: '机场快线 1 路',
    direction: '往市区方向',
    alightStop: '拓东体育馆站',
    operationHours: '06:30 - 22:00（模拟，以实际运营为准）',
    ticketPrice: '约 25 元（模拟，以实际票价为准）',
    priceSource: '模拟数据，未接入实时票价接口',
    note: '运营时间和票价为模拟数据，请以机场现场公告为准。无适合线路或已停止运营时请咨询工作人员。'
  },

  // ---------- 网约车订单核对信息 ----------
  rideHailOrderInfo: {
    reminder: '请通过手机现有打车应用（如滴滴、高德等）完成下单。未取得订单时，只能引导到公共网约车候车区域。',
    publicZoneLocation: 'B1 层 P2 停车区',
    publicZoneFloor: 'B1 地下交通层',
    meetingPoint: 'P2-B 区 3 号柱',
    orderInputFields: [
      { key: 'zone', label: '上车区', placeholder: '如 P2-C 区' },
      { key: 'floor', label: '楼层', placeholder: '如 B1' },
      { key: 'spot', label: '车位号', placeholder: '如 12 号' }
    ],
    conflictNote: '如果订单上车区与当前路线不一致，请先确认订单信息，再继续引导。',
    noOrderNote: '未取得订单时，已引导到公共网约车候车区。请在 App 下单后核对上车区信息。',
    disclaimer: '不宣称已经叫车、接单或找到车辆，除非有真实订单结果。'
  },

  // ---------- 节点 ----------
  // 坐标为长水机场 T1 航站楼真实近似坐标
  // sx/sy 为示意平面坐标（0-100 范围），用于 canvas 路线示意图绘制
  // 1F 到达层 sy: 10-40，B1 地下交通层 sy: 60-90，跨楼层在连接处标注
  nodes: [
    {
      id: 'arrival_hall',
      name: '到达大厅',
      floor: '1F 到达层',
      type: 'arrival_hall',
      description: '国内/国际到达出口，设有行李提取区，眼镜领取服务点位于 B 号出口旁',
      landmarks: ['到达出口指示牌', '行李转盘', '蓝色问询标识'],
      lat: 25.0425,
      lng: 102.9295,
      sx: 50,
      sy: 35
    },
    {
      id: 'info_desk',
      name: '问询处',
      floor: '1F 到达层',
      type: 'info_desk',
      description: '航站楼问询服务台',
      landmarks: ['蓝色问询标识'],
      lat: 25.0428,
      lng: 102.9300,
      sx: 70,
      sy: 30
    },
    {
      id: 'corridor_main',
      name: '主通道中段',
      floor: '1F 到达层',
      type: 'corridor',
      description: '到达大厅至出口的主通道中段，连接各出口和交通区',
      landmarks: ['主通道指示牌', '地面引导线'],
      lat: 25.0428,
      lng: 102.9292,
      sx: 50,
      sy: 25
    },
    {
      id: 'exit_concourse',
      name: '出口大厅',
      floor: '1F 到达层',
      type: 'concourse',
      description: '航站楼出口大厅，连接 B 号出口、出租车区和下行扶梯',
      landmarks: ['出口指示牌', '交通区引导标识'],
      lat: 25.0430,
      lng: 102.9290,
      sx: 50,
      sy: 15
    },
    {
      id: 'exit_gate_a',
      name: 'B号出口',
      floor: '1F 到达层',
      type: 'exit',
      description: '通往地面交通中心的主出口，眼镜领取服务点旁',
      landmarks: ['B号出口指示牌', '绿色出口灯'],
      lat: 25.0430,
      lng: 102.9290,
      sx: 65,
      sy: 10
    },
    {
      id: 'elevator_1',
      name: '1号电梯',
      floor: '1F 到达层',
      type: 'elevator',
      description: '通往 B1 地铁层 / 2F 出发层',
      landmarks: ['电梯标识'],
      lat: 25.0432,
      lng: 102.9288,
      sx: 35,
      sy: 15
    },
    {
      id: 'escalator_1',
      name: '下行扶梯',
      floor: '1F 到达层',
      type: 'escalator',
      description: '下行至 B1 地面交通层',
      landmarks: ['扶梯下行标识'],
      lat: 25.0432,
      lng: 102.9292,
      sx: 40,
      sy: 15
    },
    {
      id: 'b1_passage',
      name: 'B1层通道',
      floor: 'B1 地下交通层',
      type: 'corridor',
      description: 'B1 层主通道，连接网约车区、地铁入口和公交站',
      landmarks: ['B1层通道指示牌', '地面引导线'],
      lat: 25.0424,
      lng: 102.9283,
      sx: 40,
      sy: 70
    },
    {
      id: 'taxi_queue',
      name: '出租车上车点',
      floor: '1F 到达层',
      type: 'taxi_queue',
      description: 'B号出口外出租车排队上车区（正规排队点）',
      landmarks: ['出租车标识', '排队栏杆'],
      lat: 25.0435,
      lng: 102.9288,
      sx: 80,
      sy: 10
    },
    {
      id: 'ride_hail_zone',
      name: '网约车上车点',
      floor: 'B1 地下交通层',
      type: 'ride_hail_zone',
      description: 'B1 层 P2 停车区网约车上车点',
      landmarks: ['网约车标识', 'P2 停车区指示'],
      lat: 25.0428,
      lng: 102.9285,
      sx: 20,
      sy: 65
    },
    {
      id: 'metro_entrance',
      name: '地铁入口',
      floor: 'B1 地下交通层',
      type: 'metro_entrance',
      description: '昆明地铁 6 号线长水机场站入口',
      landmarks: ['地铁标识', '6 号线线路图'],
      lat: 25.0422,
      lng: 102.9282,
      sx: 50,
      sy: 80
    },
    {
      id: 'bus_stop',
      name: '公交站',
      floor: 'B1 地下交通层',
      type: 'bus_stop',
      description: '机场大巴与公交线路停靠站，旁设售票窗口',
      landmarks: ['公交标识', '站台编号牌', '售票窗口'],
      lat: 25.0420,
      lng: 102.9278,
      sx: 80,
      sy: 85
    },
    {
      id: 'landmark_atm',
      name: 'ATM取款区',
      floor: '1F 到达层',
      type: 'landmark',
      description: '到达大厅右侧 ATM 自助取款区',
      landmarks: ['银行标识'],
      lat: 25.0426,
      lng: 102.9302,
      sx: 80,
      sy: 35
    },
    {
      id: 'restroom_1',
      name: '卫生间',
      floor: '1F 到达层',
      type: 'restroom',
      description: '到达大厅左侧公共卫生间',
      landmarks: ['卫生间标识'],
      lat: 25.0424,
      lng: 102.9288,
      sx: 20,
      sy: 35
    },
    {
      id: 'checkpoint_transfer',
      name: '换乘通道口',
      floor: 'B1 地下交通层',
      type: 'checkpoint',
      description: 'B1 层地铁与公交换乘通道入口',
      landmarks: ['换乘通道指示牌'],
      lat: 25.0421,
      lng: 102.9280,
      sx: 65,
      sy: 85
    }
  ],

  // ---------- 边（节点间通行关系） ----------
  // 路线从公众区域出发，不穿越到达隔离区、安检区或工作人员通道
  edges: [
    {
      from: 'arrival_hall',
      to: 'corridor_main',
      type: 'walk',
      distance: 30,
      duration: 40,
      description: '从到达出口沿主通道直行约30米，到达主通道中段',
      landmarks: ['主通道指示牌', '地面引导线']
    },
    {
      from: 'arrival_hall',
      to: 'info_desk',
      type: 'walk',
      distance: 40,
      duration: 60,
      description: '从到达出口直行约40米，经过行李提取区，到达问询处',
      landmarks: ['到达出口指示牌', '行李转盘', '蓝色问询标识']
    },
    {
      from: 'arrival_hall',
      to: 'restroom_1',
      type: 'walk',
      distance: 25,
      duration: 35,
      description: '从到达出口左转步行约25米，到达卫生间',
      landmarks: ['卫生间标识']
    },
    {
      from: 'arrival_hall',
      to: 'landmark_atm',
      type: 'walk',
      distance: 30,
      duration: 40,
      description: '从到达出口右转步行约30米，到达 ATM 取款区',
      landmarks: ['银行标识']
    },
    {
      from: 'corridor_main',
      to: 'exit_concourse',
      type: 'walk',
      distance: 30,
      duration: 40,
      description: '沿主通道继续直行约30米，到达出口大厅',
      landmarks: ['出口指示牌', '交通区引导标识']
    },
    {
      from: 'corridor_main',
      to: 'info_desk',
      type: 'walk',
      distance: 20,
      duration: 25,
      description: '从主通道中段右转步行约20米，到达问询处',
      landmarks: ['蓝色问询标识']
    },
    {
      from: 'exit_concourse',
      to: 'exit_gate_a',
      type: 'walk',
      distance: 15,
      duration: 20,
      description: '从出口大厅直行约15米，到达 B号出口',
      landmarks: ['B号出口指示牌', '绿色出口灯']
    },
    {
      from: 'exit_concourse',
      to: 'taxi_queue',
      type: 'walk',
      distance: 30,
      duration: 45,
      description: '从出口大厅左转步行约30米，到达出租车上车点',
      landmarks: ['出租车标识', '排队栏杆']
    },
    {
      from: 'exit_concourse',
      to: 'escalator_1',
      type: 'walk',
      distance: 20,
      duration: 30,
      description: '从出口大厅右转步行约20米，到达下行扶梯',
      landmarks: ['扶梯下行标识']
    },
    {
      from: 'escalator_1',
      to: 'elevator_1',
      type: 'walk',
      distance: 15,
      duration: 20,
      description: '扶梯旁步行约15米，到达 1号电梯',
      landmarks: ['电梯标识']
    },
    {
      from: 'escalator_1',
      to: 'b1_passage',
      type: 'escalator',
      distance: 10,
      duration: 90,
      description: '乘下行扶梯至 B1 层，沿指示步行约10米，到达 B1层通道',
      landmarks: ['扶梯下行标识', 'B1层通道指示牌', '地面引导线']
    },
    {
      from: 'b1_passage',
      to: 'ride_hail_zone',
      type: 'walk',
      distance: 15,
      duration: 20,
      description: '沿 B1 层通道左转步行约15米，到达网约车上车点 P2 停车区',
      landmarks: ['网约车标识', 'P2 停车区指示']
    },
    {
      from: 'b1_passage',
      to: 'metro_entrance',
      type: 'walk',
      distance: 20,
      duration: 30,
      description: '沿 B1 层通道直行约20米，到达地铁 6 号线入口',
      landmarks: ['地铁标识', '6 号线线路图']
    },
    {
      from: 'b1_passage',
      to: 'checkpoint_transfer',
      type: 'walk',
      distance: 25,
      duration: 35,
      description: '沿 B1 层通道右转步行约25米，到达换乘通道口',
      landmarks: ['换乘通道指示牌']
    },
    {
      from: 'checkpoint_transfer',
      to: 'bus_stop',
      type: 'walk',
      distance: 40,
      duration: 60,
      description: '沿换乘通道步行约40米，到达公交站（旁设售票窗口）',
      landmarks: ['公交标识', '站台编号牌', '售票窗口']
    },
    {
      from: 'elevator_1',
      to: 'b1_passage',
      type: 'elevator',
      distance: 10,
      duration: 100,
      description: '乘电梯至 B1 层，出电梯后左转步行约10米，到达 B1层通道',
      landmarks: ['电梯标识', 'B1层通道指示牌']
    },
    {
      from: 'info_desk',
      to: 'corridor_main',
      type: 'walk',
      distance: 20,
      duration: 25,
      description: '从问询处左转步行约20米，回到主通道中段',
      landmarks: ['主通道指示牌']
    },
    {
      from: 'exit_gate_a',
      to: 'taxi_queue',
      type: 'walk',
      distance: 20,
      duration: 30,
      description: '出 B号出口后左转步行约20米，到达出租车上车点',
      landmarks: ['出租车标识', '排队栏杆']
    }
  ],

  // ---------- 交通乘车信息 ----------
  transit: {
    taxiQueue: {
      location: 'B号出口外地面层',
      floor: '1F 到达层',
      estimatedWaitMin: '约 5-15 分钟（模拟，以实际排队为准）',
      queueDescription: '正规出租车排队上车区，高峰期排队约 10-15 分钟，非高峰约 3-5 分钟（模拟）',
      boardingNote: '请确认司机打表，核对目的地地址后再上车',
      destAddressNote: '上车后请向司机说明目的地名称和地址'
    },
    rideHailZone: {
      location: 'B1 层 P2 停车区',
      floor: 'B1 地下交通层',
      meetingPoint: 'P2-B 区 3 号柱',
      pickupNote: '请在 App 上确认车牌与司机信息，到 P2-B 区 3 号柱与司机会合'
    },
    metroEntrance: {
      entranceLocation: 'B1 层长水机场站',
      floor: 'B1 地下交通层',
      line: '昆明地铁 6 号线',
      direction: '往塘子巷方向（市区）',
      transferStations: ['东风广场站（换乘 3 号线）', '塘子巷站（换乘 2 号线）'],
      alightStation: '东风广场站',
      exitGate: 'C 出口',
      estimatedRideMin: '约 20 分钟（模拟，以实际运营为准）',
      operationHours: '06:30 - 22:00（模拟，请以实际运营时间为准）',
      ticketNote: '可在入口处自动售票机或客服窗口购票',
      securityNote: '进站前需通过安检，请配合检查行李',
      boardingNote: '请在站台确认列车方向为「往塘子巷方向」后再上车'
    },
    busStop: {
      stopLocation: 'B1 层机场公交枢纽站 3 号站台',
      floor: 'B1 地下交通层',
      line: '机场快线 1 路',
      direction: '往市区方向',
      alightStop: '拓东体育馆站',
      estimatedRideMin: '约 40 分钟（模拟，以实际路况为准）',
      operationHours: '06:30 - 22:00（模拟，请以实际运营为准）',
      ticketPrice: '约 25 元（模拟，以实际票价为准）',
      priceSource: '模拟数据，未接入实时票价接口'
    }
  },

  // ---------- 目的地 ----------
  // 昆明市区真实地点坐标（近似值）
  // destCandidates 字段用于重名消歧：存在多个校区/分店时列出候选
  destinations: [
    {
      id: 'hotel_kunming_sport',
      type: 'hotel',
      name: '昆明海埂大酒店',
      address: '昆明市西山区滇池路 1288 号',
      lat: 24.9760,
      lng: 102.6670,
      destCandidates: []
    },
    {
      id: 'pickup_race_kunming',
      type: 'pickup_point',
      name: '昆明高原半程马拉松领物中心',
      address: '昆明市呈贡区昆明呈贡体育中心',
      eventName: '昆明高原半程马拉松',
      pickupDeadline: '比赛前一日 20:00',
      lat: 24.8860,
      lng: 102.8210,
      destCandidates: []
    },
    {
      id: 'yunnan_university',
      type: 'school',
      name: '云南大学',
      address: '昆明市呈贡区大学城云南大学呈贡校区',
      lat: 24.8900,
      lng: 102.8300,
      destCandidates: [
        { name: '云南大学（呈贡校区）', address: '昆明市呈贡区大学城云南大学呈贡校区', lat: 24.8900, lng: 102.8300 },
        { name: '云南大学（东陆校区）', address: '昆明市五华区翠湖北路 2 号', lat: 25.0520, lng: 102.7020 }
      ]
    },
    {
      id: 'dianchi_scenic',
      type: 'scenic',
      name: '滇池海埂公园',
      address: '昆明市西山区滇池路 1312 号',
      lat: 24.9800,
      lng: 102.6650,
      destCandidates: []
    }
  ]
};
