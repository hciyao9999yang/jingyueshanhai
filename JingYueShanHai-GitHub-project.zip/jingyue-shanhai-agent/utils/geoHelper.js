// ============================================================
// 地理位置工具模块
// 封装 Geolocation API、坐标到节点匹配、GPX 轨迹生成
// 基于 AIUI Geolocation API 和 GPXDocument API
// ============================================================

import { GPXDocument } from 'gpx';

// 定位错误码映射
var LOCATION_ERRORS = {
  1: 'PERMISSION_DENIED',
  2: 'POSITION_UNAVAILABLE',
  3: 'TIMEOUT'
};

// 定位错误消息映射
var LOCATION_ERROR_MESSAGES = {
  1: '定位权限被拒绝，请在系统设置中允许定位',
  2: '定位不可用，请检查设备 GPS 信号',
  3: '定位超时，请重试或手动选择位置'
};

/**
 * 获取当前位置（一次性）
 * @param {function} success - 回调，参数 { latitude, longitude, accuracy, timestamp }
 * @param {function} error - 回调，参数 { code, message }
 * @param {object} options - 可选：enableHighAccuracy, timeout, maximumAge
 */
export function getCurrentLocation(success, error, options) {
  if (typeof navigator === 'undefined' || !navigator.geolocation) {
    if (error) error({ code: 2, message: '设备不支持定位功能' });
    return;
  }

  var opts = options || { enableHighAccuracy: true, timeout: 10000, maximumAge: 5000 };

  try {
    navigator.geolocation.getCurrentPosition(
      function(position) {
        var coords = position.coords;
        success({
          latitude: coords.latitude,
          longitude: coords.longitude,
          accuracy: coords.accuracy,
          altitude: coords.altitude,
          heading: coords.heading,
          speed: coords.speed,
          timestamp: position.timestamp
        });
      },
      function(err) {
        var code = err.code || 2;
        var message = LOCATION_ERROR_MESSAGES[code] || (err.message || '定位失败');
        if (error) error({ code: code, message: message, errorType: LOCATION_ERRORS[code] || 'UNKNOWN' });
      },
      opts
    );
  } catch (e) {
    if (error) error({ code: 2, message: '定位调用异常: ' + String(e) });
  }
}

/**
 * 启动持续位置监听（watchPosition）
 * 返回 watchId，用于后续 clearWatch 释放
 *
 * @param {function} success - 每次位置更新的回调，参数 { latitude, longitude, accuracy, altitude, heading, speed, timestamp }
 * @param {function} error - 错误回调，参数 { code, message }
 * @param {object} options - 可选：enableHighAccuracy, timeout, maximumAge
 * @returns {number|null} watchId，失败返回 null
 */
export function startWatchLocation(success, error, options) {
  if (typeof navigator === 'undefined' || !navigator.geolocation) {
    if (error) error({ code: 2, message: '设备不支持定位功能' });
    return null;
  }

  var opts = options || { enableHighAccuracy: true, timeout: 15000, maximumAge: 3000 };

  try {
    var watchId = navigator.geolocation.watchPosition(
      function(position) {
        var coords = position.coords;
        success({
          latitude: coords.latitude,
          longitude: coords.longitude,
          accuracy: coords.accuracy,
          altitude: coords.altitude,
          heading: coords.heading,
          speed: coords.speed,
          timestamp: position.timestamp
        });
      },
      function(err) {
        var code = err.code || 2;
        var message = LOCATION_ERROR_MESSAGES[code] || (err.message || '定位失败');
        if (error) error({ code: code, message: message, errorType: LOCATION_ERRORS[code] || 'UNKNOWN' });
      },
      opts
    );
    return watchId;
  } catch (e) {
    if (error) error({ code: 2, message: '定位监听启动异常: ' + String(e) });
    return null;
  }
}

/**
 * 停止位置监听（clearWatch）
 * @param {number} watchId - startWatchLocation 返回的 watchId
 */
export function stopWatchLocation(watchId) {
  if (watchId === null || watchId === undefined) return;
  if (typeof navigator === 'undefined' || !navigator.geolocation) return;
  try {
    navigator.geolocation.clearWatch(watchId);
  } catch (e) {
    console.warn('[geoHelper] clearWatch 异常:', e);
  }
}

/**
 * 计算两个坐标之间的 Haversine 距离（米）
 * @param {number} lat1 - 纬度1
 * @param {number} lng1 - 经度1
 * @param {number} lat2 - 纬度2
 * @param {number} lng2 - 经度2
 * @returns {number} 距离（米）
 */
export function haversineDistance(lat1, lng1, lat2, lng2) {
  var R = 6371000; // 地球半径（米）
  var dLat = (lat2 - lat1) * Math.PI / 180;
  var dLng = (lng2 - lng1) * Math.PI / 180;
  var a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLng / 2) * Math.sin(dLng / 2);
  var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/**
 * 计算从坐标1到坐标2的方位角
 * 返回中文方位描述（如"东北"、"正北"等）
 * @param {number} lat1 - 起点纬度
 * @param {number} lng1 - 起点经度
 * @param {number} lat2 - 终点纬度
 * @param {number} lng2 - 终点经度
 * @returns {string} 中文方位描述
 */
export function calcBearing(lat1, lng1, lat2, lng2) {
  var dLng = (lng2 - lng1) * Math.PI / 180;
  var lat1Rad = lat1 * Math.PI / 180;
  var lat2Rad = lat2 * Math.PI / 180;

  var y = Math.sin(dLng) * Math.cos(lat2Rad);
  var x = Math.cos(lat1Rad) * Math.sin(lat2Rad) -
          Math.sin(lat1Rad) * Math.cos(lat2Rad) * Math.cos(dLng);
  var bearing = Math.atan2(y, x) * 180 / Math.PI;
  // 归一化到 0-360
  bearing = (bearing + 360) % 360;

  // 转换为中文方位
  var directions = [
    '正北', '东北偏北', '东北', '东北偏东', '正东', '东南偏东', '东南', '东南偏南',
    '正南', '西南偏南', '西南', '西南偏西', '正西', '西北偏西', '西北', '西北偏北'
  ];
  var idx = Math.round(bearing / 22.5) % 16;
  return directions[idx];
}

/**
 * 格式化距离为人类可读字符串
 * @param {number} meters - 距离（米）
 * @returns {string} 格式化后的距离
 */
export function formatDistance(meters) {
  if (meters < 1) return '< 1 米';
  if (meters < 1000) return Math.round(meters) + ' 米';
  var km = meters / 1000;
  if (km < 10) return km.toFixed(2) + ' 公里';
  if (km < 100) return km.toFixed(1) + ' 公里';
  return Math.round(km) + ' 公里';
}

/**
 * 在节点列表中查找距离指定坐标最近的节点
 * @param {array} nodes - 节点列表（需含 lat/lng 字段）
 * @param {number} latitude - 纬度
 * @param {number} longitude - 经度
 * @returns {object|null} 最近节点及距离 { node, distance }
 */
export function getNearestNode(nodes, latitude, longitude) {
  if (!nodes || !nodes.length) return null;

  var nearest = null;
  var minDist = Infinity;

  for (var i = 0; i < nodes.length; i++) {
    var n = nodes[i];
    if (typeof n.lat !== 'number' || typeof n.lng !== 'number') continue;
    var dist = haversineDistance(latitude, longitude, n.lat, n.lng);
    if (dist < minDist) {
      minDist = dist;
      nearest = n;
    }
  }

  if (!nearest) return null;
  return { node: nearest, distance: Math.round(minDist) };
}

/**
 * 构建 GPX 轨迹 XML 字符串
 * 用于 map-gpx 组件的 data 属性渲染路线轨迹
 *
 * @param {object} startPoint - 起点 { latitude, longitude, name? }
 * @param {array} trackPoints - 途经点数组 [{ latitude, longitude, name? }]
 * @param {object} endPoint - 终点 { latitude, longitude, name? }
 * @returns {string} GPX XML 字符串
 */
export function buildRouteGPX(startPoint, trackPoints, endPoint) {
  try {
    var doc = new GPXDocument();

    doc.setStartPoint({
      latitude: startPoint.latitude,
      longitude: startPoint.longitude,
      name: startPoint.name || '起点'
    });

    if (trackPoints && trackPoints.length) {
      for (var i = 0; i < trackPoints.length; i++) {
        var tp = trackPoints[i];
        doc.appendTrackPoint({
          latitude: tp.latitude,
          longitude: tp.longitude,
          name: tp.name || ''
        });
      }
    }

    doc.setEndPoint({
      latitude: endPoint.latitude,
      longitude: endPoint.longitude,
      name: endPoint.name || '终点'
    });

    return doc.toString();
  } catch (e) {
    console.error('[geoHelper] buildRouteGPX 失败:', e);
    return '';
  }
}

/**
 * 构建地图叠加 GPX（含起点、终点、机场节点航点）
 * 用于在地图上同时显示用户位置、目的地和机场关键节点
 *
 * - 起点（绿色）：用户当前 GPS 位置
 * - 终点（红色）：选中的目的地（如有）
 * - 航点（默认色）：机场关键节点（出口、出租车区、地铁入口等）
 *
 * @param {object} userPosition - 用户位置 { latitude, longitude }
 * @param {array} waypoints - 航点列表 [{ latitude, longitude, name }]
 * @param {object|null} endPoint - 目的地 { latitude, longitude, name? }，无目的地时传 null
 * @returns {string} GPX XML 字符串
 */
export function buildMapOverlayGPX(userPosition, waypoints, endPoint) {
  try {
    var doc = new GPXDocument();

    // 起点：用户当前位置
    doc.setStartPoint({
      latitude: userPosition.latitude,
      longitude: userPosition.longitude,
      name: '我的位置'
    });

    // 航点：机场关键节点
    if (waypoints && waypoints.length) {
      for (var i = 0; i < waypoints.length; i++) {
        var wp = waypoints[i];
        if (typeof wp.lat === 'number') {
          doc.addWaypoint({
            latitude: wp.lat,
            longitude: wp.lng,
            name: wp.name || ''
          });
        } else if (typeof wp.latitude === 'number') {
          doc.addWaypoint({
            latitude: wp.latitude,
            longitude: wp.longitude,
            name: wp.name || ''
          });
        }
      }
    }

    // 终点：选中的目的地（如有）
    if (endPoint && typeof endPoint.lat === 'number') {
      doc.setEndPoint({
        latitude: endPoint.lat,
        longitude: endPoint.lng,
        name: endPoint.name || '目的地'
      });
    } else if (endPoint && typeof endPoint.latitude === 'number') {
      doc.setEndPoint({
        latitude: endPoint.latitude,
        longitude: endPoint.longitude,
        name: endPoint.name || '目的地'
      });
    } else {
      // 无目的地时，终点设为用户位置（不显示红色终点）
      doc.setEndPoint({
        latitude: userPosition.latitude,
        longitude: userPosition.longitude,
        name: '我的位置'
      });
    }

    return doc.toString();
  } catch (e) {
    console.error('[geoHelper] buildMapOverlayGPX 失败:', e);
    return '';
  }
}

/**
 * 构建室内导航路线 GPX
 * 在地图上绘制从用户位置到目标乘车区的室内步行路线
 *
 * - 起点（绿色）：用户当前 GPS 位置
 * - 轨迹点：路径经过的每个节点（用 appendTrackPoint 连线）
 * - 终点（红色）：目标乘车区节点
 * - 航点：全部机场关键节点（显示建筑物/出口/交通区位置）
 *
 * @param {object} userPosition - 用户 GPS 位置 { latitude, longitude }
 * @param {array} nodes - 全部节点列表（含 lat/lng）
 * @param {array} pathNodeIds - 路径节点 ID 序列（从起点到终点）
 * @returns {string} GPX XML 字符串
 */
export function buildIndoorRouteGPX(userPosition, nodes, pathNodeIds) {
  try {
    var doc = new GPXDocument();

    // 起点：用户当前 GPS 位置
    doc.setStartPoint({
      latitude: userPosition.latitude,
      longitude: userPosition.longitude,
      name: '我的位置'
    });

    // 轨迹点：路径经过的每个节点（连线形成室内步行路线）
    if (pathNodeIds && pathNodeIds.length > 0) {
      for (var i = 0; i < pathNodeIds.length; i++) {
        var node = null;
        for (var j = 0; j < nodes.length; j++) {
          if (nodes[j].id === pathNodeIds[i]) {
            node = nodes[j];
            break;
          }
        }
        if (node && typeof node.lat === 'number' && typeof node.lng === 'number') {
          doc.appendTrackPoint({
            latitude: node.lat,
            longitude: node.lng,
            name: node.name || ''
          });
        }
      }
    }

    // 终点：路径最后一个节点（目标乘车区）
    if (pathNodeIds && pathNodeIds.length > 0) {
      var endId = pathNodeIds[pathNodeIds.length - 1];
      var endNode = null;
      for (var k = 0; k < nodes.length; k++) {
        if (nodes[k].id === endId) {
          endNode = nodes[k];
          break;
        }
      }
      if (endNode && typeof endNode.lat === 'number') {
        doc.setEndPoint({
          latitude: endNode.lat,
          longitude: endNode.lng,
          name: endNode.name || '乘车区'
        });
      }
    }

    // 航点：全部机场关键节点（在地图上显示所有设施位置）
    if (nodes && nodes.length) {
      var waypointTypes = ['exit', 'taxi_queue', 'ride_hail_zone', 'metro_entrance', 'bus_stop', 'elevator', 'escalator', 'corridor', 'concourse'];
      for (var m = 0; m < nodes.length; m++) {
        var n = nodes[m];
        if (waypointTypes.indexOf(n.type) >= 0 && typeof n.lat === 'number') {
          doc.addWaypoint({
            latitude: n.lat,
            longitude: n.lng,
            name: n.name || ''
          });
        }
      }
    }

    return doc.toString();
  } catch (e) {
    console.error('[geoHelper] buildIndoorRouteGPX 失败:', e);
    return '';
  }
}

/**
 * 从路线段的节点序列构建 GPX 轨迹
 * @param {array} nodes - 全部节点列表
 * @param {array} nodeIds - 路径经过的节点 ID 序列
 * @returns {string} GPX XML 字符串
 */
export function buildGPXFromNodePath(nodes, nodeIds) {
  if (!nodeIds || !nodeIds.length) return '';

  var points = [];
  for (var i = 0; i < nodeIds.length; i++) {
    var node = nodes.find(function(n) { return n.id === nodeIds[i]; });
    if (node && typeof node.lat === 'number' && typeof node.lng === 'number') {
      points.push({ latitude: node.lat, longitude: node.lng, name: node.name });
    }
  }

  if (points.length < 2) return '';

  var start = points[0];
  var end = points[points.length - 1];
  var middle = points.slice(1, -1);

  return buildRouteGPX(start, middle, end);
}

/**
 * 检查定位功能是否可用
 * @returns {boolean}
 */
export function isGeolocationAvailable() {
  try {
    return typeof navigator !== 'undefined' && !!navigator.geolocation;
  } catch (e) {
    return false;
  }
}
