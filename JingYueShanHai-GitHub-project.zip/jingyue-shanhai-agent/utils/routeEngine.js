// ============================================================
// 路线引擎 — BFS 最短路径 + 室内分段引导 + 交通方案推荐
// 程序负责路线计算，模型只负责理解需求和解释方案
// ============================================================

// 构建邻接表
function buildAdjacencyList(edges) {
  const adj = new Map();
  for (const edge of edges) {
    // 正向
    if (!adj.has(edge.from)) adj.set(edge.from, []);
    adj.get(edge.from).push(edge);
    // 反向（双向通行）
    const reverse = {
      ...edge,
      from: edge.to,
      to: edge.from
    };
    if (!adj.has(reverse.from)) adj.set(reverse.from, []);
    adj.get(reverse.from).push(reverse);
  }
  return adj;
}

// BFS 查找最短路径（按距离）
export function findShortestPath(edges, startId, endId) {
  const adj = buildAdjacencyList(edges);
  const visited = new Set([startId]);
  const queue = [
    { nodeId: startId, path: [] }
  ];

  while (queue.length > 0) {
    const current = queue.shift();
    const nodeId = current.nodeId;
    const path = current.path;
    if (nodeId === endId) return path;

    const neighbors = adj.get(nodeId) || [];
    for (const edge of neighbors) {
      if (!visited.has(edge.to)) {
        visited.add(edge.to);
        queue.push({ nodeId: edge.to, path: [...path, edge] });
      }
    }
  }
  return [];
}

// BFS 查找最短路径，返回节点 ID 序列（含起点和终点）
// 用于室内导航：从用户最近节点到目标乘车区节点
export function findNodePath(edges, startId, endId) {
  if (startId === endId) return [startId];

  const adj = buildAdjacencyList(edges);
  const visited = new Set([startId]);
  const queue = [
    { nodeId: startId, nodePath: [startId] }
  ];

  while (queue.length > 0) {
    const current = queue.shift();
    const nodeId = current.nodeId;
    const nodePath = current.nodePath;
    if (nodeId === endId) return nodePath;

    const neighbors = adj.get(nodeId) || [];
    for (const edge of neighbors) {
      if (!visited.has(edge.to)) {
        visited.add(edge.to);
        queue.push({ nodeId: edge.to, nodePath: [...nodePath, edge.to] });
      }
    }
  }
  return [];
}

// 根据 ID 获取节点
export function getNodeById(nodes, id) {
  for (var i = 0; i < nodes.length; i++) {
    if (nodes[i].id === id) return nodes[i];
  }
  return null;
}

// 构建室内分段引导步骤
// 从节点 ID 序列 + edges 构建人类可读的引导步骤列表
// 每步包含：fromName, toName, direction, description, landmarks, distance, duration, floor
export function buildIndoorSteps(nodes, nodeIds, edges) {
  if (!nodeIds || nodeIds.length < 2) return [];

  var steps = [];
  var adj = buildAdjacencyList(edges);

  for (var i = 0; i < nodeIds.length - 1; i++) {
    var fromId = nodeIds[i];
    var toId = nodeIds[i + 1];
    var fromNode = getNodeById(nodes, fromId);
    var toNode = getNodeById(nodes, toId);

    // 查找 fromId → toId 的边
    var edge = null;
    var neighbors = adj.get(fromId) || [];
    for (var j = 0; j < neighbors.length; j++) {
      if (neighbors[j].to === toId) {
        edge = neighbors[j];
        break;
      }
    }

    if (!edge) {
      // 找不到直接边，跳过
      continue;
    }

    // 方向描述
    var direction = '';
    if (edge.type === 'escalator') {
      direction = '乘扶梯下行';
    } else if (edge.type === 'elevator') {
      direction = '乘电梯下楼';
    } else {
      direction = '步行';
    }

    steps.push({
      index: i,
      fromId: fromId,
      toId: toId,
      fromName: fromNode ? fromNode.name : fromId,
      toName: toNode ? toNode.name : toId,
      fromFloor: fromNode ? fromNode.floor : '',
      toFloor: toNode ? toNode.floor : '',
      direction: direction,
      type: edge.type,
      description: edge.description,
      landmarks: edge.landmarks || [],
      distance: edge.distance,
      duration: edge.duration
    });
  }

  // 重新编号
  steps.forEach(function(s, i) { s.index = i; });
  return steps;
}

// 从节点列表中获取节点名
function getNodeName(nodes, id) {
  const node = nodes.find(function(n) { return n.id === id; });
  return node ? node.name : id;
}

// 查找到达大厅到指定交通区起点的步行路段
function buildAirportWalkSegments(mapData, pickupPointId, targetNodeId) {
  const path = findShortestPath(mapData.edges, pickupPointId, targetNodeId);
  const segments = path.map(function(edge, i) {
    return {
      index: i,
      type: 'airport_walk',
      fromNode: edge.from,
      toNode: edge.to,
      description: edge.description,
      landmarks: edge.landmarks || [],
      requiresBoardingCheck: false
    };
  });
  // 重新编号
  segments.forEach(function(s, i) { s.index = i; });
  return segments;
}

// 重新编号路段
function reindexSegments(segments) {
  segments.forEach(function(s, i) { s.index = i; });
}

// 计算步行总距离
function sumWalkDistance(mapData, startId, endId) {
  const path = findShortestPath(mapData.edges, startId, endId);
  return path.reduce(function(sum, e) { return sum + e.distance; }, 0);
}

// 计算三种交通方案
export function computeRouteOptions(mapData, pickupPointId, destination) {
  const options = [];

  // ----- 方案1: 网约车（更快到达） -----
  const rideHailWalk = buildAirportWalkSegments(
    mapData,
    pickupPointId,
    'ride_hail_zone'
  );
  const rideHailSegments = [
    ...rideHailWalk,
    {
      index: 0,
      type: 'ride_hail_boarding',
      fromNode: 'ride_hail_zone',
      toNode: 'ride_hail_zone',
      description: '在 ' + mapData.transit.rideHailZone.location + ' 上车，前往 ' + destination.name,
      landmarks: [
        mapData.transit.rideHailZone.meetingPoint,
        mapData.transit.rideHailZone.pickupNote
      ],
      requiresBoardingCheck: true,
      transportMode: 'ride_hail'
    },
    {
      index: 0,
      type: 'final_walk',
      fromNode: 'ride_hail_zone',
      toNode: 'destination',
      description: '网约车送达 ' + destination.address + '，下车后步行至 ' + destination.name,
      landmarks: ['目的地建筑标识', '导航终点'],
      requiresBoardingCheck: false
    },
    {
      index: 0,
      type: 'arrival',
      fromNode: 'destination',
      toNode: 'destination',
      description: '已到达 ' + destination.name + '，请核对地址：' + destination.address,
      landmarks: [],
      requiresBoardingCheck: false
    }
  ];
  reindexSegments(rideHailSegments);
  const rideHailWalkDist = sumWalkDistance(mapData, pickupPointId, 'ride_hail_zone');
  options.push({
    id: 'route_ride_hail',
    strategy: 'fastest',
    strategyLabel: '更快到达',
    transportMode: 'ride_hail',
    totalTime: 28,
    totalCost: 30,
    walkDistance: rideHailWalkDist + 50,
    transferCount: 0,
    segments: rideHailSegments
  });

  // ----- 方案2: 地铁（费用更低） -----
  const metroWalk = buildAirportWalkSegments(
    mapData,
    pickupPointId,
    'metro_entrance'
  );
  const metroSegments = [
    ...metroWalk,
    {
      index: 0,
      type: 'metro_boarding',
      fromNode: 'metro_entrance',
      toNode: 'metro_entrance',
      description: '在 ' + mapData.transit.metroEntrance.entranceLocation + ' 乘坐 ' + mapData.transit.metroEntrance.line + '，' + mapData.transit.metroEntrance.direction + '，在 ' + mapData.transit.metroEntrance.alightStation + ' 下车',
      landmarks: [
        mapData.transit.metroEntrance.line,
        mapData.transit.metroEntrance.direction,
        '下车站：' + mapData.transit.metroEntrance.alightStation,
        '出站口：' + mapData.transit.metroEntrance.exitGate
      ],
      requiresBoardingCheck: true,
      transportMode: 'metro'
    },
    {
      index: 0,
      type: 'disembark',
      fromNode: 'metro_entrance',
      toNode: 'destination',
      description: '在 ' + mapData.transit.metroEntrance.alightStation + ' ' + mapData.transit.metroEntrance.exitGate + ' 出站，步行至 ' + destination.name,
      landmarks: [mapData.transit.metroEntrance.exitGate, '目的地方向指示'],
      requiresBoardingCheck: false
    },
    {
      index: 0,
      type: 'final_walk',
      fromNode: 'destination',
      toNode: 'destination',
      description: '沿 ' + mapData.transit.metroEntrance.exitGate + ' 出站后步行约300米，到达 ' + destination.name,
      landmarks: ['目的地建筑标识'],
      requiresBoardingCheck: false
    },
    {
      index: 0,
      type: 'arrival',
      fromNode: 'destination',
      toNode: 'destination',
      description: '已到达 ' + destination.name + '，请核对地址：' + destination.address,
      landmarks: [],
      requiresBoardingCheck: false
    }
  ];
  reindexSegments(metroSegments);
  const metroWalkDist = sumWalkDistance(mapData, pickupPointId, 'metro_entrance');
  options.push({
    id: 'route_metro',
    strategy: 'cheapest',
    strategyLabel: '费用更低',
    transportMode: 'metro',
    totalTime: 39,
    totalCost: 7,
    walkDistance: metroWalkDist + 300,
    transferCount: mapData.transit.metroEntrance.transferStations.length,
    segments: metroSegments
  });

  // ----- 方案3: 出租车（少走路） -----
  const taxiWalk = buildAirportWalkSegments(
    mapData,
    pickupPointId,
    'taxi_queue'
  );
  const taxiSegments = [
    ...taxiWalk,
    {
      index: 0,
      type: 'taxi_boarding',
      fromNode: 'taxi_queue',
      toNode: 'taxi_queue',
      description: '在 ' + mapData.transit.taxiQueue.location + ' 排队上车，前往 ' + destination.name + '（' + destination.address + '）',
      landmarks: [
        mapData.transit.taxiQueue.queueDescription,
        mapData.transit.taxiQueue.boardingNote
      ],
      requiresBoardingCheck: true,
      transportMode: 'taxi'
    },
    {
      index: 0,
      type: 'final_walk',
      fromNode: 'taxi_queue',
      toNode: 'destination',
      description: '出租车送达 ' + destination.address + '，下车后步行至 ' + destination.name,
      landmarks: ['目的地建筑标识'],
      requiresBoardingCheck: false
    },
    {
      index: 0,
      type: 'arrival',
      fromNode: 'destination',
      toNode: 'destination',
      description: '已到达 ' + destination.name + '，请核对地址：' + destination.address,
      landmarks: [],
      requiresBoardingCheck: false
    }
  ];
  reindexSegments(taxiSegments);
  const taxiWalkDist = sumWalkDistance(mapData, pickupPointId, 'taxi_queue');
  options.push({
    id: 'route_taxi',
    strategy: 'least_walk',
    strategyLabel: '少走路少换乘',
    transportMode: 'taxi',
    totalTime: 31,
    totalCost: 38,
    walkDistance: taxiWalkDist + 30,
    transferCount: 0,
    segments: taxiSegments
  });

  return options;
}

// 根据 ID 获取方案
export function getRouteOptionById(options, id) {
  return options.find(function(o) { return o.id === id; });
}

// 获取当前路段
export function getCurrentSegment(option, index) {
  if (index < 0 || index >= option.segments.length) return null;
  return option.segments[index];
}

// 路段类型中文标签
export function getSegmentTypeLabel(type) {
  const labels = {
    airport_walk: '机场内步行',
    taxi_boarding: '出租车上车',
    ride_hail_boarding: '网约车上车',
    metro_boarding: '地铁乘车',
    bus_boarding: '公交乘车',
    disembark: '下车出站',
    final_walk: '末端步行',
    arrival: '到达确认',
    transfer: '换乘'
  };
  return labels[type] || type;
}

// 交通方式中文标签
export function getTransportLabel(mode) {
  const labels = {
    taxi: '出租车',
    ride_hail: '网约车',
    metro: '地铁',
    bus: '公交'
  };
  return labels[mode] || mode;
}

// ============================================================
// 新增：交通方案推荐计算
// 根据目的地类型和距离计算推荐方案+理由
// 推荐理由标注「估算」，不编造精确实时价格
// ============================================================
export function computeTransportRecommendation(mapData, destination) {
  var reasons = mapData.recommendedReasons || {};
  var destLat = destination.lat;
  var destLng = destination.lng;
  var centerLat = mapData.airportCenter.latitude;
  var centerLng = mapData.airportCenter.longitude;

  // 计算大致距离
  var dist = haversineDistance(centerLat, centerLng, destLat, destLng);
  var distKm = dist / 1000;

  var recommendedId = '';
  var reasonKey = '';

  // 简单推荐逻辑：
  // - 距离 > 15km：推荐出租车（少步行、直达）
  // - 距离 8-15km：推荐网约车（较快到达）
  // - 距离 < 8km 且市区方向：推荐地铁（费用低）
  // - 市区方向且经济优先：推荐大巴
  if (distKm > 15) {
    recommendedId = 'taxi';
    reasonKey = 'taxi';
  } else if (distKm > 8) {
    recommendedId = 'ride_hail';
    reasonKey = 'ride_hail';
  } else {
    recommendedId = 'metro';
    reasonKey = 'metro';
  }

  // 如果目的地类型为酒店，默认推荐出租车（少步行适合带行李）
  if (destination.type === 'hotel') {
    recommendedId = 'taxi';
    reasonKey = 'taxi';
  }

  // 如果目的地类型为学校/景点，默认推荐地铁
  if (destination.type === 'school' || destination.type === 'scenic') {
    recommendedId = 'metro';
    reasonKey = 'metro';
  }

  var reasonTemplate = reasons[reasonKey] || { short: '推荐方案（估算）', detail: '推荐方案（估算）' };

  return {
    recommendedId: recommendedId,
    reasonShort: reasonTemplate.short,
    reasonDetail: reasonTemplate.detail,
    estimatedDistance: distKm.toFixed(1) + ' 公里（估算）'
  };
}

// ============================================================
// 新增：大巴两阶段路径构建
// 第一阶段：引导到售票窗口
// 第二阶段：购票后引导到候车点
// 返回 { ticketSteps, waitingSteps }
// ============================================================
export function buildBusTwoStageSteps(mapData, startNodeId) {
  var ticketNodeId = mapData.busTicketData.ticketNodeId;
  var waitingNodeId = mapData.busTicketData.waitingNodeId;

  // 第一阶段：起点 → 售票窗口
  var ticketNodeIds = findNodePath(mapData.edges, startNodeId, ticketNodeId);
  var ticketSteps = buildIndoorSteps(mapData.nodes, ticketNodeIds, mapData.edges);

  // 第二阶段：售票窗口 → 候车点（通常在同一位置或很近）
  var waitingNodeIds = findNodePath(mapData.edges, ticketNodeId, waitingNodeId);
  var waitingSteps = buildIndoorSteps(mapData.nodes, waitingNodeIds, mapData.edges);

  return {
    ticketSteps: ticketSteps,
    waitingSteps: waitingSteps,
    ticketNodeIds: ticketNodeIds,
    waitingNodeIds: waitingNodeIds
  };
}

// ============================================================
// Haversine 距离计算（内部使用，与 geoHelper 中的独立实现重复但自包含）
// ============================================================
function haversineDistance(lat1, lng1, lat2, lng2) {
  var R = 6371000; // 地球半径（米）
  var dLat = (lat2 - lat1) * Math.PI / 180;
  var dLng = (lng2 - lng1) * Math.PI / 180;
  var a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLng / 2) * Math.sin(dLng / 2);
  var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}
