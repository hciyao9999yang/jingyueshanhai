import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const root=path.resolve(import.meta.dirname,'..');
const context=vm.createContext({console:{info(){},warn(){},error(){}},setTimeout(){throw Error('Unexpected map timer')},clearTimeout(){}});
const cache=new Map();
async function load(file){file=path.resolve(file);if(cache.has(file))return cache.get(file);let code=fs.readFileSync(file,'utf8');if(file.endsWith('.ink'))code=code.match(/<script setup>([\s\S]*?)<\/script>/)[1];const mod=new vm.SourceTextModule(code,{context,identifier:file});cache.set(file,mod);await mod.link((spec,ref)=>load(path.resolve(path.dirname(ref.identifier),spec)));await mod.evaluate();return mod;}
const def=(await load(root+'/pages/index/index.ink')).namespace.default;
const {MOCK_AIRPORT: data}=(await load(root+'/utils/mapData.js')).namespace;
const {findNodePath,buildIndoorSteps}=(await load(root+'/utils/routeEngine.js')).namespace;
const {ROUTE_IMAGES: images}=(await load(root+'/utils/routeImages.js')).namespace;
function page(){const p={...def,data:structuredClone(def.data),setData(v){Object.assign(this.data,v)}};p.onLoad();return p;}
let checked=0;const used=new Set();
for(const a of data.nodes)for(const b of data.nodes){
 const ids=findNodePath(data.edges,a.id,b.id),steps=buildIndoorSteps(data.nodes,ids,data.edges);
 const p=page();Object.assign(p.data,{phase:'indoor_nav',indoorSteps:steps});
 for(let idx=0;idx<steps.length;idx++){
  p.data.currentStepIndex=idx;p.data.currentStep=steps[idx];p.updateRouteImage();
  assert.equal(p.data.routeMapError,'');assert.ok(p.data.routeImageSrc);
  assert.ok(fs.existsSync(root+p.data.routeImageSrc));
  const key=[steps[idx].fromId,...steps.slice(idx).map(s=>s.toId)].join('>');
  const img=images[key];assert.equal(img.src,p.data.routeImageSrc);assert.equal(img.currentId,steps[idx].fromId);assert.equal(img.nextId,steps[idx].toId);
  assert.equal(img.crossFloor,steps[idx].fromFloor!==steps[idx].toFloor);
  used.add(img.src);checked++;
 }
}
assert.equal(used.size,Object.keys(images).length);
console.log('PASS all node-pair routes: '+checked+' step selections; '+used.size+' unique bundled images; identifiers/floors match');
let core=0;
for(let i=0;i<data.transportOptions.length;i++){
 const p=page();p.selectTransportByIndex(i);if(p.data.rideHailOrderMode)p.skipOrderCheck();
 const steps=p.data.indoorSteps;assert.ok(steps.length);let guard=0;
 while(p.data.phase==='indoor_nav'&&p.data.indoorSteps.length&&!(p.data.transportMode==='bus'&&p.data.busStage==='waiting')){
  assert.ok(p.data.routeImageSrc);assert.equal(p.data.routeMapError,'');
  assert.equal(p.data.currentFloor,p.data.currentStep.fromFloor);
  assert.equal(p.data.currentLocationLabel,p.data.currentStep.fromName);
  const expected=path.resolve(root,'.'+p.data.routeImageSrc);assert.ok(fs.existsSync(expected));
  p.advanceStep();core++;assert.ok(++guard<30);
 }
 if(p.data.transportMode==='bus')assert.equal(p.data.busStage,'waiting');else assert.equal(p.data.phase,'transport_info');
 console.log('PASS core flow '+data.transportOptions[i].id+': '+guard+' steps');
 // 重规划：每个可选地标均测试，目标节点不在列表内。
 const q=page();q.selectTransportByIndex(i);if(q.data.rideHailOrderMode)q.skipOrderCheck();
 q.wrongWay();const landmarks=[...q.data.wrongWayNodes];
 for(let j=0;j<landmarks.length;j++){q.data.wrongWayNodes=landmarks;q.data.wrongWayMode=true;q.selectLandmarkByIndex(j);if(q.data.indoorSteps.length){assert.ok(q.data.routeImageSrc);assert.equal(q.data.routeMapError,'');}}
 q.wrongWay();q.cancelWrongWay();assert.equal(q.data.wrongWayMode,false);assert.ok(q.data.routeImageSrc);
 q.onUnload();
}
console.log('PASS '+core+' main-flow steps; all selectable landmark replans; cancel and unload');
const broken=page();Object.assign(broken.data,{phase:'indoor_nav',indoorSteps:[{fromId:'missing',toId:'unknown'}],currentStepIndex:0});broken.updateRouteImage();assert.ok(broken.data.routeMapError);assert.equal(broken.data.routeImageSrc,'');
broken.data.currentStepIndex=99;broken.updateRouteImage();assert.ok(broken.data.routeMapError.includes('越界'));
broken.data.currentStepIndex=0;broken.data.indoorSteps=[{fromId:'a',toId:'b'},{fromId:'c',toId:'d'}];broken.updateRouteImage();assert.ok(broken.data.routeMapError.includes('不连续'));
console.log('PASS missing asset, invalid index and disconnected route: visible text fallback');
const ink=fs.readFileSync(root+'/pages/index/index.ink','utf8');
assert.ok(!ink.includes('<canvas'));assert.ok(!ink.includes('selectComponent('));assert.ok(!ink.includes('getContext('));assert.ok(!ink.includes('setTimeout('));
for(const [,name] of ink.matchAll(/bind(?:tap|input|change|confirm)="([A-Za-z0-9_]+)"/g))assert.equal(typeof def[name],'function',name);
for(const route of JSON.parse(fs.readFileSync(root+'/app.json')).pages)assert.ok(fs.existsSync(root+'/'+route+'.ink'));
await load(root+'/app.js');
console.log('PASS active module linking, page events and manifest; no Canvas/network/timer needed for map');
console.log('LIMIT: mock state tests only. AIUI importer/compiler and glasses rendering are NOT tested here.');
