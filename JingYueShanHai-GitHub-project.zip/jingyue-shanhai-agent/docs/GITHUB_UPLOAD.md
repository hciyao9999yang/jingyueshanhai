# 将项目上传到 GitHub

本说明适用于已解压的 `jingyue-shanhai-agent` 项目目录。不要只上传项目 ZIP，否则 GitHub 无法直接运行包内工作流。

## 方法一：Git 命令上传

### 1. 新建空仓库

登录 GitHub 后访问 https://github.com/new 。

- Repository name：`jingyue-shanhai-agent`
- Description：`镜越山海：Rokid AIUI 机场接驳 Agent`
- 可见性按需要选择；建议先用 Private 做真机测试。
- 不勾选初始化 README、gitignore 或 license，避免与本项目已有内容冲突。

创建后，复制你实际仓库的 HTTPS 地址。

### 2. 在项目根目录打开终端

Windows 可以在解压后的项目目录空白处右键打开终端。确认该目录能看到 `README.md`、`app.json`、`pages` 和 `assets`。

依次执行：

```sh
git init -b main
git add .
git commit -m "Initial airport Agent with bundled route maps"
```

如果 Git 提示未设置提交身份，先执行下面两条，并换成你自己的信息，再重新执行 commit：

```sh
git config user.name "你的GitHub用户名"
git config user.email "你的GitHub提交邮箱"
```

然后执行，URL 必须换成你刚创建的仓库地址：

```sh
git remote add origin https://github.com/YOUR_USERNAME/jingyue-shanhai-agent.git
git push -u origin main
```

按本机 Git 的登录提示完成认证。不要把密码或访问令牌写进项目、命令中的 URL，或发给别人。

### 3. 下载自动生成的 AIX

打开该仓库：

1. 点击 **Actions**。
2. 打开 **Build AIX** 的最新运行记录。
3. 等待运行成功，找到 **Artifacts**。
4. 下载 **JingYueShanHai-AIX**。
5. 解压下载结果，取得 `.aix` 文件，再上传到你已使用的 AIUI 入口。

产物里同时包含验证报告和 SHA256 校验值。工作流默认保存构建产物 30 天。

如果首次运行没有启动，检查仓库是否允许 Actions；也可以打开 Build AIX，通过 Run workflow 手动运行。

## 方法二：使用 GitHub Desktop 推送

如果你更习惯图形界面，可先在项目目录执行一次 `git init -b main`，再通过 GitHub Desktop 的 **File → Add local repository** 选择该目录。

在 Desktop 中提交文件，然后使用 **Publish repository** 发布。建议先保持私有。发布成功后，仍通过 GitHub 网页的 Actions 下载 AIX。

如 Desktop 版本菜单有所变化，以该版本实际界面为准。项目不包含你的 GitHub 登录信息，也未替你创建或推送远程仓库。

## 后续更新

修改代码或点位后，执行：

```sh
python scripts/build.py
git add .
git commit -m "Update airport Agent"
git push
```

构建产物目录 `dist/` 不会提交到 Git。GitHub Actions 会根据源码重新生成产物。

GitHub 的作用是版本管理与打包。它不会自动把 Agent 安装到眼镜，也不会把模拟点位变成真实机场地图。
