export default {
  globalData: {
    appName: '镜越山海｜机场赴赛导航',
    version: '1.0.3-localmap',
    demoMode: true,
    storageKey: 'journey_state'
  },

  onLaunch() {
    console.info('[镜越山海] Agent 启动 onLaunch — 镜越山海｜机场赴赛导航 v1.0.3-localmap');
    console.info('[镜越山海] demoMode=true, 模拟演示模式');
  },

  onShow() {
    console.info('[镜越山海] Agent onShow');
  },

  onHide() {
    console.info('[镜越山海] Agent onHide');
  },

  onError(err) {
    console.error('[镜越山海] Agent onError:', err);
  }
}
