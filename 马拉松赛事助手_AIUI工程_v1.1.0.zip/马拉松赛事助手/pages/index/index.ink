<script def>
{
  "navigationBarTitleText": "马拉松赛事助手",
  "description": "查询马拉松、中国登山协会及山地越野资料。将包含年份、站点、赛事或组别的用户原话传入 question。",
  "schema": {
    "data": {
      "type": "object",
      "properties": {"question": {"type": "string", "description": "用户的赛事问题原话"}},
      "additionalProperties": false
    }
  }
}
</script>
<script setup>
import agentPage from '../../lib/page.js';
export default agentPage;
</script>
<page>
  <view class="screen">
    <view class="top"><text class="badge">{{badge}}</text><text class="count">{{counter}}</text></view>
    <text class="title">{{title}}</text>
    <view class="body" ink:if="{{!typing}}">
      <text class="first">{{line0}}</text>
      <text class="bodyline" ink:if="{{line1}}">{{line1}}</text>
      <text class="bodyline" ink:if="{{line2}}">{{line2}}</text>
    </view>
    <view class="body" ink:if="{{typing}}">
      <input class="input" value="{{draft}}" placeholder="输入赛事问题" bindinput="updateText" bindconfirm="submitTyped" />
      <view class="controls"><text class="key" bindtap="submitTyped">查询</text><text class="key" bindtap="goBack">返回</text></view>
    </view>
    <text class="source" ink:if="{{!status}}">{{source}}</text>
    <text class="status" ink:if="{{status}}">{{status}}</text>
    <view class="controls" ink:if="{{!typing}}">
      <text class="key" bindtap="prev">上翻</text>
      <text class="primary" bindtap="centerAction">{{center}}</text>
      <text class="key" bindtap="next">下翻</text>
      <text class="key" ink:if="{{showMountainCatalog}}" bindtap="openMountain">登山资料</text>
      <text class="quiet" bindtap="openText">键入</text>
    </view>
  </view>
</page>
<style>
.screen { box-sizing: border-box; display: flex; flex-direction: column; width: 100%; height: 100%; padding: 8px 16px; background-color: #000000; }
.top { display: flex; flex-direction: row; justify-content: space-between; align-items: center; }
.badge,.count,.source,.quiet { color: #81dba0; font-size: 13px; line-height: 17px; }
.title { color: #c0ffd0; font-size: 23px; font-weight: bold; line-height: 30px; }
.body { display: flex; flex: 1; min-height: 0; flex-direction: column; justify-content: center; }
.first,.bodyline { color: #98fbb1; font-size: 18px; line-height: 24px; }
.first { color: #d0ffda; font-weight: bold; }
.source,.status { font-size: 13px; line-height: 17px; }
.status { color: #c7ffd9; }
.controls { display: flex; flex-direction: row; align-items: center; }
.key,.primary,.quiet { font-size: 15px; line-height: 22px; margin-right: 14px; }
.key { color: #9afab1; } .primary { color: #d0ffda; font-weight: bold; }
.quiet { color: #81dba0; }
.input { height: 30px; font-size: 16px; line-height: 25px; color: #c0ffd0; background-color: #000000; border: 1px solid #60ba79; }
@media (max-height: 185px) {
  .screen { padding: 2px 10px; }
  .badge,.count,.source,.status { font-size: 11px; line-height: 14px; }
  .title { font-size: 17px; line-height: 22px; }
  .first,.bodyline { font-size: 14px; line-height: 19px; }
  .key,.primary,.quiet { font-size: 13px; line-height: 19px; }
}
</style>
