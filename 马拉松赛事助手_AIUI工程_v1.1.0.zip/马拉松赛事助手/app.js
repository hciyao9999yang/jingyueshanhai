export default {globalData: {name: '马拉松赛事助手', version: '1.1.0', knowledgeDate: '2026-11-19'}};
